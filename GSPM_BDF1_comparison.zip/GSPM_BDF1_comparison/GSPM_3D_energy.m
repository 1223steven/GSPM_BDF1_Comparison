% 3D GSPM for comparing the results to the 3D BDF method (mainly for the CPU Time)
% % the version
% first original version on 24th, September, 2018, author: Changjian Xie
% % started
% clear; close all; clc;
format long;
% h = waitbar(0,'Please wait...'); % build the process bar
% % the discretization in 3D space 
xleft = 0.0;
xright = 1.d0;
yleft = 0.0;
yright = 1.d0; 
zleft = 0.0;
zright = 1.d0;
Nx = 20.0;
Ny = 20.0;
Nz = 20.0;
nnl = Nx*Ny*Nz; % use /mnt/d/PersonalFile/Desktop_great/Chen_Jingrun_mission/phd_paper/paper_2/3D_GSPM_with_exchange/GSPM_3D/GSPM_diag_Damp_v3
% nn = 53600; %32(2); %352(4); %3200(8); %27136(16); %223232(32); %1810432(64);
            % 53600(20) % 93312(24) % 148960(28) %318816 (36) % 1296 (6) % 7n^3-6n^2
dx = (xright-xleft)/Nx;
dy = (yright-yleft)/Ny;
dz = (zright-zleft)/Nz;
x = xleft+dx/2:dx:xright-dx/2;
y = yleft+dy/2:dy:yright-dy/2;
z = zleft+dz/2:dz:zright-dz/2;
% X = x.^2.*(ones(1,Nx)-x).^2;        % change variable 
% X_prime = 4*x.^3-6*x.^2+2*x;         % the derivative of X
% X_prime_2 = 12*x.^2-12*x+2*ones(1,Nx); % the derivative of X_prime
% 
% Y = y.^2.*(ones(1,Ny)-y).^2;        % change variable 
% Y_prime = 4*y.^3-6*y.^2+2*y;         % the derivative of X
% Y_prime_2 = 12*y.^2-12*y+2*ones(1,Ny); % the derivative of X_prime
% 
% Z = z.^2.*(ones(1,Nz)-z).^2;        % change variable 
% Z_prime = 4*z.^3-6*z.^2+2*z;         % the derivative of X
% Z_prime_2 = 12*z.^2-12*z+2*ones(1,Nz); % the derivative of X_prime
% % the discretization in time 
T = 1.d-1;
T0 = 0.0;
Nt = 40;
dt = (T-T0)/Nt;
% % damping parameter
alpha = 0.2;

% % iteration
% initial condition
m_init_1 = zeros(Nx,Ny,Nz);m_init_2 = m_init_1;m_init_3 = m_init_1;
tic;

x_exact_prime = zeros(1,3,Nx,Ny,Nz);
y_exact_prime = zeros(1,3,Nx,Ny,Nz);
z_exact_prime = zeros(1,3,Nx,Ny,Nz);
       
difference_x = zeros(size(x_exact_prime));
difference_y = zeros(size(y_exact_prime));
difference_z = zeros(size(z_exact_prime));

mt_p = zeros(3*Nx,Ny,Nz);

En = zeros(1,Nt+1);

t = T0;
% for k=1:Nz
%     for j=1:Ny
% %     m_init_1(:,j,k) = cos(X*Y(j)*Z(k))*sin(t);  % here m_init_1(:,1,1) is column vector
% %     m_init_2(:,j,k) = sin(X*Y(j)*Z(k))*sin(t);
% %     m_init_3(:,j,k) = ones(size(X))*cos(t); 
%     
% %     m_init_1(:,j,k) = cos(cos(pi*x)*cos(pi*y(j))*cos(pi*z(k)))*sin(t);  % here m_init_1(:,1,1) is column vector
% %     m_init_2(:,j,k) = sin(cos(pi*x)*cos(pi*y(j))*cos(pi*z(k)))*sin(t);
% %     m_init_3(:,j,k) = ones(size(x))*cos(t); 
%     
%     m_init_1(:,j,k) = cos(cos(pi*x))*sin(0.01);  % here m_init_1(:,1,1) is column vector
%     m_init_2(:,j,k) = sin(cos(pi*x))*sin(0.01);
%     m_init_3(:,j,k) = ones(size(x))*cos(0.01); 
%     end
% end


% Init S state

% for k = 1:Nz
%     for j = 1:Ny
%         for i = 1:Nx
%             if x(i) < xright/5.0
%                 m_init_1(i,j,k) = 0.0;
%                 m_init_2(i,j,k) = 1.0;
%                 m_init_3(i,j,k) = 0.0;
%             elseif x(i) > 4.0*xright/5.0
%                 m_init_1(i,j,k) = 0.0;
%                 m_init_2(i,j,k) = 1.0;
%                 m_init_3(i,j,k) = 0.0;
%             else
%                 m_init_1(i,j,k) = 1.0;
%                 m_init_2(i,j,k) = 0.0;
%                 m_init_3(i,j,k) = 0.0;
%             end
%         end
%     end
% end


% Init C state

for k = 1:Nz
    for j = 1:Ny
        for i = 1:Nx
            if x(i) < xright/5.0
                m_init_1(i,j,k) = 0.0;
                m_init_2(i,j,k) = 1.0;
                m_init_3(i,j,k) = 0.0;
            elseif x(i) > 4.0*xright/5.0
                m_init_1(i,j,k) = 0.0;
                m_init_2(i,j,k) = -1.0;
                m_init_3(i,j,k) = 0.0;
            else
                m_init_1(i,j,k) = 1.0;
                m_init_2(i,j,k) = 0.0;
                m_init_3(i,j,k) = 0.0;
            end
        end
    end
end

% ---- original energy -----
mt_p(1:Nx,:,:) = m_init_1(:,:,:);
mt_p(Nx+1:2*Nx,:,:) = m_init_2(:,:,:);
mt_p(2*Nx+1:3*Nx,:,:) = m_init_3(:,:,:);



 for k=1:Nz
    for j=1:Ny
        for i=1:Nx
            
            if i==1
                difference_x(:,:,i,j,k) =[(-mt_p(1,j,k)+mt_p(2,j,k))/(2*dx),...
                                          (-mt_p(Nx+1,j,k)+mt_p(Nx+2,j,k))/(2*dx),...
                                          (-mt_p(2*Nx+1,j,k)+mt_p(2*Nx+2,j,k))/(2*dx)];
                                      
                                      
           
            
            elseif i==Nx
                difference_x(:,:,i,j,k) = [(-mt_p(Nx-1,j,k)+mt_p(Nx,j,k))/(2*dx),...
                                           (-mt_p(Nx+Nx-1,j,k)+mt_p(Nx+Nx,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+Nx-1,j,k)+mt_p(2*Nx+Nx,j,k))/(2*dx)];
                                       
            
            
            else
                difference_x(:,:,i,j,k) = [(-mt_p(i-1,j,k)+0*mt_p(i,j,k)+mt_p(i+1,j,k))/(2*dx),...
                                           (-mt_p(Nx+i-1,j,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i+1,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+i-1,j,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i+1,j,k))/(2*dx)];
                                       
               
            end
         
            
            if j==1
                
                                      
                difference_y(:,:,i,j,k) =[(-mt_p(i,1,k)+mt_p(i,2,k))/(2*dy),...
                                          (-mt_p(Nx+i,1,k)+mt_p(Nx+i,2,k))/(2*dy),...
                                          (-mt_p(2*Nx+i,1,k)+mt_p(2*Nx+i,2,k))/(2*dy)];
                                      
                
                                      
            
            
            elseif j==Ny
                
                                       
                difference_y(:,:,i,j,k) = [(-mt_p(i,Ny-1,k)+mt_p(i,Ny,k))/(2*dy),...
                                           (-mt_p(Nx+i,Ny-1,k)+mt_p(Nx+i,Ny,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,Ny-1,k)+mt_p(2*Nx+i,Ny,k))/(2*dy)];
                                       
                
            
            
                  
                 
            else
                
                difference_y(:,:,i,j,k) = [(-mt_p(i,j-1,k)+0*mt_p(i,j,k)+mt_p(i,j+1,k))/(2*dy),...
                                           (-mt_p(Nx+i,j-1,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j+1,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,j-1,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j+1,k))/(2*dy)];
                                       
                 
            end
            
            if k==1
                
                difference_z(:,:,i,j,k) =[(-mt_p(i,j,1)+mt_p(i,j,2))/(2*dz),...
                                          (-mt_p(Nx+i,j,1)+mt_p(Nx+i,j,2))/(2*dz),...
                                          (-mt_p(2*Nx+i,j,1)+mt_p(2*Nx+i,j,2))/(2*dz)];
                                      
            
            elseif k==Nz
                            
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,Nz-1)+mt_p(i,j,Nz))/(2*dz),...
                                           (-mt_p(Nx+i,j,Nz-1)+mt_p(Nx+i,j,Nz))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,Nz-1)+mt_p(2*Nx+i,j,Nz))/(2*dz)];
            
            
            
            else
                        
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,k-1)+0*mt_p(i,j,k)+mt_p(i,j,k+1))/(2*dz),...
                                           (-mt_p(Nx+i,j,k-1)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j,k+1))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,k-1)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j,k+1))/(2*dz)];
                                       
            end
            
%             difference_x(:,:,i,j,k) = [(mt_p(i+1,j,k)-mt_p(i,j,k))/dx, (mt_p(Nx+i+1,j,k)-mt_p(Nx+i,j,k))/dx, (mt_p(2*(Nx-1)+i+3,j,k)-mt_p(2*(Nx-1)+i+2,j,k))/dx];          
        end
    end
 end


 % comput 
 En(1,1) = sum(sum(sum(sum(difference_x.^2 + difference_y.^2 + difference_z.^2))))*dx*dy*dz;
 
% ------------------

m_exact_1= m_init_1;m_exact_2= m_init_2;m_exact_3= m_init_3;
f1 = m_init_1;  f2 = m_init_2;  f3 = m_init_3;

m_init_1= reshape(m_init_1,1,Nx*Ny*Nz);m_init_2= reshape(m_init_2,1,Nx*Ny*Nz);m_init_3= reshape(m_init_3,1,Nx*Ny*Nz);
% m1 = m_init_1;      m2 = m_init_2;  m3 = m_init_3;
% g1 = m_init_1;      g2 = m_init_2;  g3 = m_init_3;
% m_tmp1 = m_init_1;   m_tmp2 = m_init_2; m_tmp3 = m_init_3;


% Create the sparse matrix for inversion
e = ones(Nx,1);
A = spdiags([e -2*e e],-1:1,Nx,Nx);
A(1,1) = -1; 
A(Nx,Nx) = -1;
Ax = A/dx^2;
Iy = speye(Nx,Nx)/dy^2;
Iz = speye(Nx,Nx)/dz^2;
EPS = 0.d0;

% ------
counter = 0;

for ii=1:Nx
    for jj=1:Nx
        if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
%             nonzero_row_index(counter+1,1) = ii;
%             nonzero_col_index(counter+1,1) = jj;
%             nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) );
            counter = counter +1;
        end
    end
%     nonzero_row_index(counter+1,1) = ii;
%     nonzero_col_index(counter+1,1) = Nx+ii;
%     nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
%     nonzero_row_index(counter+1,1) = ii;
%     nonzero_col_index(counter+1,1) = Nx*Ny+ii;
%     nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;
    end
end

for kk=2:Ny-1
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
%                 nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
%                 nonzero_col_index(counter+1,1) = (kk-1)*Nx+jj;
%                 nonzero_value(counter+1,1) = ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) );
                counter = counter +1;
            end
        end
%         nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
%         nonzero_col_index(counter+1,1) = (kk-2)*Nx+ii;
%         nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
%         nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
%         nonzero_col_index(counter+1,1) = kk*Nx+ii;
%         nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        if Nz >= 2
%         nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
%         nonzero_col_index(counter+1,1) = Nx*Ny+(kk-1)*Nx+ii;
%         nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1; 
        end
    end
end

for ii=1:Nx
    for jj=1:Nx
        if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
%             nonzero_row_index(counter+1,1) = Nx*(Ny-1)+ii;
%             nonzero_col_index(counter+1,1) = Nx*(Ny-1)+jj;
%             nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) );
            counter = counter +1;
        end
    end
%     nonzero_row_index(counter+1,1) = Nx*(Ny-1)+ii;
%     nonzero_col_index(counter+1,1) = Nx*(Ny-2)+ii;
%     nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
%     nonzero_row_index(counter+1,1) = Nx*(Ny-1)+ii;
%     nonzero_col_index(counter+1,1) = Nx*Ny+(Ny-1)*Nx+ii;
%     nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;
    end
end

for ll=2:Nz-1
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) ) ) > EPS
%                 nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
%                 nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+jj;
%                 nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) );
                counter = counter +1;
            end
        end
%         nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
%         nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+Nx+ii;
%         nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
%         nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
%         nonzero_col_index(counter+1,1) = ll*Nx*Ny+ii;
%         nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;
        
%         nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
%         nonzero_col_index(counter+1,1) = (ll-2)*Nx*Ny+ii;
%         nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;        
    end
    for kk=2:Ny-1
        for ii=1:Nx
            for jj=1:Nx
                if abs( ( Ax(ii,jj)-2.d0*Iy(ii,jj)-2.d0*Iz(ii,jj) ) ) > EPS
%                     nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
%                     nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+jj;
%                     nonzero_value(counter+1,1) = ( Ax(ii,jj)-2.d0*Iy(ii,jj)-2.d0*Iz(ii,jj) );
                    counter = counter +1;
                end
            end
%             nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
%             nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-2)*Nx+ii;
%             nonzero_value(counter+1,1) = Iy(1,1);
            counter = counter +1;
            
%             nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
%             nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+kk*Nx+ii;
%             nonzero_value(counter+1,1) = Iy(1,1);
            counter = counter +1;
            
%             nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
%             nonzero_col_index(counter+1,1) = ll*Nx*Ny+(kk-1)*Nx+ii;
%             nonzero_value(counter+1,1) = Iz(1,1);
            counter = counter +1;
            
%             nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
%             nonzero_col_index(counter+1,1) = (ll-2)*Nx*Ny+(kk-1)*Nx+ii;
%             nonzero_value(counter+1,1) = Iz(1,1);
            counter = counter +1;           
        end        
    end
    
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) ) ) > EPS
%                 nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
%                 nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+jj;
%                 nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) );
                counter = counter +1;
            end
        end
%         nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
%         nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-2)+ii;
%         nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
%         nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
%         nonzero_col_index(counter+1,1) = ll*Nx*Ny+(Ny-1)*Nx+ii;
%         nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;
        
%         nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
%         nonzero_col_index(counter+1,1) = (ll-2)*Nx*Ny+(Ny-1)*Nx+ii;
%         nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;     
    end  
end

for ii=1:Nx
    for jj=1:Nx
       if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
%            nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+ii;
%            nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+jj;
%            nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) );
           counter = counter +1;
       end
    end
%     nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+ii;
%     nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx+ii;
%     nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
%     nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+ii;
%     nonzero_col_index(counter+1,1) = (Nz-2)*Nx*Ny+ii;
%     nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;   
    end
end

for kk=2:Ny-1
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
%                 nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
%                 nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+jj;
%                 nonzero_value(counter+1,1) = ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) );
                counter = counter +1;
            end
        end
%         nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
%         nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-2)*Nx+ii;
%         nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
%         nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
%         nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+kk*Nx+ii;
%         nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        if Nz >= 2
%         nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
%         nonzero_col_index(counter+1,1) = (Nz-2)*Nx*Ny+(kk-1)*Nx+ii;
%         nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;  
        end
    end   
end

for ii=1:Nx
    for jj=1:Nx
        if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
%             nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+ii;
%             nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+jj;
%             nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj));
            counter = counter +1;
        end
    end
%     nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+ii;
%     nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-2)+ii;
%     nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
%     nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+ii;
%     nonzero_col_index(counter+1,1) = (Nz-2)*Nx*Ny+(Ny-1)*Nx+ii;
%     nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;
    end
    
end

% ------

nonzero_row_index = zeros(counter,1);
nonzero_col_index = zeros(counter,1);
nonzero_value = zeros(counter,1);
one = speye(Nx,Nx);
counter = 0;

for ii=1:Nx
    for jj=1:Nx
        if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
            nonzero_row_index(counter+1,1) = ii;
            nonzero_col_index(counter+1,1) = jj;
            nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) );
            counter = counter +1;
        end
    end
    nonzero_row_index(counter+1,1) = ii;
    nonzero_col_index(counter+1,1) = Nx+ii;
    nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
    nonzero_row_index(counter+1,1) = ii;
    nonzero_col_index(counter+1,1) = Nx*Ny+ii;
    nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;
    end
end

for kk=2:Ny-1
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
                nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
                nonzero_col_index(counter+1,1) = (kk-1)*Nx+jj;
                nonzero_value(counter+1,1) = ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) );
                counter = counter +1;
            end
        end
        nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
        nonzero_col_index(counter+1,1) = (kk-2)*Nx+ii;
        nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
        nonzero_col_index(counter+1,1) = kk*Nx+ii;
        nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        if Nz >= 2
        nonzero_row_index(counter+1,1) = (kk-1)*Nx+ii;
        nonzero_col_index(counter+1,1) = Nx*Ny+(kk-1)*Nx+ii;
        nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1; 
        end
    end
end

for ii=1:Nx
    for jj=1:Nx
        if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
            nonzero_row_index(counter+1,1) = Nx*(Ny-1)+ii;
            nonzero_col_index(counter+1,1) = Nx*(Ny-1)+jj;
            nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) );
            counter = counter +1;
        end
    end
    nonzero_row_index(counter+1,1) = Nx*(Ny-1)+ii;
    nonzero_col_index(counter+1,1) = Nx*(Ny-2)+ii;
    nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
    nonzero_row_index(counter+1,1) = Nx*(Ny-1)+ii;
    nonzero_col_index(counter+1,1) = Nx*Ny+(Ny-1)*Nx+ii;
    nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;
    end
end

for ll=2:Nz-1
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) ) ) > EPS
                nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
                nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+jj;
                nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) );
                counter = counter +1;
            end
        end
        nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
        nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+Nx+ii;
        nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
        nonzero_col_index(counter+1,1) = ll*Nx*Ny+ii;
        nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;
        
        nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+ii;
        nonzero_col_index(counter+1,1) = (ll-2)*Nx*Ny+ii;
        nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;        
    end
    for kk=2:Ny-1
        for ii=1:Nx
            for jj=1:Nx
                if abs( ( Ax(ii,jj)-2.d0*Iy(ii,jj)-2.d0*Iz(ii,jj) ) ) > EPS
                    nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
                    nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+jj;
                    nonzero_value(counter+1,1) = ( Ax(ii,jj)-2.d0*Iy(ii,jj)-2.d0*Iz(ii,jj) );
                    counter = counter +1;
                end
            end
            nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
            nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-2)*Nx+ii;
            nonzero_value(counter+1,1) = Iy(1,1);
            counter = counter +1;
            
            nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
            nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+kk*Nx+ii;
            nonzero_value(counter+1,1) = Iy(1,1);
            counter = counter +1;
            
            nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
            nonzero_col_index(counter+1,1) = ll*Nx*Ny+(kk-1)*Nx+ii;
            nonzero_value(counter+1,1) = Iz(1,1);
            counter = counter +1;
            
            nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+(kk-1)*Nx+ii;
            nonzero_col_index(counter+1,1) = (ll-2)*Nx*Ny+(kk-1)*Nx+ii;
            nonzero_value(counter+1,1) = Iz(1,1);
            counter = counter +1;           
        end        
    end
    
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) ) ) > EPS
                nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
                nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+jj;
                nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-2.d0*Iz(ii,jj) );
                counter = counter +1;
            end
        end
        nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
        nonzero_col_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-2)+ii;
        nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
        nonzero_col_index(counter+1,1) = ll*Nx*Ny+(Ny-1)*Nx+ii;
        nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;
        
        nonzero_row_index(counter+1,1) = (ll-1)*Nx*Ny+Nx*(Ny-1)+ii;
        nonzero_col_index(counter+1,1) = (ll-2)*Nx*Ny+(Ny-1)*Nx+ii;
        nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;     
    end  
end

for ii=1:Nx
    for jj=1:Nx
       if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
           nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+ii;
           nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+jj;
           nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) );
           counter = counter +1;
       end
    end
    nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+ii;
    nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx+ii;
    nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
    nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+ii;
    nonzero_col_index(counter+1,1) = (Nz-2)*Nx*Ny+ii;
    nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;   
    end
end

for kk=2:Ny-1
    for ii=1:Nx
        for jj=1:Nx
            if abs( ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
                nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
                nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+jj;
                nonzero_value(counter+1,1) = ( Ax(ii,jj)-2.d0*Iy(ii,jj)-Iz(ii,jj) );
                counter = counter +1;
            end
        end
        nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
        nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-2)*Nx+ii;
        nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
        nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+kk*Nx+ii;
        nonzero_value(counter+1,1) = Iy(1,1);
        counter = counter +1;
        
        if Nz >= 2
        nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+(kk-1)*Nx+ii;
        nonzero_col_index(counter+1,1) = (Nz-2)*Nx*Ny+(kk-1)*Nx+ii;
        nonzero_value(counter+1,1) = Iz(1,1);
        counter = counter +1;  
        end
    end   
end

for ii=1:Nx
    for jj=1:Nx
        if abs( ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj) ) ) > EPS
            nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+ii;
            nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+jj;
            nonzero_value(counter+1,1) = ( Ax(ii,jj)-Iy(ii,jj)-Iz(ii,jj));
            counter = counter +1;
        end
    end
    nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+ii;
    nonzero_col_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-2)+ii;
    nonzero_value(counter+1,1) = Iy(1,1);
    counter = counter +1;
    
    if Nz >= 2
    nonzero_row_index(counter+1,1) = (Nz-1)*Nx*Ny+Nx*(Ny-1)+ii;
    nonzero_col_index(counter+1,1) = (Nz-2)*Nx*Ny+(Ny-1)*Nx+ii;
    nonzero_value(counter+1,1) = Iz(1,1);
    counter = counter +1;
    end
    
end

% counter

Del = sparse(nonzero_row_index,nonzero_col_index,nonzero_value,nnl,nnl);

DelB = speye(nnl,nnl) - alpha*dt*Del; 
Del = speye(nnl,nnl) - dt*Del;


f_pr1 = zeros(1,Nx*Ny*Nz);
f_pr2 = zeros(1,Nx*Ny*Nz);
f_pr3 = zeros(1,Nx*Ny*Nz);


for nsteps=1:Nt
% nsteps = 1;
    % implicit Gauss-Seidel
%     t =  T0 + nsteps*dt;
    t =  T0 + (nsteps-1)*dt; % version 3 : correct the force term f; good

% f = [cos(X)*cos(t)+cos(t)*sin(t)*sin(X).*(X_prime).^2-cos(t)*sin(t)*cos(X).*X_prime_2+...
%     alpha*sin(t)*sin(X).*X_prime_2+alpha*sin(t)*cos(t)^2*cos(X).*(X_prime).^2;
%     sin(X)*cos(t)-cos(t)*sin(t)*cos(X).*(X_prime).^2-cos(t)*sin(t)*sin(X).*X_prime_2-...
%     alpha*sin(t)*cos(X).*X_prime_2+alpha*cos(t)^2*sin(t)*sin(X).*(X_prime).^2;
%     -sin(t)+sin(t)^2*X_prime_2-alpha*sin(t)^2*cos(t)*sin(X).*(cos(X)+sin(X)).*((X_prime).^2-X_prime_2)];
% for k=1:Nz
%     for j=1:Ny
% %        phi = (Y(j)*Z(k))^2*(X_prime).^2+(X*Z(k)).^2*(Y_prime(j))^2+(X*Y(j)).^2*(Z_prime(k))^2;
% %        psi = Y(j)*Z(k)*X_prime_2+X*Z(k)*Y_prime_2(j)+X*Y(j)*Z_prime_2(k);
% %        f1(:,j,k) = cos(t)*cos(X'*Y(j)*Z(k))+sin(t)*cos(t)*(sin(X'*Y(j)*Z(k)).*phi'-cos(X'*Y(j)*Z(k)).*psi')+alpha*(cos(t)^2*sin(t)*cos(X'*Y(j)*Z(k)).*phi'+sin(t)*sin(X'*Y(j)*Z(k)).*psi');
% %        f2(:,j,k) = cos(t)*sin(X'*Y(j)*Z(k))-sin(t)*cos(t)*(cos(X'*Y(j)*Z(k)).*phi'+sin(X'*Y(j)*Z(k)).*psi')+alpha*(cos(t)^2*sin(t)*sin(X'*Y(j)*Z(k)).*phi'-sin(t)*cos(X'*Y(j)*Z(k)).*psi');
% %        f3(:,j,k) =-sin(t)*ones(Nx,1)+sin(t)^2*psi'-alpha*sin(t)^2*cos(t)*phi';
%        
%               a = cos(pi*x)*cos(pi*y(j))*cos(pi*z(k));
%        ax = -pi*sin(pi*x)*cos(pi*y(j))*cos(pi*z(k));
%        ay = -pi*sin(pi*y(j))*cos(pi*x)*cos(pi*z(k));
%        az = -pi*sin(pi*z(k))*cos(pi*x)*cos(pi*y(j));
%        
%        % for sol
%        u = cos(a)*sin(t);
%        v = sin(a)*sin(t);
%        w = ones(size(a))*cos(t);
%        
%        ux = -sin(a).*ax*sin(t);
%        vx = cos(a).*ax*sin(t);
%        wx = zeros(size(a));
%        
%        uy = -sin(a).*ay*sin(t);
%        vy = cos(a).*ay*sin(t);
%        wy = zeros(size(a));
%        
%        uz = -sin(a).*az*sin(t);
%        vz = cos(a).*az*sin(t);
%        wz = zeros(size(a));
%        
%        
%        uxx = -cos(a).*ax.*ax*sin(t)-sin(a)*(-pi^2).*a*sin(t);
%        uyy = -cos(a).*ay.*ay*sin(t)-sin(a)*(-pi^2).*a*sin(t);
%        uzz = -cos(a).*az.*az*sin(t)-sin(a)*(-pi^2).*a*sin(t);
%        du = uxx+uyy+uzz;
%        
%        vxx = -sin(a).*ax.*ax*sin(t)+cos(a)*(-pi^2).*a*sin(t);
%        vyy = -sin(a).*ay.*ay*sin(t)+cos(a)*(-pi^2).*a*sin(t);
%        vzz = -sin(a).*az.*az*sin(t)+cos(a)*(-pi^2).*a*sin(t);
%        dv = vxx+vyy+vzz;
%        
%        wxx = zeros(size(a));
%        wyy = zeros(size(a));
%        wzz = zeros(size(a));
%        dw = wxx+wyy+wzz;
%        
%        ut = cos(a)*cos(t);
%        vt = sin(a)*cos(t);
%        wt = -ones(size(a))*sin(t);
%        
%                
% %        b(:,j,k) = [(ut +(v.*dw-w.*dv)+alpha*(v.*(u.*dv-v.*du)-w.*(w.*du-u.*dw) ) )';
% %                    (vt +(w.*du-u.*dw)+alpha*(w.*(v.*dw-w.*dv)-u.*(u.*dv-v.*du) ) )';
% %                    (wt +(u.*dv-v.*du)+alpha*(u.*(w.*du-u.*dw)-v.*(v.*dw-w.*dv) ) )'];
%                
%        f1(:,j,k) = (ut +(v.*dw-w.*dv)+alpha*(v.*(u.*dv-v.*du)-w.*(w.*du-u.*dw) ) )';
%        f2(:,j,k) = (vt +(w.*du-u.*dw)+alpha*(w.*(v.*dw-w.*dv)-u.*(u.*dv-v.*du) ) )';
%        f3(:,j,k) = (wt +(u.*dv-v.*du)+alpha*(u.*(w.*du-u.*dw)-v.*(v.*dw-w.*dv) ) )';
%                
% 
%     end
% end
% f_pr1 = dt*reshape(f1,1,Nx*Ny*Nz);
% f_pr2 = dt*reshape(f2,1,Nx*Ny*Nz);
% f_pr3 = dt*reshape(f3,1,Nx*Ny*Nz);


% f_pr1 = zeros(1,Nx*Ny*Nz);
% f_pr2 = zeros(1,Nx*Ny*Nz);
% f_pr3 = zeros(1,Nx*Ny*Nz);




%     m_tmp = m_init;
% m_tmp1 = m_init_1; 
m_tmp2 = m_init_2; m_tmp3 = m_init_3;
%     m_tmp(1,1) = m_tmp(1,1) - 0/dx*dt;
%     m_tmp(2,1) = m_tmp(2,1) - 0/dx*dt;
%     m_tmp(3,1) = m_tmp(3,1) - 0/dx*dt;
%     m_tmp(1,Nx) = m_tmp(1,Nx) + 0/dx*dt;
%     m_tmp(2,Nx) = m_tmp(2,Nx) + 0/dx*dt;
%     m_tmp(3,Nx) = m_tmp(3,Nx) + 0/dx*dt;
%     g1 = m_tmp1/Del; % m_init_i is the row vector and m_tmp is as well
% tic;
    g2 = m_tmp2/Del;
% toc;
    g3 = m_tmp3/Del;
%     m1 = m_init_1 + g2.*m_init_3 - g3.*m_init_2;
    m1 = m_init_1 + g2.*m_init_3 - g3.*m_init_2 + f_pr1;
    m_tmp1 = m1; % update 
%     m_tmp(1,1) = m_tmp(1,1) - 0/dx*dt;
%     m_tmp(2,1) = m_tmp(2,1) - 0/dx*dt;
%     m_tmp(3,1) = m_tmp(3,1) - 0/dx*dt;
%     m_tmp(1,Nx) = m_tmp(1,Nx) + 0/dx*dt;
%     m_tmp(2,Nx) = m_tmp(2,Nx) + 0/dx*dt;
%     m_tmp(3,Nx) = m_tmp(3,Nx) + 0/dx*dt;
    g1 = m_tmp1/Del; % this is for g^{*}
%     m2 = m_init_2 + g3.*m1 - g1.*m_init_3;
    m2 = m_init_2 + g3.*m1 - g1.*m_init_3 + f_pr2;
    m_tmp2 = m2; % update
%     m_tmp(1,1) = m_tmp(1,1) - 0/dx*dt;
%     m_tmp(2,1) = m_tmp(2,1) - 0/dx*dt;
%     m_tmp(3,1) = m_tmp(3,1) - 0/dx*dt;
%     m_tmp(1,Nx) = m_tmp(1,Nx) + 0/dx*dt;
%     m_tmp(2,Nx) = m_tmp(2,Nx) + 0/dx*dt;
%     m_tmp(3,Nx) = m_tmp(3,Nx) + 0/dx*dt;
    g2 = m_tmp2/Del;
%     m3 = m_init_3 + g1.*m2 - g2.*m1;
    m3 = m_init_3 + g1.*m2 - g2.*m1 + f_pr3;

    % Heat flow without constraints
%     m_damp(1,:) = m(1,:) + dt*f(1,:);  % Here, due to the zero BC, so we
%     neglect the BC
%     m1 = m1 + f_pr1;
    m1 = m1/DelB;
%     m_damp(2,:) = m(2,:) + dt*f(2,:);
%     m2 = m2 + f_pr2;
    m2 = m2/DelB;
%     m_damp(3,:) = m(3,:) + dt*f(3,:);
%     m(3,:) = B\m_damp(3,:)';
%     m3 = m3 + f_pr3;
    m3 = m3/DelB;
    
    % Projection onto S^2
%     norm_m = sqrt(m1.^2+m2.^2+m3.^2);
%     m1 = m1./norm_m;
%     m2 = m2./norm_m;
%     m3 = m3./norm_m;
    
    m_init_1 = m1;
    m_init_2 = m2;
    m_init_3 = m3;
    
    % ===== for the energy comput ======
  
    mr = [m1;
          m2;
          m3];
  
    m1t = mr';
    m10 = reshape(m1t,Nx,Ny,Nz,3);

    for k=1:Nz
        for j=1:Ny
            mt_p(:,j,k) = [m10(:,j,k,1); m10(:,j,k,2); m10(:,j,k,3)];
%             m_exact(:,j,k) = [mrt0(:,j,k,1); mrt0(:,j,k,2); mrt0(:,j,k,3)];
        end
    end

 for k=1:Nz
    for j=1:Ny
        for i=1:Nx
            
            if i==1
                difference_x(:,:,i,j,k) =[(-mt_p(1,j,k)+mt_p(2,j,k))/(2*dx),...
                                          (-mt_p(Nx+1,j,k)+mt_p(Nx+2,j,k))/(2*dx),...
                                          (-mt_p(2*Nx+1,j,k)+mt_p(2*Nx+2,j,k))/(2*dx)];
                                      
                                      
           
            
            elseif i==Nx
                difference_x(:,:,i,j,k) = [(-mt_p(Nx-1,j,k)+mt_p(Nx,j,k))/(2*dx),...
                                           (-mt_p(Nx+Nx-1,j,k)+mt_p(Nx+Nx,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+Nx-1,j,k)+mt_p(2*Nx+Nx,j,k))/(2*dx)];
                                       
            
            
            else
                difference_x(:,:,i,j,k) = [(-mt_p(i-1,j,k)+0*mt_p(i,j,k)+mt_p(i+1,j,k))/(2*dx),...
                                           (-mt_p(Nx+i-1,j,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i+1,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+i-1,j,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i+1,j,k))/(2*dx)];
                                       
               
            end
         
            
            if j==1
                
                                      
                difference_y(:,:,i,j,k) =[(-mt_p(i,1,k)+mt_p(i,2,k))/(2*dy),...
                                          (-mt_p(Nx+i,1,k)+mt_p(Nx+i,2,k))/(2*dy),...
                                          (-mt_p(2*Nx+i,1,k)+mt_p(2*Nx+i,2,k))/(2*dy)];
                                      
                
                                      
            
            
            elseif j==Ny
                
                                       
                difference_y(:,:,i,j,k) = [(-mt_p(i,Ny-1,k)+mt_p(i,Ny,k))/(2*dy),...
                                           (-mt_p(Nx+i,Ny-1,k)+mt_p(Nx+i,Ny,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,Ny-1,k)+mt_p(2*Nx+i,Ny,k))/(2*dy)];
                                       
                
            
            
                  
                 
            else
                
                difference_y(:,:,i,j,k) = [(-mt_p(i,j-1,k)+0*mt_p(i,j,k)+mt_p(i,j+1,k))/(2*dy),...
                                           (-mt_p(Nx+i,j-1,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j+1,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,j-1,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j+1,k))/(2*dy)];
                                       
                 
            end
            
            if k==1
                
                difference_z(:,:,i,j,k) =[(-mt_p(i,j,1)+mt_p(i,j,2))/(2*dz),...
                                          (-mt_p(Nx+i,j,1)+mt_p(Nx+i,j,2))/(2*dz),...
                                          (-mt_p(2*Nx+i,j,1)+mt_p(2*Nx+i,j,2))/(2*dz)];
                                      
            
            elseif k==Nz
                            
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,Nz-1)+mt_p(i,j,Nz))/(2*dz),...
                                           (-mt_p(Nx+i,j,Nz-1)+mt_p(Nx+i,j,Nz))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,Nz-1)+mt_p(2*Nx+i,j,Nz))/(2*dz)];
            
            
            
            else
                        
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,k-1)+0*mt_p(i,j,k)+mt_p(i,j,k+1))/(2*dz),...
                                           (-mt_p(Nx+i,j,k-1)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j,k+1))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,k-1)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j,k+1))/(2*dz)];
                                       
            end
            
%             difference_x(:,:,i,j,k) = [(mt_p(i+1,j,k)-mt_p(i,j,k))/dx, (mt_p(Nx+i+1,j,k)-mt_p(Nx+i,j,k))/dx, (mt_p(2*(Nx-1)+i+3,j,k)-mt_p(2*(Nx-1)+i+2,j,k))/dx];          
        end
    end
 end


 % comput 
 En(1,nsteps+1) = sum(sum(sum(sum(difference_x.^2 + difference_y.^2 + difference_z.^2))))*dx*dy*dz;
 
    % ==================================
    
%     waitbar(nsteps / Nt) %  Basic Wait Bar
fprintf('The iteration times: %d \n',nsteps);
end

toc;
% close(h) % end the wait bar
% Compare with the exact solution

% t = T0 + Nt*dt;
% % t = T0 + dt;
% for k=1:Nz
%     for j=1:Ny
% %     m_exact_1(:,j,k) = cos(X'*Y(j)*Z(k))*sin(t); 
% %     m_exact_2(:,j,k) = sin(X'*Y(j)*Z(k))*sin(t);
% %     m_exact_3(:,j,k) = ones(size(X'))*cos(t); 
%     
%     
%     m_exact_1(:,j,k) = cos(cos(pi*x')*cos(pi*y(j))*cos(pi*z(k)))*sin(t);  % here m_init_1(:,1,1) is column vector
%     m_exact_2(:,j,k) = sin(cos(pi*x')*cos(pi*y(j))*cos(pi*z(k)))*sin(t);
%     m_exact_3(:,j,k) = ones(size(x'))*cos(t); 
%     end
% end
% m_exact_1= reshape(m_exact_1,1,Nx*Ny*Nz);
% m_exact_2= reshape(m_exact_2,1,Nx*Ny*Nz);
% m_exact_3= reshape(m_exact_3,1,Nx*Ny*Nz);
% % m_exact = [cos(x.^2.*(ones(1,Nx)-x).^2)*sin(t); 
% %            sin(x.^2.*(ones(1,Nx)-x).^2)*sin(t); 
% %            ones(size(x))*cos(t)];
% 
% % figure(1);clf;
% % plot(x,m(1,:)-m_exact(1,:),'b-');hold on;
% % plot(x,m(2,:)-m_exact(2,:),'r-');
% % plot(x,m(3,:)-m_exact(3,:),'g-');
% % legend('m_1','m_2','m_3','Location','NorthWest');
% 
% % element = [max(abs(m1-m_exact_1)),max(abs(m2-m_exact_2)),max(abs(m3-m_exact_3))];
% % err = max(element)
% 
% mr_exact = [m_exact_1; 
%             m_exact_2;
%             m_exact_3];
% 
% mr = [m1;
%       m2;
%       m3];
% 
% mt_p = zeros(3*Nx,Ny,Nz);
% m_exact = zeros(3*Nx,Ny,Nz);
% 
% m1t = mr';
% m10 = reshape(m1t,Nx,Ny,Nz,3);
% 
% mrt = mr_exact';
% mrt0 = reshape(mrt,Nx,Ny,Nz,3);
% 
% for k=1:Nz
%     for j=1:Ny
%     mt_p(:,j,k) = [m10(:,j,k,1); m10(:,j,k,2); m10(:,j,k,3)];
%     m_exact(:,j,k) = [mrt0(:,j,k,1); mrt0(:,j,k,2); mrt0(:,j,k,3)];
%     end
% end
% 
% m = reshape(mt_p,3*Nx*Ny*Nz,1);
% mt_exact = reshape(m_exact,3*Nx*Ny*Nz,1);
% 
% err_inf = max(abs(m-mt_exact))
% 
% x_exact_prime = zeros(1,3,Nx,Ny,Nz);
% y_exact_prime = zeros(1,3,Nx,Ny,Nz);
% z_exact_prime = zeros(1,3,Nx,Ny,Nz);
%        
%        
% for k=1:Nz
%     for j=1:Ny
%         for i=1:Nx
%             a = cos(pi*x(i))*cos(pi*y(j))*cos(pi*z(k));
%             ax = -pi*sin(pi*x(i))*cos(pi*y(j))*cos(pi*z(k));
%             ay = -pi*sin(pi*y(j))*cos(pi*x(i))*cos(pi*z(k));
%             az = -pi*sin(pi*z(k))*cos(pi*x(i))*cos(pi*y(j));
%             
% %             a = x(i).^2.*(1-x(i)).^2*y(j)^2*(1-y(j))^2*z(k)^2*(1-z(k))^2;
% %        
% %             ax = (2*x(i).*(1-x(i)).^2-2*x(i).^2.*(1-x(i)))*y(j)^2*(1-y(j))^2*z(k)^2*(1-z(k))^2;
% %             ay = x(i).^2.*(1-x(i)).^2*(2*y(j)*(1-y(j))^2-2*y(j)^2*(1-y(j)))*z(k)^2.*(1-z(k))^2;
% %             az = x(i).^2.*(1-x(i)).^2*y(j)^2*(1-y(j))^2*(2*z(k)*(1-z(k))^2-2*z(k)^2*(1-z(k)));
%             
%             x_exact_prime(:,:,i,j,k) = [-sin(a)*ax*sin(t), cos(a)*ax*sin(t),0];
%             
%             y_exact_prime(:,:,i,j,k) = [-sin(a)*ay*sin(t), cos(a)*ay*sin(t),0];
%             
%             z_exact_prime(:,:,i,j,k) = [-sin(a)*az*sin(t), cos(a)*az*sin(t),0];
%             
% %     x_exact_prime(:,:,i,j,k) = [-YY(j)*ZZ(k)*X_prime(i)*sin(X(i)*YY(j)*ZZ(k))*sin(t),YY(j)*ZZ(k)*X_prime(i)*cos(X(i)*YY(j)*ZZ(k))*sin(t),0];
%         end
%     end
% end
% 
% 
% 
% difference_x = zeros(size(x_exact_prime));
% difference_y = zeros(size(y_exact_prime));
% difference_z = zeros(size(z_exact_prime));
% 
% 
% for k=1:Nz
%     for j=1:Ny
%         for i=1:Nx
%             
%             if i==1
%                 difference_x(:,:,i,j,k) =[(-mt_p(1,j,k)+mt_p(2,j,k))/(2*dx),...
%                                           (-mt_p(Nx+1,j,k)+mt_p(Nx+2,j,k))/(2*dx),...
%                                           (-mt_p(2*Nx+1,j,k)+mt_p(2*Nx+2,j,k))/(2*dx)];
%                                       
%                                       
%            
%             
%             elseif i==Nx
%                 difference_x(:,:,i,j,k) = [(-mt_p(Nx-1,j,k)+mt_p(Nx,j,k))/(2*dx),...
%                                            (-mt_p(Nx+Nx-1,j,k)+mt_p(Nx+Nx,j,k))/(2*dx),...
%                                            (-mt_p(2*Nx+Nx-1,j,k)+mt_p(2*Nx+Nx,j,k))/(2*dx)];
%                                        
%             
%             
%             else
%                 difference_x(:,:,i,j,k) = [(-mt_p(i-1,j,k)+0*mt_p(i,j,k)+mt_p(i+1,j,k))/(2*dx),...
%                                            (-mt_p(Nx+i-1,j,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i+1,j,k))/(2*dx),...
%                                            (-mt_p(2*Nx+i-1,j,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i+1,j,k))/(2*dx)];
%                                        
%                
%             end
%          
%             
%             if j==1
%                 
%                                       
%                 difference_y(:,:,i,j,k) =[(-mt_p(i,1,k)+mt_p(i,2,k))/(2*dy),...
%                                           (-mt_p(Nx+i,1,k)+mt_p(Nx+i,2,k))/(2*dy),...
%                                           (-mt_p(2*Nx+i,1,k)+mt_p(2*Nx+i,2,k))/(2*dy)];
%                                       
%                 
%                                       
%             
%             
%             elseif j==Ny
%                 
%                                        
%                 difference_y(:,:,i,j,k) = [(-mt_p(i,Ny-1,k)+mt_p(i,Ny,k))/(2*dy),...
%                                            (-mt_p(Nx+i,Ny-1,k)+mt_p(Nx+i,Ny,k))/(2*dy),...
%                                            (-mt_p(2*Nx+i,Ny-1,k)+mt_p(2*Nx+i,Ny,k))/(2*dy)];
%                                        
%                 
%             
%             
%                   
%                  
%             else
%                 
%                 difference_y(:,:,i,j,k) = [(-mt_p(i,j-1,k)+0*mt_p(i,j,k)+mt_p(i,j+1,k))/(2*dy),...
%                                            (-mt_p(Nx+i,j-1,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j+1,k))/(2*dy),...
%                                            (-mt_p(2*Nx+i,j-1,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j+1,k))/(2*dy)];
%                                        
%                  
%             end
%             
%             if k==1
%                 
%                 difference_z(:,:,i,j,k) =[(-mt_p(i,j,1)+mt_p(i,j,2))/(2*dz),...
%                                           (-mt_p(Nx+i,j,1)+mt_p(Nx+i,j,2))/(2*dz),...
%                                           (-mt_p(2*Nx+i,j,1)+mt_p(2*Nx+i,j,2))/(2*dz)];
%                                       
%             
%             elseif k==Nz
%                             
%                 difference_z(:,:,i,j,k) = [(-mt_p(i,j,Nz-1)+mt_p(i,j,Nz))/(2*dz),...
%                                            (-mt_p(Nx+i,j,Nz-1)+mt_p(Nx+i,j,Nz))/(2*dz),...
%                                            (-mt_p(2*Nx+i,j,Nz-1)+mt_p(2*Nx+i,j,Nz))/(2*dz)];
%             
%             
%             
%             else
%                         
%                 difference_z(:,:,i,j,k) = [(-mt_p(i,j,k-1)+0*mt_p(i,j,k)+mt_p(i,j,k+1))/(2*dz),...
%                                            (-mt_p(Nx+i,j,k-1)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j,k+1))/(2*dz),...
%                                            (-mt_p(2*Nx+i,j,k-1)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j,k+1))/(2*dz)];
%                                        
%             end
%             
% %             difference_x(:,:,i,j,k) = [(mt_p(i+1,j,k)-mt_p(i,j,k))/dx, (mt_p(Nx+i+1,j,k)-mt_p(Nx+i,j,k))/dx, (mt_p(2*(Nx-1)+i+3,j,k)-mt_p(2*(Nx-1)+i+2,j,k))/dx];          
%         end
%     end
% end
% 
% % for k=1:Nz
% %     for j=1:Ny-1
% %         for i=1:Nx
% %             difference_y(:,:,i,j,k) = [(mt_p(i,j+1,k)-mt_p(i,j,k))/dy, (mt_p(Nx+i,j+1,k)-mt_p(Nx+i,j,k))/dy, (mt_p(2*(Nx-1)+i+2,j+1,k)-mt_p(2*(Nx-1)+i+2,j,k))/dy];
% %         end
% %     end
% % end
% % 
% % for k=1:Nz-1
% %     for j=1:Ny
% %         for i=1:Nx
% %             difference_z(:,:,i,j,k) = [(mt_p(i,j,k+1)-mt_p(i,j,k))/dz, (mt_p(Nx+i,j,k+1)-mt_p(Nx+i,j,k))/dz, (mt_p(2*(Nx-1)+i+2,j,k+1)-mt_p(2*(Nx-1)+i+2,j,k))/dz];           
% %         end
% %     end
% % end
% 
% % for k=1:Nz-1
% %     for j=1:Ny-1
% %         for i=1:Nx-1
% %             difference(:,:,i,j,k) = [(mt(i+1,j,k)-mt(i,j,k))/dx, (mt(Nx+i+1,j,k)-mt(Nx+i,j,k))/dx, (mt(2*(Nx-1)+i+3,j,k)-mt(2*(Nx-1)+i+2,j,k))/dx;
% %                                      (mt(i,j+1,k)-mt(i,j,k))/dy, (mt(Nx+i,j+1,k)-mt(Nx+i,j,k))/dy, (mt(2*(Nx-1)+i+2,j+1,k)-mt(2*(Nx-1)+i+2,j,k))/dy;
% %                                      (mt(i,j,k+1)-mt(i,j,k))/dz, (mt(Nx+i,j,k+1)-mt(Nx+i,j,k))/dz, (mt(2*(Nx-1)+i+2,j,k+1)-mt(2*(Nx-1)+i+2,j,k))/dz];           
% % %             difference(i,j,k) = (mt(i+1,j,k)-mt(i,j,k))./dx+(mt(i,j+1,k)-mt(i,j,k))./dy+(mt(i,j,k+1)-mt(i,j,k))./dz;
% % %             difference(Nx-1+i,j,k) = (mt(Nx+i+1,j,k)-mt(Nx+i,j,k))./dx+(mt(Nx+i,j+1,k)-mt(Nx+i,j,k))./dy+(mt(Nx+i,j,k+1)-mt(Nx+i,j,k))./dz;
% % %             difference(2*(Nx-1)+i,j,k) = (mt(2*(Nx-1)+i+3,j,k)-mt(2*(Nx-1)+i+2,j,k))./dx+(mt(2*(Nx-1)+i+2,j+1,k)-mt(2*(Nx-1)+i+2,j,k))./dy+(mt(2*(Nx-1)+i+2,j,k+1)-mt(2*(Nx-1)+i+2,j,k))./dz;
% %         end
% %     end
% % end
% 
% 
% % % err = max(abs(m-mt_exact)) % the infty norm
% err2 = sqrt(1.0/3.0*dx*dy*dz*sum((m-mt_exact).^2)) % the 2-norm
% % % err_grad_2_difference = sqrt(1.0/3.0*dx*dy*dz*sum(sum(sum(sum(sum((difference-mt_exact_prime).^2))))))  %% the \nabla error \ell^2-norm  
% % % err_grad_2_difference = sqrt(1.0/(9.0*(Nx-1)*(Ny-1)*(Nz-1))*sum(sum(sum(sum(sum((difference-mt_exact_prime).^2))))))  %% the \nabla error \ell^2-norm  
% % err_grad_2_difference = sqrt(1.0/(3.0*(Nx-1)*Ny*Nz)*(sum(sum(sum(sum((x_exact_prime-difference_x).^2))))+sum(sum(sum(sum((y_exact_prime-difference_y).^2))))+sum(sum(sum(sum((z_exact_prime-difference_z).^2))))));
% % err_grad_2_H_1 = err2 + err_grad_2_difference % the H^1 norm
tt = linspace(0,T,Nt+1);

toc; 

