!c
!c Semi-implicit method for the Spin-polarized equations.
!c
!c----- We make it second order in space by increasing the stencil at the
!c     interface. This means we need to solve an heptadiagonal system
!c
! the forcing term of BDF2 takes form of extrapolation, i.e., f^{n+2}=2*f^{n+1}-f^{n}

!      implicit double precision(a-h, o-z)
!      implicit integer(i-n)

      implicit none

      include "fftw3.f"
      include 'mpif.h'

      integer :: nx, ny, nz, nxp, nyp, nzp, mx, my, mz, nsteps, nfield, nw, i_hyst, iampere, &
                 ikernels, iloop, irest, iter, j, k


      double precision :: hyst_tolerance, a0, a_fm, a_J, acs, beta1, beta2, Bohr,&
                          ca, chi, Current, d_fm, dmag, dmpng, dt, Electron, ElectronVolt, &
                          energynew, energyold, EnergyScale, eps, etaJ_fm, etaSF_fm, &
                          etaSF_SF, FieldStrength, fku, fms, gamma, q, ratio, s1, sigma, &
                          sigma0, TimeScale, tmp, tp, twrite, v1, xmax, xreal, ymax, yreal, &
                          zero_mu, zmax, zreal, df


      parameter( nx = 100, ny = 100, nxp = nx+1, nyp = ny+1 )
      parameter( nz = 4, nzp = nz+1 )
      parameter( mx = 2*nx, my = 2*ny, mz = 2*nz )
      parameter( nsteps = 40, nfield = 200, nw = 1000 )
      parameter( hyst_tolerance = 1.d-7 )
!c
!c----- variables for the magnetization in the first layer
!c
      double precision u0(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision u0_prime(0:nxp, 0:nyp, 0:nzp, 3)

      double precision u1(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision u1_prime(0:nxp, 0:nyp, 0:nzp, 3)
      ! double precision u2(0:nxp, 0:nyp, 0:nzp, 3)


      double precision hu1(nx, ny, nz, 3), hu2(nx, ny, nz, 3), emfu(nx, ny, nz, 3)
!      double precision tmp(nx, ny, nz)
      double precision si, sj, t

!c
!!c----- Ampere field and External field
!c
!      double precision ampereu(nx, ny, nz, 3), xtrnlu(nx, ny, nz, 3)
! only external field
    double precision xtrnlu(nx, ny, nz, 3)

!c
!c----- variables for the gspm, backward euler step (tridiagonal system)
!c
      double precision gu(nx, ny, nz, 3)
      double precision ggu(3*nx, ny, nz)
      double precision m_inter(3*nx, ny, nz)


!      double precision diagu_gm(nx, ny, nz), upperdu_gm(nx, ny, nz),&
!          fmulu_gm(nx, ny, nz)
!      double precision diagu_pj(nx, ny, nz), upperdu_pj(nx, ny, nz),&
!          fmulu_pj(nx, ny, nz)
!c
!c----- variables for the spin accumulation
!c
!!      double precision s0(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision s1(0:nxp, 0:nyp, 0:nzp, 3)
!!
!!      double precision sx(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision sy(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision sz(0:nxp, 0:nyp, 0:nzp, 3)
!!
!!      double precision sxm(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision sym(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision szm(0:nxp, 0:nyp, 0:nzp, 3)
!!      double precision gs(nx, ny, nz, 3)
!!
!!      double precision Js0(0:nxp, 0:nyp, 0:nzp, 3, 3)
!!      double precision Js1(0:nxp, 0:nyp, 0:nzp, 3, 3)
!!      double precision gJs(0:nxp, 0:nyp, 0:nzp, 3, 3)
!c
!c----- variables for the grid
!c
      double precision z(nz)
!c
!c----- variables for the backward euler (heptadiagonal system)
!c
!      double precision diags(nx, ny, nz)
!      double precision upperds(nx, ny, nz)
!      double precision fmuls(nx, ny, nz)
!c
!c----- variables for the Fourier transform of u in the plane
!c
      integer*8 planf_be_u(nz, 3), planb_be_u(nz, 3)
!c
!c----- variables for the Fourier transform of s in the plane
!c
      integer*8 planf_be_s(nz, 3), planb_be_s(nz, 3)
!c
!c----- eigenvalues of thelaplacian in the plane
!c
      double precision evalx(nx), evaly(ny)
!c
!c----- variables for the convolution
!c
      double complex khat( mx/2+1, my, mz, 6 )
      double precision work2( nw )
      integer link( nw )

      integer*8 convf(3), convb(3)
      double precision uhat( 0:mx-1, 0:my-1, 0:mz-1, 3 )
      double complex work( mx/2+1, my, mz, 3 )
!c
!c----- for the energy and external field
!c
      double precision eng_magu( 3 ), eng_cplu
      double precision eng_magv( 3 ), eng_cplv
!      double precision eng_spin(2)

!      double precision efield( 3, nfield )
      double precision efield( 3, nfield+1 )

      double precision magu( 3 )
      double precision magv( 3 )

      double precision x(nx), y(ny)
!c
!c----- for the filenames
!c
      integer m(5)
      character filename*60
!c
!c----- parameters
!c
      double precision lambda_SF, lambda_J, LengthScale
!c
!c----- variables for the kernel computation
!c
      double precision dx, dy, dz, lambda, mu, nu, pi

      common/param/dx, dy, dz, lambda, mu, nu, pi
!=========================================================
! for mpi
      integer    MAX_LOCAL_SIZE
      integer    HYPRE_PARCSR

      parameter  (MAX_LOCAL_SIZE=40000000)

!c     the following is from HYPRE.c
      parameter  (HYPRE_PARCSR=5555)
      integer    ierr
      integer    num_procs, myid
      integer    local_size, extra
      integer    solver_id, print_solution, ng
      integer    nnz, ilower, iupper, i
      integer    precond_id

      double precision rhs_values(MAX_LOCAL_SIZE)
      double precision x_values(MAX_LOCAL_SIZE)
      integer    rows(MAX_LOCAL_SIZE)
      integer, parameter :: nnl=3*nx*ny*nz, nnx=21

      integer    cols(nnl,nnx),colsB(nnl,nnx)
      integer   mat_counter(nnl,1),mat_counterB(nnl,1)
      double precision values(nnl,nnx),valuesB(nnl,nnx)
      integer    num_iterations
      double precision final_res_norm, tol

      integer    mpi_comm

      integer*8  parcsr_A
      integer*8  AA        ! means :  HYPRE_TYPE
      integer*8  bb        ! means :  HYPRE_TYPE
      integer*8  x_hat   ! means :  HYPRE_TYPE
      integer*8  par_b     ! means :  HYPRE_TYPE
      integer*8  par_x     ! means :  HYPRE_TYPE
      integer*8  solver    ! means :  HYPRE_TYPE
      integer*8  precond   ! means :  HYPRE_TYPE

      integer :: nonzero_row_index(nnx,1),nonzero_col_index(nnx,1),i_index(nnl,1)
      double precision :: nonzero_value(nnx,1)
      double precision :: rhs(nnl,1),g(nnl,1)
      double precision m1(Nx*Ny*Nz,1), m2(Nx*Ny*Nz,1),m3(Nx*Ny*Nz,1)

double precision, parameter :: EPSS = 0.d0, e_rr=0.d0

double precision Ax(Nx,Nx),Iy(Nx,Nx),Iz(Nx,Nx),one(Nx,Nx)
double precision :: Cy(1:3*Nx,1:3*Nx), Cz(1:3*Nx,1:3*Nx), EE(1:3*Nx,1:3*Nx)


integer :: N=1,ii=1,kk=1,jj=1,ll=1, counter=0, counter_sum=0
double precision :: t1=0.d0,t2=0.d0
double precision e(Nx,1)
double precision Cy_1(Nx,Nx)

!c-----------------------------------------------------------------------
!c     Initialize MPI
!c-----------------------------------------------------------------------write(*,*) 'myid'
	  
      call MPI_INIT(ierr)
      call MPI_COMM_RANK(MPI_COMM_WORLD, myid, ierr)
      call MPI_COMM_SIZE(MPI_COMM_WORLD, num_procs, ierr)
      mpi_comm = MPI_COMM_WORLD
		
	  write(*,*) myid  ! 0
	  
	  write(*,*) 'num_procs'
      write(*,*) num_procs ! 1 
	  
      !c   Default problem parameters
      solver_id = 11 ! here we use GMRES
      print_solution  = 1
      tol = 1.0d-7

      ng = 3*Nx*Ny*Nz

      local_size = ng/num_procs
	  
	  
      extra = ng - local_size*num_procs

      ilower = local_size*myid
      ilower = ilower + min(myid, extra)

      iupper = local_size*(myid+1)
      iupper = iupper + min(myid+1, extra)
      iupper = iupper - 1

      local_size = iupper - ilower + 1

      !----------------------------------------------

!double precision :: e_x(Nx,1),e_y(Ny,1),e_z(Nz,1)
tmp = 0.d0
g = 0.d0
rhs =1.d0

nonzero_row_index = 0
nonzero_col_index = 0
nonzero_value = 0.d0
! the initialization for intermediate variable
!e_x = 1.d0
!e_y = 1.d0
!e_z = 1.d0
e = 1.d0

Ax = 0.d0
Iy = 0.d0
Iz = 0.d0

!===================================================
!c
!c----- physical parameters
!c
      open(7,file='parameters')
!c- dimensions: 1 micron long, 1 micron wide, 20 nanometers high
      read(7,*)
      read(7,*) xreal
      read(7,*)
      read(7,*) yreal
      read(7,*)
      read(7,*) zreal
!c
!c     - exchange, anisotropy, and saturation magnetization
!c
!c---- ca is given in Joule per meter
      read(7,*)
      read(7,*) ca
!c     ca = 1.3d-11
!c---- fku is given in Joule per meter^3
      read(7,*)
      read(7,*) fku
!c     fku = 5.d+2
!c---- fms is given in Ampere per meter.
      read(7,*)
      read(7,*) fms
!c     fms = 8.d+5
!c External Field strength (in Tesla)
      read(7,*)
      read(7,*) FieldStrength
!c---- d_fm (in meter^2 per second)
      read(7,*)
      read(7,*) d_fm
!c---- lambda_J (in meters)
      read(7,*)
      read(7,*) lambda_J
!c---- lambda_SF (in meters)
      read(7,*)
      read(7,*) lambda_SF
!c---- a_J (in electron volt)
      read(7,*)
      read(7,*) a_J
!c---- Current (in Ampere per meter^2)
      read(7,*)
      read(7,*) Current
!c---- a0 (in meters)
      read(7,*)
      read(7,*) a0
!c---- beta, beta'
      read(7,*)
      read(7,*) beta1
      read(7,*)
      read(7,*) beta2
!c---- the damping is dimensionless
      read(7,*)
      read(7,*) dmpng
!c     dmpng = 1.d0 / 512
      read(7,*)
      read(7,*) iloop
      close(7)
!c---- gamma is given in 1./(Tesla second)
      pi = 4.d0*datan(1.d0)
!c---- zero_mu has dimensions Newton per Ampere^2
      zero_mu = 4.d0*pi*1.d-7
      gamma = 1.76d+11
!c---- Bohr magneton (in Ampere times meter^2)
      Bohr = 9.2741d-24
!c---- electron charge (in Ampere times second)
      Electron = -1.602d-19
!c---- electron Volt (in Joules)
      ElectronVolt = 1.6d-19
!c---- ratio between characteristic times of electron collision and spin-magnetization coupling
      ratio =  lambda_J**2/(2.d0*d_fm) / ( 6.582d-16 / a_J )
!c
!c---- numerical parameters: We make the code dimensionless
!c
      LengthScale = xreal
      TimeScale = 1.d0  / (gamma*zero_mu*fms)
!c      TimeScale = (1.d0 + dmpng**2) / (gamma*zero_mu*fms)
      EnergyScale = zero_mu * fms**2 * LengthScale**3

      eps = 2.d0 * ca / (zero_mu * fms**2 * LengthScale**2)
      q = 2.d0 * fku / (zero_mu * fms**2)

      a_fm = d_fm * TimeScale / LengthScale**2

      etaSF_fm = d_fm * TimeScale / lambda_SF**2

      etaJ_fm = d_fm * TimeScale / lambda_J**2

      sigma0 = Bohr * Current * beta1 * TimeScale /&
          (Electron * LengthScale * fms)

      chi = a_J * ElectronVolt / (a0**3 * zero_mu * fms**2)

!c      write(*,*) 'a_fm', a_fm, 'etaJ_in', etaJ_in
!c
!c----- Strength of the ampere field
!c
      acs = Current * LengthScale / fms
!c
!c----- strength of the external field in dimensionless form
!c
      dmag = FieldStrength / (zero_mu * fms)
!!        dmag = 50.d0
!      dmag = 6.d-2

!      efield(1,1) = dmag!dmag !* dcos(pi / 180.d0)
!      efield(2,1) = 0.d0!-dmag !dmag * dsin(pi / 180.d0)
!      efield(3,1) = 0.d0

!      efield(1,1) = dmag !* dcos(pi / 180.d0)
!      efield(2,1) = 0.d0 !dmag * dsin(pi / 180.d0)
!      efield(3,1) = 0.d0

      efield(1,1) = 0.d0!dmag !* dcos(pi / 180.d0)
      efield(2,1) = 0.d0 !dmag * dsin(pi / 180.d0)
      efield(3,1) = 0.d0

!! for short axis (x axis)
!      efield(1,1) = dmag * dcos(pi / 180.d0)
!      efield(2,1) = dmag * dsin(pi / 180.d0)
!      efield(3,1) = 0.d0

!! for long axis (y axis)
!      efield(1,1) = -dmag * dsin(pi / 180.d0)
!      efield(2,1) = dmag * dcos(pi / 180.d0)
!      efield(3,1) = 0.d0

!      efield(1,1) = 0.d0
!      efield(2,1) = dmag
!      efield(3,1) = 0.d0

!! for z axis
!      efield(1,1) = 0.d0
!      efield(2,1) = 0.d0
!      efield(3,1) = dmag

      efield(1,2) = 0.d0
      efield(2,2) = 0.d0
      efield(3,2) = 0.d0

      efield(1,3) = 0.d0
      efield(2,3) = 0.d0
      efield(3,3) = 0.d0

      efield(1,4) = 0.d0
      efield(2,4) = 0.d0
      efield(3,4) = 0.d0

!      df = 4 * FieldStrength / nfield
      df = 4 * dmag / nfield

!!!! df = 2.d-3
!!!!
!!!!      do kk=2,51
!!!!         dmag = dmag - df
!!!!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!!!!         efield(2,kk) = 0.d0!dmag * dsin(pi / 180.d0)
!!!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!!!      enddo
!!!!
!!!!      df = 4.d-4
!!!!
!!!!      do kk=52,nfield
!!!!         dmag = dmag - df
!!!!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!!!!         efield(2,kk) = 0.d0!dmag * dsin(pi / 180.d0)
!!!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!!!      enddo

!!      do kk=2,nfield/2+1
!!         dmag = dmag - df
!!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!!         efield(2,kk) = 0.d0!dmag * dsin(pi / 180.d0)
!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!      enddo

!!      do kk=2,nfield/2
!!         dmag = dmag - df
!!        ! parrallel short axis (x axis)
!!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!!         efield(2,kk) = 0.d0 !dmag * dsin(pi / 180.d0)
!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!
!!         ! for short axis (x axis) angle: +1
!!!         efield(1,kk) = dmag * dcos(pi / 180.d0)
!!!         efield(2,kk) = dmag * dsin(pi / 180.d0)
!!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!
!!         ! for long axis (y axis): +1
!!!          efield(1,kk) = -dmag * dsin(pi / 180.d0)
!!!          efield(2,kk) = dmag * dcos(pi / 180.d0)
!!!          efield(3,kk) = 0.d0!efield(3,kk-1)
!!
!!!!         ! for z axis
!!!          efield(1,kk) = 0.d0
!!!          efield(2,kk) = 0.d0
!!!          efield(3,kk) = dmag
!!      enddo

!!      do kk=nfield/2+2,nfield+1
!!         dmag = dmag + df
!!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!!         efield(2,kk) = 0.d0!dmag * dsin(pi / 180.d0)
!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!      enddo

!      do kk=nfield/2+2,nfield
!         dmag = dmag + df
!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!         efield(2,kk) = 0.d0!dmag * dsin(pi / 180.d0)
!         efield(3,kk) = 0.d0!efield(3,kk-1)
!      enddo

!!      do kk=nfield/2+1,nfield
!!         dmag = dmag + df
!!         ! parallel short axis (x axis)
!!         efield(1,kk) = dmag !* dcos(pi / 180.d0)
!!         efield(2,kk) = 0.d0! dmag * dsin(pi / 180.d0)
!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!
!!         ! for short axis (x axis) angle: +1
!!!         efield(1,kk) = dmag * dcos(pi / 180.d0)
!!!         efield(2,kk) = dmag * dsin(pi / 180.d0)
!!!         efield(3,kk) = 0.d0!efield(3,kk-1)
!!
!!         ! for long axis (y axis) angle: +1
!!!          efield(1,kk) = -dmag * dsin(pi / 180.d0)
!!!          efield(2,kk) = dmag * dcos(pi / 180.d0)
!!!          efield(3,kk) = 0.d0!efield(3,kk-1)
!!
!!!!         ! for z axis
!!!          efield(1,kk) = 0.d0
!!!          efield(2,kk) = 0.d0
!!!          efield(3,kk) = dmag
!!      enddo

      open(1,file='fields')
      do kk=1,nfield
         write(1,*) FieldStrength*efield(1,kk),&
             FieldStrength*efield(2,kk)
      enddo
      close(1)

      open(9,file='loop1.dat')
      open(10,file='loop2.dat')
      open(101,file='Remanent_loop1.dat')
!c
!c----- initialize numerical constants
!c
      xmax = xreal / LengthScale
      ymax = yreal / LengthScale
      zmax = zreal / LengthScale

      dx = xmax / dble( nx )
      dy = ymax / dble( ny )
      dz = zmax / dble( nz )

     ! dt = 1.d-13 / TimeScale ! dt is 0.1ps
      dt = 1.d-12 / TimeScale ! dt is 1ps
!      tp = 1.d-9 / TimeScale ! tp is 1ns
!     tp = 1.d-8 / TimeScale ! tp is 10ns
!     tp = 1.6d-9 / TimeScale ! tp is 1.6ns
      tp = 2.d-9 / TimeScale ! tp is 2ns
!      tp = 0.1d-9 / TimeScale ! tp is 2ns

!      tp = 8.d-9 / TimeScale ! tp is 8ns

      write(*,*) 'dt', dt, 'dx', dx, 'dy', dy, 'dz', dz
!      pause
!c

! Create the sparse tridiagonal discrete laplacian matrix
do ii=2,Nx
Ax(ii,ii)=-2.d0
Ax(ii,ii-1)=1.d0
Ax(ii-1,ii)=1.d0
enddo
Ax(1,1)=-1.d0
Ax(Nx,Nx)=-1.d0

Ax = dt*Ax/dx**2

one(:,:)=0.d0
do ii=1,Nx
 one(ii,ii)=1.d0
enddo
Iy=dt*1.d0/dy**2*one
Iz=dt*1.d0/dz**2*one

!write(*,*) 'dx'
!write(*,*) dx
!
!write(*,*) 'Ax(1,1:4)'
!write(*,*) Ax(1,1:4)

!c----- Initialize variables for the convolution
!c
      write(*,*) 'Creating plans....'
      t1 = second()
      do j=1,3
         call dfftw_plan_dft_r2c_3d( convf(j), mx, my, mz,&
             uhat(0,0,0,j), work(1,1,1,j), FFTW_MEASURE )

         call dfftw_plan_dft_c2r_3d( convb(j), mx, my, mz,&
             work(1,1,1,j), uhat(0,0,0,j), FFTW_MEASURE )
      enddo
      t2 = second()
      write(*,*) 'Plans created in ', t2-t1, ' seconds.'
!c
!c----- Initialize variables for Backward Euler for u
!c
!!      write(*,*) 'Creating plans for Backward Euler for u....'
!!      t1 = second()
!!      do ll=1,3
!!         do k=1,nz
!!            call dfftw_plan_r2r_2d(planf_be_u(k,ll), nx, ny,&
!!                gu(1,1,k,ll), gu(1,1,k,ll), FFTW_REDFT01,&
!!                FFTW_REDFT01, FFTW_EXHAUSTIVE)
!!            call dfftw_plan_r2r_2d(planb_be_u(k,ll), nx, ny,&
!!                gu(1,1,k,ll), gu(1,1,k,ll), FFTW_REDFT10,&
!!                FFTW_REDFT10, FFTW_EXHAUSTIVE)
!!         enddo
!!      enddo
!!      t2 = second()
!!      write(*,*) 'Plans created in ', t2-t1,' seconds.'
!c
!c----- Initialize variables for Backward Euler for s
!c
!      write(*,*) 'Creating plans for Backward Euler for s....'
!      t1 = second()
!      do ll=1,3
!         do k=1,nz
!            call dfftw_plan_r2r_2d(planf_be_s(k,ll), nx, ny,&
!                gs(1,1,k,ll), gs(1,1,k,ll), FFTW_REDFT01,&
!                FFTW_REDFT01, FFTW_EXHAUSTIVE)
!            call dfftw_plan_r2r_2d(planb_be_s(k,ll), nx, ny,&
!                gs(1,1,k,ll), gs(1,1,k,ll), FFTW_REDFT10,&
!                FFTW_REDFT10, FFTW_EXHAUSTIVE)
!         enddo
!      enddo
!      t2 = second()
!      write(*,*) 'Plans created in ', t2-t1,' seconds.'
!c
!c----- Define e-values for the laplacian
!c
!      do i=1,nx
!         si = .5d0 * pi * dble( i-1 ) / dble( nx )
!         evalx(i) = - 4.d0 * ( dsin( si ) / dx )**2
!      enddo
!
!      do j=1,ny
!         sj = .5d0 * pi * dble(j-1) / dble( ny )
!         evaly(j) = - 4.d0 * ( dsin( sj ) / dy )**2
!      enddo
!c
!c----- Files for output
!c
      open( 11, file='history' )
      open( 12, file='anisotropy_u' )
      open( 13, file='exchange_u' )
      open( 14, file='stray_u' )
      open( 15, file='coupling_u' )
      open( 16, file='mag_u' )

      open( 32, file='energy_s' )
      open( 36, file='accumulation' )
!c
!c----- run for one nanosecond
!c
      t = 0.d0
!c
!c----- define the numerical grid
!c
      do i=1,nx
         x(i) = ( dble( i ) - .5d0 ) * dx
      enddo

      do j=1,ny
         y(j) = ( dble( j ) - .5d0 ) * dy
      enddo

      do k=1,nz
         z(k) = (dble(k)-.5d0) * dz
      enddo

!      write(*,*) 'Compute kernels? (1=yes)'
!      read(*,*) ikernels
      ikernels = 1

      if( ikernels .eq. 1 ) then
!c
!c----- compute kernels
!c
         call krnl( uhat, work2, khat, mx, my, mz, nw )
      else
!c
!c----- read kernels
!c
         write(*,*) 'Reading kernels....'
         open(7,file='kernels.7',form='unformatted')
         read(7) khat
         close(7)
         write(*,*) 'Kernels read.'
      endif

!      write(*,*) 'Compute Ampere field? (1=yes)'
!      read(*,*) iampere
      iampere = 0

!!      if( iampere .eq. 1 ) then
!!!c
!!!c----- compute Ampere field
!!!c
!!         call amp( ampereu, work2, link, nx, ny, nz, nw,&
!!             x, y, z, xmax, ymax, zmax )
!!      else
!!!c
!!!c----- read Ampere field
!!!c
!!         write(*,*) 'Reading Ampere field....'
!!         open(7,file='ampere.7',form='unformatted')
!!         read(7) ampereu
!!         close(7)
!!         write(*,*) 'Ampere field read.'
!!      endif
!c
!c----- rescale Ampere field
!c
!!      do k=1,nz
!!         do j=1,ny
!!            do i=1,nx
!!               ampereu(i,j,k,1) = acs * ampereu(i,j,k,1)
!!               ampereu(i,j,k,2) = acs * ampereu(i,j,k,2)
!!               ampereu(i,j,k,3) = acs * ampereu(i,j,k,3)
!!            enddo
!!         enddo
!!      enddo
!c
!c----- Lu decomposition for the gyromagnetic term for first layer
!c
!!      k=1
!!      do j=1,ny
!!         do i=1,nx
!!            diagu_gm(i,j,k) = 1.d0 + eps * dt * &
!!                (1.d0 / dz**2 - evalx(i) - evaly(j))
!!         enddo
!!      enddo

!!      do k=2,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               diagu_gm(i,j,k) = 1.d0 &
!!                   + eps * dt * (2.d0 / dz**2 - evalx(i) - evaly(j))
!!            enddo
!!         enddo
!!      enddo
!!
!!      k=nz
!!      do j=1,ny
!!         do i=1,nx
!!            diagu_gm(i,j,k) = 1.d0 + eps * dt * &
!!                (1.d0 / dz**2 - evalx(i) - evaly(j))
!!         enddo
!!      enddo

!!      do k=1,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               upperdu_gm(i,j,k) = - eps * dt / dz**2
!!               fmulu_gm(i,j,k) = - eps * dt / dz**2
!!            enddo
!!         enddo
!!      enddo
!!
!!      do k=1,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               fmulu_gm(i,j,k) = fmulu_gm(i,j,k) / diagu_gm(i,j,k)
!!               diagu_gm(i,j,k+1) = diagu_gm(i,j,k+1) &
!!                   - fmulu_gm(i,j,k) * upperdu_gm(i,j,k)
!!            enddo
!!         enddo
!!      enddo
!c
!c----- Lu decomposition for the damping term for first layer
!c
!!      k=1
!!      do j=1,ny
!!         do i=1,nx
!!            diagu_pj(i,j,k) = 1.d0 + dmpng * eps * &
!!                dt * (1.d0 / dz**2 - evalx(i) - evaly(j))
!!         enddo
!!      enddo
!!
!!      do k=2,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               diagu_pj(i,j,k) = 1.d0 + dmpng * eps * &
!!                   dt * (2.d0 / dz**2 - evalx(i) - evaly(j))
!!            enddo
!!         enddo
!!      enddo

!!      k=nz
!!      do j=1,ny
!!         do i=1,nx
!!            diagu_pj(i,j,k) = 1.d0 + dmpng * eps * &
!!                dt * (1.d0 / dz**2 - evalx(i) - evaly(j))
!!         enddo
!!      enddo

!!      do k=1,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               upperdu_pj(i,j,k) = - dmpng * eps * dt / dz**2 ! this for dissipation term
!!               fmulu_pj(i,j,k) = - dmpng * eps * dt / dz**2
!!            enddo
!!         enddo
!!      enddo

!!      do k=1,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               fmulu_pj(i,j,k) = fmulu_pj(i,j,k) / diagu_pj(i,j,k)
!!               diagu_pj(i,j,k+1) = diagu_pj(i,j,k+1) &
!!                   - fmulu_pj(i,j,k) * upperdu_pj(i,j,k)
!!            enddo
!!         enddo
!!      enddo
!c
!c----- LU decomposition for the spin term
!c
!c
!c----- diagonal
!c
!      do j=1,ny
!         do i=1,nx
!            k=1
!            diags(i,j,k) = 1.d0 + a_fm * dt * (1.d0 / dz**2 - evalx(i) &
!                - evaly(j))
!            do k=2,nz-1
!               diags(i,j,k) = 1.d0 + a_fm * dt * (2.d0 / dz**2 &
!                   - evalx(i) - evaly(j))
!            enddo
!
!            k=nz
!            diags(i,j,k) = 1.d0 + a_fm * dt * (1.d0 / dz**2 &
!                - evalx(i) - evaly(j))
!!c
!!c----- upper diagonals
!!c
!            do k=1,nz-1
!               upperds(i,j,k) = - a_fm * dt / dz**2
!            enddo
!!c
!!c----- lower diagonals
!!c
!            do k=1,nz-1
!               fmuls(i,j,k) = - a_fm * dt / dz**2
!            enddo
!         enddo
!      enddo
!c
!c----- do LU of the matrix
!c
!!      do k=1,nz-1
!!         do j=1,ny
!!            do i=1,nx
!!               fmuls(i,j,k) = fmuls(i,j,k) / diags(i,j,k)
!!               diags(i,j,k+1) = diags(i,j,k+1) &
!!                   - fmuls(i,j,k) * upperds(i,j,k)
!!            enddo
!!         enddo
!!      enddo
!c
!c----- initial data
!c
!c      write(*,*) 'Entering init'
!      call init( u0, s0, Js0, x, y, z, xmax, ymax, &
!          zmax, nx, ny, nz, irest, iter )

      call init( u0, x, y, z, xmax, ymax, &
          zmax, nx, ny, nz, irest, iter ) ! iter = 0

      call bc( u0, nx, ny, nz )

      do k=1,nz
         do j=1,ny
            do i=1,nx
               u1(i,j,k,1) = u0(i,j,k,1)
               u1(i,j,k,2) = u0(i,j,k,2)
               u1(i,j,k,3) = u0(i,j,k,3)
            enddo
         enddo
      enddo

      call bc( u1, nx, ny, nz )

      call stray( u0, uhat, khat, work, emfu, convf, &
          convb, nx, ny, nz, mx, my, mz )


  !---------------------------------------------
  !---------------------------------------------
  ! the first layer for magnatizaition



!open(33,file='test_element')
!
!do ii=1,3*Nx*Ny*Nz
!    write(33,*) cols(ii,:)
!enddo
!
!close(33)
  !------------------------------------------------

!c      open(7,file='emf1.7',form='unformatted')
!c      read(7) emf
!c      close(7)
!c
!c      err = 0.d0
!c      do k=1,nz3
!c         do j=1,ny
!c            do i=1,nx
!c               err = max( err, dabs( emf(i,j,k,1)-emfv(i,j,k,1)), &
!c                   dabs( emf(i,j,k,2)-emfv(i,j,k,2)), &
!c                   dabs( emf(i,j,k,3)-emfv(i,j,k,3)))
!c            enddo
!c         enddo
!c      enddo
!c      write(*,*) 'Error: ', err
!c      stop

      call digits( iter, m, nsteps ) !=================================================

      filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
          char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'

      call matlab( u0, dx, dy, dz, nx, ny, nz, &
          t, filename )

      filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
          char(48+m(3))//char(48+m(2))//char(48+m(1))//'.dat'

!c      call tecplot( u0, s0, gu, gs, x, y, z, nx, ny,
!c     $     nz, t, filename )

!c      write(*,*) diagu_pj
!c      pause
!c      write(*,*) upperdu_pj
!c      pause
!c      write(*,*) fmulu_pj
!c      pause

      open( 20, file = 'mumag.log' )

!c      write(*,*) 'Entering init'
!c      call fdate( filename )

      write(20,*) filename
      write(20,*)
      write(20,*) 'Micromagnetics Simulation'
      write(20,*)
      write(20,*) '   Gridpoints: ', nx,' x ', ny,' x (', nz, ')'
      write(20,*) '   Xmax = ', xreal * 1.d6, ' micrometer.'
      write(20,*) '   Ymax = ', yreal * 1.d6, ' micrometer.'
      write(20,*) '   Zmax = ', zreal * 1.d6, ' micrometer.'
      write(20,*)
      write(20,*)
      write(20,*) '   Length Scale = ', LengthScale * 1d6,' micrometer.'
      write(20,*) '   Time Scale = ', TimeScale, ' seconds.'
      write(20,*) '   Energy Scale = ', EnergyScale, ' Joules.'
      write(20,*)
      write(20,*) '   Anisotropy constant = ',fku,' Joules / meter'
      write(20,*) '   Exchange constant = ',ca,' Joules / meter^3'
      write(20,*) '   Saturation Magnetization = ',fms,' Ampere / meter'
      write(20,*)
      write(20,*) '   Spin Diffusion = ', d_fm, &
          ' meter^2 / second.'
      write(20,*) '   Spin Polarization Parameter 1 = ', beta1
      write(20,*) '   Spin Polarization Parameter 2 = ', beta2
      write(20,*) '   Spin-Flip Relaxation Length = ', lambda_SF * 1d9, &
          ' nanometer.'
      write(20,*) '   Spin-Flip Exchange Length = ', lambda_J * 1d9, &
          ' nanometer.'
      write(20,*)
      write(20,*) '   Bohr Magneton = ', Bohr, ' Ampere meter^2.'
      write(20,*) '   Electron Charge = ', Electron, ' Ampere second.'
      write(20,*)
      write(20,*) '   Electric Current = ', Current,' Ampere / meter^2.'
      write(20,*) '   Applied Field Strength = ', FieldStrength, &
          ' Tesla.'
      write(20,*) '   Ampere Field Strength = ', &
          zero_mu * LengthScale * Current, ' Tesla.'
      write(20,*)
      write(20,*) '   Lattice Constant = ', a0 * 1d9, ' nanometer.'
      write(20,*) '   Coupling parameter = ', a_J, ' Electron Volt.'
      write(20,*) '   1 Electron Volt = ', ElectronVolt, ' Joules.'
      write(20,*)
      write(20,*) '   dt = ', dt
      write(20,*)
      write(20,*) '   Q = ', q
      write(20,*) '   eps = ', eps
      write(20,*)
      write(20,*) '   a_fm = ', a_fm
      write(20,*) '   etaSF_SF = ', etaSF_SF
      write(20,*) '   sigma = ', sigma
      write(20,*) '   chi = ', chi
      write(20,*) '   acs = ', acs
      write(20,*)
      write(20,*) '   Time step: ', dt*TimeScale*1.d12, ' picoseconds.'
      write(20,*) '   Final time: ', tp*TimeScale*1.d9, ' nanoseconds.'
      write(20,*)
      write(20,*) '   Damping: ', dmpng
      write(20,*)

      call flush( 20 )

      write(*,*) 'k  --  t -- Maxnorm -- Minnorm -- Energy'

      energyold = 0.d0
      energynew = 0.d0

! for BDF1 initialization-------------------

        call bc( u0, nx, ny, nz )
!c----- variables for the magnetization in the first layer
!c

!!      do k=1,nz
!!         do j=1,ny
!!            do i=1,nx
!!               u0_prime(i,j,k,1) = u0(i,j,k,1)
!!               u0_prime(i,j,k,2) = u0(i,j,k,2)
!!               u0_prime(i,j,k,3) = u0(i,j,k,3)
!!            enddo
!!         enddo
!!      enddo

      call effective( u0, hu1, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )

!!      call bc( u0_prime, nx, ny, nz )

!c----- Compute Right Hand Side for BDF1
!c


!!      do k=1,nz
!!         do j=1,ny
!!            do i=1,nx
!!               u1_prime(i,j,k,1) = u1(i,j,k,1)
!!               u1_prime(i,j,k,2) = u1(i,j,k,2)
!!               u1_prime(i,j,k,3) = u1(i,j,k,3)
!!            enddo
!!         enddo
!!      enddo
!!
!!call bc( u1_prime, nx, ny, nz )

t1 = second()

      do i_hyst=1,1
!      do i_hyst=1,nfield/2+1 ! half loop
!      do i_hyst=1,nfield/2 ! half loop

!      do i_hyst=1,nfield ! full loop

!      do i_hyst=1,nfield+1 ! full loop

!       do i_hyst=1,100 ! test loop


!c      do i_hyst=2,4
!c      do i_hyst=2,2

!         t = 0.d0
         t = dt

!         if( i_hyst.eq.3 ) then
!            sigma = sigma0
!            iampere = 1
!            tp = 1.d-9 / TimeScale
!         tp = 1.6d-9 / TimeScale ! tp is 1.6ns
!         else
!            sigma = 0.d0
!            iampere = 0
!            tp = 1.d-9 / TimeScale
!         endif
!c
!c----- compute the external field
!c
!         if( iampere .eq. 1 ) then
!!c
!!c----- the ampere field is applied in the x direction
!!c
!            do k=1,nz
!               do j=1,ny
!                  do i=1,nx
!                     xtrnlu(i,j,k,1) = efield(1,i_hyst)+ampereu(i,j,k,1)
!                     xtrnlu(i,j,k,2) = efield(2,i_hyst)+ampereu(i,j,k,2)
!                     xtrnlu(i,j,k,3) = efield(3,i_hyst)+ampereu(i,j,k,3)
!                  enddo
!               enddo
!            enddo
!         else
            do k=1,nz
               do j=1,ny
                  do i=1,nx
                     xtrnlu(i,j,k,1) = efield(1,i_hyst)
                     xtrnlu(i,j,k,2) = efield(2,i_hyst)
                     xtrnlu(i,j,k,3) = efield(3,i_hyst)
                  enddo
               enddo
            enddo
!         endif

!---------------------------------------------------------
! for the matrix called Del (no damping)
!write(*,*) 'dx,dy,dz is'
!write(*,*) dx,dy,dz
!
!write(*,*) 'dt'
!write(*,*) dt

!write(*,*) 'Ax(1,1:4)'
!write(*,*) Ax(1,1:4)

!----------------------------------------------------
!----------------------------------------------------
!c
!c----- here starts the time iteration
!c
 1       continue ! to repeat the calculations for GSPM until the final time tp

         energyold = energynew

!        call bc( u0, nx, ny, nz )

        ! ----- add the initial energy -----
         if(iter .eq. 0) then
            call energy( u0, emfu, xtrnlu, nx, ny, &
                    nz, dx, dy, dz, q, eps, a_fm, etaSF_fm, &
                    chi, beta1, beta2, eng_magu )

            energynew = eng_magu(1) + eng_magu(2) + eng_magu(3)
            energynew = EnergyScale * energynew
!            twrite = iter * dt * TimeScale
            twrite = 0.d0

            write(11,*) twrite, energynew

         end if
! --------------------------------------

!c         write(*,*) 'Entering bc'
!         call bc( u0, s0, nx, ny, nz )
!        call bc( u0, nx, ny, nz )
!c
!c----- gspm for the magnetization in the two layers
!c
!c         write(*,*) 'Entering gspm'
!         call gspm( u0, u1, hu, gu, emfu, diagu_gm, fmulu_gm, &
!             upperdu_gm, diagu_pj, fmulu_pj, upperdu_pj, planf_be_u, &
!             planb_be_u, s0, khat, convf, convb, uhat, work, nx, ny, &
!             nz, mx, my, mz, dx, dy, dz, q, dmpng, chi, xtrnlu, dt )

!!!call gspm( u0, u1, hu, gu, emfu, diagu_gm, fmulu_gm, &
!!!             upperdu_gm, diagu_pj, fmulu_pj, upperdu_pj, planf_be_u, &
!!!             planb_be_u, khat, convf, convb, uhat, work, nx, ny, &
!!!             nz, mx, my, mz, dx, dy, dz, q, dmpng, chi, xtrnlu, dt )

!=================================================================
! the AMG solver
! for gspmAGG---------------------------------
!c
!c----- variables for the magnetization in the first layer
!c

!      do k=1,nz
!         do j=1,ny
!            do i=1,nx
!               u1(i,j,k,1) = u0(i,j,k,1)
!               u1(i,j,k,2) = u0(i,j,k,2)
!               u1(i,j,k,3) = u0(i,j,k,3)
!            enddo
!         enddo
!      enddo

!c
!c----- compute the effective field
!c
!c      write(*,*) 'Effective in'
     call effective( u0, hu1, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )

      ! call effective( u1, hu2, emfu, khat, &
          ! convf, convb, uhat, work, nx, ny, nz, &
          ! mx, my, mz, dx, dy, dz, q, chi, xtrnlu )

!c----- Compute Right Hand Side for BDF1
!c 2*u1(i,j,k,1)-u0(i,j,k,1)
!c 2*u1(i,j,k,1)-1.d0/2.d0*u0(i,j,k,1)

!------------------------------------------------------
! iteration for BDF2
!------------------------------------------------------
counter_sum = 0
  do kk=1,Nz
    do jj=1,Ny
       !****** c_11
        e(:,1)=(u0(1:nx,jj,kk,2))**2+&
             (u0(1:nx,jj,kk,3))**2
        call diag(Nx,e,Cy_1)
        Cy(1:Nx,1:Nx) = -eps*dmpng*matmul(Cy_1,Iy)
        Cz(1:Nx,1:Nx) = -eps*dmpng*matmul(Cy_1,Iz)
        EE(1:Nx,1:Nx) = one-eps*dmpng*matmul(Cy_1,Ax-Iy-Iz)
        !***** the c_12
!        write(*,*) '1 is'
!        write(*,11) Cy_1*Iy
!        write(*,*) '2 is'
!        write(*,11) matmul(Cy_1,Iy)
        e(:,1)=u0(1:nx,jj,kk,3)-dmpng*( &
             u0(1:nx,jj,kk,2))*(u0(1:nx,jj,kk,1))
!        write(*,*) e

        call diag(Nx,e,Cy_1)
!        write(*,11) Cy_1
!        11 format(1x,4F6.2)
        Cy(1:Nx,Nx+1:2*Nx)=-eps*matmul(Cy_1,Iy) ! here Cy is antisymmeric
        Cz(1:Nx,Nx+1:2*Nx)=-eps*matmul(Cy_1,Iz) ! here Cz is antisymmeric
        ! here EE is a matrix which is : D+E1; where D is diagonal and E1 is antisymmeric
        EE(1:Nx,Nx+1:2*Nx)=-eps*matmul(Cy_1,Ax-Iy-Iz) ! here is matrix multiply
!        write(*,11) EE(1:Nx,Nx+1:2*Nx)
        !****** the c_13
        e(:,1)=u0(1:nx,jj,kk,2)+dmpng*( &
        u0(1:nx,jj,kk,3))*(u0(1:nx,jj,kk,1))
        call diag(Nx,e,Cy_1)
        Cy(1:Nx,2*Nx+1:3*Nx)=eps*matmul(Cy_1,Iy)
        Cz(1:Nx,2*Nx+1:3*Nx)=eps*matmul(Cy_1,Iz)
        EE(1:Nx,2*Nx+1:3*Nx)=eps*matmul(Cy_1,Ax-Iy-Iz)
        !******* the c_21
        e(:,1)=u0(1:nx,jj,kk,3)+dmpng*( &
        u0(1:nx,jj,kk,1))*(u0(1:nx,jj,kk,2))
        call diag(Nx,e,Cy_1)
        Cy(Nx+1:2*Nx,1:Nx)=eps*matmul(Cy_1,Iy)
        Cz(Nx+1:2*Nx,1:Nx)=eps*matmul(Cy_1,Iz)
        EE(Nx+1:2*Nx,1:Nx)=eps*matmul(Cy_1,Ax-Iy-Iz)
        !****** the c_22
        e(:,1)=(u0(1:nx,jj,kk,3))**2+(u0(1:nx,jj,kk,1))**2
        call diag(Nx,e,Cy_1)
        Cy(Nx+1:2*Nx,Nx+1:2*Nx)=-eps*dmpng*matmul(Cy_1,Iy)
        Cz(Nx+1:2*Nx,Nx+1:2*Nx)=-eps*dmpng*matmul(Cy_1,Iz)
        EE(Nx+1:2*Nx,Nx+1:2*Nx)=one-eps*dmpng*matmul(Cy_1,Ax-Iy-Iz)
        !******* the c_23
        e(:,1)=u0(1:nx,jj,kk,1)-dmpng*( &
            u0(1:nx,jj,kk,3))*(u0(1:nx,jj,kk,2))
        call diag(Nx,e,Cy_1)
        Cy(Nx+1:2*Nx,2*Nx+1:3*Nx)=-eps*matmul(Cy_1,Iy)
        Cz(Nx+1:2*Nx,2*Nx+1:3*Nx)=-eps*matmul(Cy_1,Iz)
        EE(Nx+1:2*Nx,2*Nx+1:3*Nx)=-eps*matmul(Cy_1,Ax-Iy-Iz)
        !******* the c_31
        e(:,1)=u0(1:nx,jj,kk,2)-dmpng*(u0(1:nx,jj,kk,1)) &
            *(u0(1:nx,jj,kk,3))
        call diag(Nx,e,Cy_1)
        Cy(2*Nx+1:3*Nx,1:Nx)=-eps*matmul(Cy_1,Iy)
        Cz(2*Nx+1:3*Nx,1:Nx)=-eps*matmul(Cy_1,Iz)
        EE(2*Nx+1:3*Nx,1:Nx)=-eps*matmul(Cy_1,Ax-Iy-Iz)
        !****** the c_32
        e(:,1)=u0(1:nx,jj,kk,1)+dmpng*( &
            u0(1:nx,jj,kk,2))*(u0(1:nx,jj,kk,3))
        call diag(Nx,e,Cy_1)
        Cy(2*Nx+1:3*Nx,Nx+1:2*Nx)=eps*matmul(Cy_1,Iy)
        Cz(2*Nx+1:3*Nx,Nx+1:2*Nx)=eps*matmul(Cy_1,Iz)
        EE(2*Nx+1:3*Nx,Nx+1:2*Nx)=eps*matmul(Cy_1,Ax-Iy-Iz)
        !****** the c_33
        e(:,1)=(u0(1:nx,jj,kk,1))**2+(u0(1:nx,jj,kk,2))**2
        call diag(Nx,e,Cy_1)
        Cy(2*Nx+1:3*Nx,2*Nx+1:3*Nx)=-eps*dmpng*matmul(Cy_1,Iy)
        Cz(2*Nx+1:3*Nx,2*Nx+1:3*Nx)=-eps*dmpng*matmul(Cy_1,Iz)
        EE(2*Nx+1:3*Nx,2*Nx+1:3*Nx)=one-eps*dmpng*matmul(Cy_1,Ax-Iy-Iz)


        do ii=1,3*Nx
            counter = 0
            do ll=1,3*Nx
                if ( dabs(Cy(ii,ll)) .GT. EPSS ) then
                    ! consider the matrix Cy
                    if (jj.EQ.1) then
                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+ii
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx+ll-1
                        nonzero_value(counter+1,1) = Cy(ii,ll)
!                        write(10,*) (kk-1)*3*Nx*Ny+ii,(kk-1)*3*Nx*Ny+3*Nx+ll,Cy(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    elseif (jj.EQ.Ny) then
                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(Ny-1)+ii
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(Ny-2)+ll-1
                        nonzero_value(counter+1,1) = Cy(ii,ll)
!                        write(10,*) (kk-1)*3*Nx*Ny+3*Nx*(Ny-1)+ii,(kk-1)*3*Nx*Ny+3*Nx*(Ny-2)+ll,Cy(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    else
                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-2)+ll-1
                        nonzero_value(counter+1,1) = Cy(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1

                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*jj+ll-1
                        nonzero_value(counter+1,1) = Cy(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
!                        write(10,*) (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii,(kk-1)*3*Nx*Ny+3*Nx*(jj-2)+ll,Cy(ii,ll)
!                        write(10,*) (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii,(kk-1)*3*Nx*Ny+3*Nx*jj+ll,Cy(ii,ll)
!!                        counter = counter+2
                    endif
                endif

                if ( dabs(EE(ii,ll)) .GT. EPSS ) then
                    ! consider the matrix E in B1
                    if ( (kk.EQ.1).AND.(jj.EQ.1) ) then
                        nonzero_row_index(counter+1,1) = ii
                        nonzero_col_index(counter+1,1) = ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)
!                        write(10,*) ii,ll,EE(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif

                    if ( (kk.EQ.1).AND.(jj.EQ.Ny) ) then
                        nonzero_row_index(counter+1,1) = 3*Nx*(Ny-1)+ii
                        nonzero_col_index(counter+1,1) = 3*Nx*(Ny-1)+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)
!                        write(10,*) 3*Nx*(Ny-1)+ii,3*Nx*(Ny-1)+ll,EE(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                     ! consider the matrix E in B2
                    if ( (kk.EQ.Nz).AND.(jj.EQ.1).AND.(Nz.GE.2) ) then
                        nonzero_row_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+ii
                        nonzero_col_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)
!                        write(10,*) 3*Nx*Ny*(Nz-1)+ii,3*Nx*Ny*(Nz-1)+ll,EE(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif

                    if ( (kk.EQ.Nz).AND.(jj.EQ.Ny).AND.(Nz.GE.2) ) then
                        nonzero_row_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ii
                        nonzero_col_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)
!                        write(10,*) 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ii,3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ll,EE(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                endif

                if ( dabs(EE(ii,ll)-Cy(ii,ll)) .GT. EPSS ) then
                    ! consider the k element of B1 (jj=2,Ny-1)
                    if ( (jj.NE. 1).AND. (jj.NE.Ny).AND.(kk.EQ.1) ) then
                        nonzero_row_index(counter+1,1) = 3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)-Cy(ii,ll)
!                        write(10,*) 3*(jj-1)*Nx+ii,3*(jj-1)*Nx+ll, EE(ii,ll)-Cy(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                    ! consider the k element of B2 (jj=2,Ny-1)
                    if ( (jj.NE. 1).AND. (jj.NE.Ny).AND.(kk.EQ.Nz).AND.(Nz.GE.2) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)-Cy(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll, EE(ii,ll)-Cy(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                endif
                    ! for D
                if ( dabs(EE(ii,ll)-Cz(ii,ll)).GT.EPSS ) then
                    if ( (kk.NE.1).AND.(kk.NE.Nz).AND.(jj.EQ.1).AND.(Nz.GE.3) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+ii
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)-Cz(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+ii,3*(kk-1)*Nx*Ny+ll,EE(ii,ll)-Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif

                    if ( (kk.NE.1).AND.(kk.NE.Nz).AND.(jj.EQ.Ny).AND.(Nz.GE.3) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)-Cz(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll,EE(ii,ll)-Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                endif

                if ( dabs(EE(ii,ll)-Cy(ii,ll)-Cz(ii,ll)).GT.EPSS ) then
                    if ( (kk.NE.1).AND.(kk.NE.Nz).AND.(jj.NE.1).AND.(jj.NE.Ny).AND.(Nz.GE.3) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = EE(ii,ll)-Cy(ii,ll)-Cz(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll,EE(ii,ll)-Cy(ii,ll)-Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                endif
                ! for off-diagnal matrix Cz
                if ( dabs(Cz(ii,ll)).GT.EPSS ) then
                    ! for the 1st and last rows
                    if ( (kk.EQ.1).AND.(Nz.GE.2) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*kk*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = Cz(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*kk*Nx*Ny+3*(jj-1)*Nx+ll,Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif

                    if ( (kk.EQ.Nz).AND.(Nz.GE.2) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = Cz(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll,Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
                    endif
                    ! for k rows; (k=2,Nz)
                    if ( (kk.NE.1).AND.(kk.NE.Nz).AND.(Nz.GE.3) ) then
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*kk*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1

                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii
                        nonzero_col_index(counter+1,1) = 3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll-1
                        nonzero_value(counter+1,1) = Cz(ii,ll)
                        counter = counter+1
                        counter_sum = counter_sum+1
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*kk*Nx*Ny+3*(jj-1)*Nx+ll,Cz(ii,ll)
!                        write(10,*) 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii,3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll,Cz(ii,ll)
!!                        counter = counter+2
                    endif
                endif

            enddo
            mat_counter((kk-1)*3*Nx*Ny+(jj-1)*3*Nx+ii,1) = counter
            cols((kk-1)*3*Nx*Ny+(jj-1)*3*Nx+ii,1:counter) = nonzero_col_index(1:counter,1)
            cols((kk-1)*3*Nx*Ny+(jj-1)*3*Nx+ii,counter+1:) = 0 ! the rest to avoid out of memory
            values((kk-1)*3*Nx*Ny+(jj-1)*3*Nx+ii,1:counter) = nonzero_value(1:counter,1)
        enddo


    enddo
enddo


      do k=1,nz
         do j=1,ny
            do i=1,nx
               gu(i,j,k,1) = u0(i,j,k,1) - dt * (u0(i,j,k,2)*hu1(i,j,k,3)-u0(i,j,k,3)*hu1(i,j,k,2))- &
                             dmpng*dt*(u0(i,j,k,2)*(u0(i,j,k,1)*hu1(i,j,k,2)-u0(i,j,k,2)*hu1(i,j,k,1))-u0(i,j,k,3)*&
                             (u0(i,j,k,3)*hu1(i,j,k,1)-u0(i,j,k,1)*hu1(i,j,k,3) ) )

               gu(i,j,k,2) = u0(i,j,k,2) - dt * (u0(i,j,k,3)*hu1(i,j,k,1)-u0(i,j,k,1)*hu1(i,j,k,3))- &
                             dmpng*dt*(u0(i,j,k,3)*(u0(i,j,k,2)*hu1(i,j,k,3)-u0(i,j,k,3)*hu1(i,j,k,2))-u0(i,j,k,1)*&
                             (u0(i,j,k,1)*hu1(i,j,k,2)-u0(i,j,k,2)*hu1(i,j,k,1) ) )

               gu(i,j,k,3) = u0(i,j,k,3) - dt * (u0(i,j,k,1)*hu1(i,j,k,2)-u0(i,j,k,2)*hu1(i,j,k,1))- &
                             dmpng*dt*(u0(i,j,k,1)*(u0(i,j,k,3)*hu1(i,j,k,1)-u0(i,j,k,1)*hu1(i,j,k,3))-u0(i,j,k,2)*&
                             (u0(i,j,k,2)*hu1(i,j,k,3)-u0(i,j,k,3)*hu1(i,j,k,2) ) )

            enddo
            ggu(1:Nx,j,k) = gu(:,j,k,1)
            ggu(Nx+1:2*Nx,j,k) = gu(:,j,k,2)
            ggu(2*Nx+1:3*Nx,j,k) = gu(:,j,k,3)
         enddo
      enddo

      rhs = reshape(ggu,(/3*Nx*Ny*Nz,1/))

      call BDF2GMRES_solver(MAX_LOCAL_SIZE,HYPRE_PARCSR,local_size, extra,&
            ilower,iupper,mpi_comm,nnl,nnx,cols,values,mat_counter,rhs,print_solution,&
            solver_id,myid,g)

      m_inter = reshape(g,(/3*Nx,Ny,Nz/))

      gu(:,:,:,1) = m_inter(1:Nx,:,:)
      gu(:,:,:,2) = m_inter(Nx+1:2*Nx,:,:)
      gu(:,:,:,3) = m_inter(2*Nx+1:3*Nx,:,:)

!c
!c----- Project to the unit sphere
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               tmp = dsqrt(gu(i,j,k,1)**2+gu(i,j,k,2)**2 &
                   +gu(i,j,k,3)**2)
               u1(i,j,k,1) = gu(i,j,k,1) / tmp
               u1(i,j,k,2) = gu(i,j,k,2) / tmp
               u1(i,j,k,3) = gu(i,j,k,3) / tmp
            enddo
         enddo
      enddo

call bc( u1, nx, ny, nz )

!c      write(*,*) 'Effective out'


!=================================================================

!c         write(*,*) 'Exitting gspm'
!c
!c----- boundary conditions
!c
!c      write(*,*) 'Entering bc'
!         call bc( u1, nx, ny, nz )
!c
!c----- solve for the spin accumulation
!c
!      write(*,*) 'Solve for spin accumulation: Input
!         call reducedmomentsplitting(u1, s0, s1, gs, Js0, Js1, gJs, &
!          diags, upperds, fmuls, ratio, &
!          planf_be_s, planb_be_s, sx, sy, sz, sxm, sym, szm, nx, ny, &
!          nz, dt, dx, dy, dz, beta, a_fm, etaSF_fm, etaJ_fm, sigma )
!c
!c----- update
!c
!u0_prime = u1_prime
!u1_prime = gu ! without projection term

!!!         do k=1,nz
!!!            do j=1,ny
!!!               do i=1,nx
!!!                  u0_prime(i,j,k,1) = u1_prime(i,j,k,1)
!!!                  u0_prime(i,j,k,2) = u1_prime(i,j,k,2)
!!!                  u0_prime(i,j,k,3) = u1_prime(i,j,k,3)
!!!               enddo
!!!            enddo
!!!         enddo

!!!         do k=1,nz
!!!            do j=1,ny
!!!               do i=1,nx
!!!                  u1_prime(i,j,k,1) = gu(i,j,k,1)
!!!                  u1_prime(i,j,k,2) = gu(i,j,k,2)
!!!                  u1_prime(i,j,k,3) = gu(i,j,k,3)
!!!               enddo
!!!            enddo
!!!         enddo

         do k=1,nz
            do j=1,ny
               do i=1,nx
                  u0(i,j,k,1) = u1(i,j,k,1)
                  u0(i,j,k,2) = u1(i,j,k,2)
                  u0(i,j,k,3) = u1(i,j,k,3)
               enddo
            enddo
         enddo

         ! do k=1,nz
            ! do j=1,ny
               ! do i=1,nx
                  ! u1(i,j,k,1) = u2(i,j,k,1)
                  ! u1(i,j,k,2) = u2(i,j,k,2)
                  ! u1(i,j,k,3) = u2(i,j,k,3)
               ! enddo
            ! enddo
         ! enddo

!!         call bc( u0_prime, nx, ny, nz )
!!         call bc( u1_prime, nx, ny, nz )
         call bc( u0, nx, ny, nz )
         ! call bc( u1, nx, ny, nz )
!         do k=1,nz
!            do j=1,ny
!               do i=1,nx
!                  s0(i,j,k,1) = s1(i,j,k,1)
!                  s0(i,j,k,2) = s1(i,j,k,2)
!                  s0(i,j,k,3) = s1(i,j,k,3)
!               enddo
!            enddo
!         enddo

         t = t + dt
         iter = iter + 1
!c
!c----- compute the energy
!c
!c         if( mod(iter,nsteps) .eq. 0 ) then
!c      write(*,*) 'Entering energy'
!            call energy( u0, s0, emfu, xtrnlu, nx, ny, &
!                nz, dx, dy, dz, q, eps, a_fm, etaSF_fm, &
!                chi, beta1, beta2, eng_magu, eng_cplu, eng_spin )
    call energy( u1, emfu, xtrnlu, nx, ny, &
                nz, dx, dy, dz, q, eps, a_fm, etaSF_fm, &
                chi, beta1, beta2, eng_magu )
!c      write(*,*) 'Exit energy'

!c      write(*,*) 'Exit energy'

!            energynew = eng_magu(1) + eng_magu(2) + eng_magu(3) + &
!                eng_cplu +  eng_spin(1) + eng_spin(2)
            energynew = eng_magu(1) + eng_magu(2) + eng_magu(3)
            energynew = EnergyScale * energynew

!            twrite = iter * dt * TimeScale
            twrite = t * TimeScale

!         if( mod(iter,nsteps) .eq. 0 ) then
         if( mod(iter+1,nsteps) .eq. 0 ) then
!c
!c----- compute the magnetization
!c
!!            write(*,*) twrite, energynew
!!            write(*,*) eng_magu(1),eng_magu(2),eng_magu(3)
!!            write(*,*) eng_cplu
!!            write(*,*) eng_spin(1),eng_spin(2)

            write(11,*) twrite, energynew
!            write(12,*) twrite, EnergyScale * eng_magu(1)
!            write(13,*) twrite, EnergyScale * eng_magu(2)
!            write(14,*) twrite, EnergyScale * eng_magu(3)
!            write(15,*) twrite, EnergyScale * eng_cplu
!
!            write(32,*) twrite, &
!                EnergyScale * ( eng_spin(1) + eng_spin(2) )

            magu(1) = 0.d0
            magu(2) = 0.d0
            magu(3) = 0.d0

            do k=1,nz
               do j=1,ny
                  do i=1,nx
                     magu(1) = magu(1) + u1(i,j,k,1)
                     magu(2) = magu(2) + u1(i,j,k,2)
                     magu(3) = magu(3) + u1(i,j,k,3)
                  enddo
               enddo
            enddo
            magu(1) = magu(1) / (nx*ny*nz)
            magu(2) = magu(2) / (nx*ny*nz)
            magu(3) = magu(3) / (nx*ny*nz)

            write(16,1000) twrite, magu(1), magu(2), magu(3)
!            write(36,1000) twrite, s1(nx/2,ny/2,nz/2,1), &
!                s1(nx/2,ny/2,nz/2,2), s1(nx/2,ny/2,nz/2,3)
!c
!c----- write to a file
!c
!!if (dabs(efield(1,i_hyst) ) .GT. 1.d-7 ) then
!!            call digits( iter, m, nsteps )
!!
!!            filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
!!                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'
!!
!!            call matlab( u2, dx, dy, dz, nx, ny, &
!!                nz, t, filename )
!!else
!!            call digits( iter, m, nsteps )
!!
!!            filename = 'RemanentData'//char(m(5)+48)//char(m(4)+48)// &
!!                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'
!!
!!            call matlab( u2, dx, dy, dz, nx, ny, &
!!                nz, t, filename )
!!
!!endif

!!if (dabs(efield(2,i_hyst) ) .GT. 1.d-7 ) then
!!            call digits( iter, m, nsteps )
!!
!!            filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
!!                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'
!!
!!            call matlab( u2, dx, dy, dz, nx, ny, &
!!                nz, t, filename )
!!else
!!            call digits( iter, m, nsteps )
!!
!!            filename = 'RemanentData'//char(m(5)+48)//char(m(4)+48)// &
!!                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'
!!
!!            call matlab( u2, dx, dy, dz, nx, ny, &
!!                nz, t, filename )
!!
!!endif

!if (dabs(efield(3,i_hyst) ) .GT. 1.d-7 ) then ! for z axis
!            call digits( iter, m, nsteps )
!
!            filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
!                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'
!
!            call matlab( u1, dx, dy, dz, nx, ny, &
!                nz, t, filename )
!else
!            call digits( iter, m, nsteps )
!
!            filename = 'RemanentData'//char(m(5)+48)//char(m(4)+48)// &
!                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'
!
!            call matlab( u1, dx, dy, dz, nx, ny, &
!                nz, t, filename )
!
!endif

            call digits( iter, m, nsteps )

            filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
                char(48+m(3))//char(48+m(2))//char(48+m(1))//'.m'

            call matlab( u1, dx, dy, dz, nx, ny, &
                nz, t, filename )

!      filename = 'mdata'//char(m(5)+48)//char(m(4)+48)// &
!          char(48+m(3))//char(48+m(2))//char(48+m(1))//'.dat'

!c      call tecplot( u0, s0, gu, gs, x, y, z, nx, ny, &
!c          nz, t, filename )
!c
!c----- end conditions
!c
!c            write(*,*) dabs(1.d0-energyold/energynew), t, tp
!c            pause

!            if((dabs(1.d0-energyold/energynew).gt.hyst_tolerance).and. &
!                (t.lt.tp)) goto 1

!    if((dabs(1.d0-energyold/energynew).gt.hyst_tolerance)) goto 1

            if( t .lt. tp ) goto 1 ! this is for the loop of time layer
!c            if( dabs(t-tp) .gt. .5d0*dt ) goto 1
!c
!c---- if it continues here, we write the magnetization in the loop files
!c
            write( 9,1000) efield(1,i_hyst), magu(1), magu(2), magu(3)
            write(10,1000) efield(1,i_hyst), magv(1), magv(2), magv(3)

!!            write( 9,1000) efield(2,i_hyst), magu(1), magu(2), magu(3)
!!            write(10,1000) efield(2,i_hyst), magv(1), magv(2), magv(3)


!            if (dabs(efield(1,i_hyst) ) .LE. 1.d-7 ) then
!                write( 101,1000) efield(1,i_hyst), magu(1), magu(2), magu(3)
!            endif

            call flush( 9 )
            call flush( 10 )
            call flush( 101 )

         else
!c
!c----- if mod(iter,nsteps) .ne. 0, goto 1
            goto 1
         endif
!c
!c----- if we get here, the energy has not changed much in nsteps,
!c     so we change the field, but first we store the current state
!c
!         call digits( i_hyst, m, 1 )

!         filename = 'out'//char(m(5)+48)//char(m(4)+48)//
!     $        char(48+m(3))//char(48+m(2))//char(48+m(1))//'.7'

!         open(7,file=filename, form='unformatted')
!         write(7) u1
!         write(7) v1
!         write(7) s1
!         close(7)

         write(*,*)
         write(*,*) '***************************************'
         write(*,*) '        Changing external field         ', i_hyst
         write(*,*) '***************************************'
         write(*,*)

      enddo

      t2 = second()
      write(*,*) 'Hysteresis loop done in ', t2-t1, ' seconds.'
!c
!c----- after all the computations are finishes, I write the current
!c     state for initialization purposes
!c
      open(7,file='fort.7', form='unformatted')
      write(7) t, iter+1
      write(7) u1
      write(7) v1
      write(7) s1
      close(7)
!c
!c----- close all the files that are open
!c
      close(9)
      close(10)
      close(101)

      close(11)
      close(12)
      close(13)
      close(14)
      close(15)
      close(16)

      close(22)
      close(23)
      close(24)
      close(25)
      close(26)

      close(32)
!c
!c----- write the end date in mumag.log
!c
!c      call fdate( filename )
      write(20,*) filename
      close(20)


 1000 format( 2x, 4(e17.10,1x) )

      call MPI_Finalize(ierr)

      stop
      end

!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine matlab(u, dx, dy, dz, nx, ny, nz, &
          t, filename)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision u( 0:nx+1, 0:ny+1, 0:nz+1, 3 )
!      double precision s( 0:nx+1, 0:ny+1, 0:nz+1, 3 )
      character filename*60

      write(*,*) 'Opening file ', filename, '....'
      open(7,file=filename)
!c
!c----- We write output suitable for matlab
!c
      write(7,102) t

      write(7,102) dx
      write(7,102) dy
      write(7,102) dz

      write(7,*) nx
      write(7,*) ny
      write(7,*) nz

      do k=1,nz
         do j=1,ny
            do i=1,nx
               write(7,101) u(i,j,k,1),u(i,j,k,2),u(i,j,k,3)
            enddo
         enddo
      enddo

!      do k=1,nz
!         do j=1,ny
!            do i=1,nx
!               write(7,101) s(i,j,k,1),s(i,j,k,2),s(i,j,k,3)
!            enddo
!         enddo
!      enddo

      write(*,*) 'Closing file ', filename, '....'
      close(7)

 101  format (3(e22.16,2x))
 102  format (e22.16,2x)
 103  format (i10,2x)

      return
      end
!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine digits( int, m, module )

      integer m( 5 ), ii( 5 ), module
      integer int

      ii(1) = int / module
      m(1) = mod(ii(1),10)

      do k = 2,5
         ii(k) = ii(k-1) / 10
         m(k) = mod( ii(k), 10 )
      enddo

      return
      end
!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine tecplot( u, gu, x, y, z, nx, ny, &
          nz, t, filename )
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision u( 0:nx+1, 0:ny+1, 0:nz+1, 3 )
!      double precision s( 0:nx+1, 0:ny+1, 0:nz+1, 3 )

      double precision gu( nx, ny, nz, 3 )
!      double precision gs( nx, ny, nz, 3 )

      double precision x( nx )
      double precision y( ny )
      double precision z (nz)

      character filename*60
      character*1 NULLCHR

      write(*,*) 'Opening file ', filename, '....'
      open(7,file=filename)

      write(7,*) 'TITLE = "Spin Transport in Multilayers"'
      write(7,*) 'VARIABLES = "X", "Y", "Z", "U1", "U2", "U3"'
      write(7,1) nx, ny, nz
 1    format('ZONE DATAPACKING=POINT T="Bottom Layer" I=',i3,' J=',i3 &
          ,' K=',i3,' ZONETYPE = ORDERED')

      do k=1,nz
         do j=1,ny
            do i=1,nx
               write(7,1000) x(i),y(j),z(k),u(i,j,k,1),u(i,j,k,2), &
                   u(i,j,k,3)
            enddo
         enddo
      enddo

      write(7,3) nx, ny, nz
 3    format('ZONE DATAPACKING=POINT T="Spin" I=',i3,' J=',i3,' K=',i3, &
          ' ZONETYPE = ORDERED')
!
!      do k=1,nz
!         do j=1,ny
!            do i=1,nx
!               write(7,1000) x(i),y(j),z(k),s(i,j,k,1),s(i,j,k,2), &
!                   s(i,j,k,3)
!            enddo
!         enddo
!      enddo

      close(7)

 1000 format(1x,6(f10.6,1x))

      return
      end
