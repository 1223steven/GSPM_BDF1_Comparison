!c
!c----- compute the ampere field due to a uniform current in x direction
!c      parallel to the magnetic layer
!c
      subroutine amp( ampereu, work, link, nx, ny, nz, &
          nmax, x, y, z, xmax, ymax, zmax )
      implicit double precision(a-h, o-z)
      implicit integer(i-n)

      external ay
      external az

      parameter( tol = 1.d-10, nodes = 32 )

      double precision ampereu(nx, ny, nz, 3)
      double precision work( nmax )

      integer link( nmax )
      double precision fnodes( nodes ), weight( nodes )

      double precision x(nx), y(ny), z(nz)

      common/param2/pi, xm, ym, zm, xi, yj, zk
!c
!c----- initialization
!c
      pi = 4.d0 * datan( 1.d0 )

      xm = xmax
      ym = ymax
      zm = zmax
!c
!c----- ampere field on the first layer
!c
      t1 = second()
      do k=1,nz
         zk = z(k)
         do j=1,ny
            yj = y(j)
            do i=1,nx
               xi = x(i)

               ampereu(i,j,k,1) = 0.d0

               ampereu(i,j,k,2) = adapgaus1d( 0.d0, xmax, work, link, &
                   nmax, fnodes, weight, nodes, tol, ay )

               ampereu(i,j,k,3) = adapgaus1d( 0.d0, xmax, work, link, &
                   nmax, fnodes, weight, nodes, tol, az )
            enddo
         enddo
      enddo
      t2 = second()
      write(*,*) 'Ampere field in first layer computed in ', t2-t1, &
          ' seconds.'
!c
!c----- write the ampere field to a file
!c
      open(7,file='ampere.7',form='unformatted')
      write(7) ampereu
      close(7)

      return
      end
!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      double precision function ay( p )
      implicit double precision(a-h,o-z)
      implicit integer( i-n )

      common/param2/pi, xmax, ymax, zmax, xi, yj, zk

      tmp1 = dsqrt( (xi-p)**2 + zk**2 )
      tmp2 = dsqrt( (xi-p)**2 + (zk-zmax)**2 )

      tt1 = yj/tmp1 + dsqrt(1.d0 + (yj/tmp1)**2)
      tt2 = (ymax-yj)/tmp1 + dsqrt(1.d0 + ((ymax-yj)/tmp1)**2)

      tt3 = yj/tmp2 + dsqrt(1.d0 + (yj/tmp2)**2)
      tt4 = (ymax-yj)/tmp2 + dsqrt(1.d0 + ((ymax-yj)/tmp2)**2)

      ay = dlog( tt1*tt2 / (tt3*tt4) ) / (4.d0 * pi)

      return
      end
!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      double precision function az( p )
      implicit double precision(a-h,o-z)
      implicit integer( i-n )

      common/param2/pi, xmax, ymax, zmax, xi, yj, zk

      tmp1 = dsqrt( (xi-p)**2 + (yj-ymax)**2 )
      tmp2 = dsqrt( (xi-p)**2 + yj**2 )

      tt1 = zk/tmp1 + dsqrt(1.d0 + (zk/tmp1)**2)
      tt2 = (zmax-zk)/tmp1 + dsqrt(1.d0 + ((zmax-zk)/tmp1)**2)

      tt3 = zk/tmp2 + dsqrt(1.d0 + (zk/tmp2)**2)
      tt4 = (zmax-zk)/tmp2 + dsqrt(1.d0 + ((zmax-zk)/tmp2)**2)

      az = dlog( tt1*tt2 / (tt3*tt4) ) / (4.d0 * pi)

      return
      end

