      subroutine solve_penta( b, diag, fmul1, fmul2, upperd1, upperd2, &
          planf, planb, nx, ny, nz )
      implicit double precision( a-h, o-z )
      implicit integer( i-n )

      double precision b(nx, ny, nz, 3)
      double precision diag(nx, ny, nz), upperd1(nx, ny, nz), &
          upperd2(nx, ny, nz)
      double precision fmul1(nx, ny, nz), fmul2(nx, ny, nz)
      integer*8 planf(nz,3), planb(nz,3)

      do l=1,3
!c
!c----- compute the fft
!c

         do k=1,nz
            call dfftw_executed( planb(k,l) )
         enddo
!c
!c----- the LU has been performed already, so fmul1, fmul2, and fmul3 have
!c     the multipliers
!c
         do k=2,nz-1
            do j=1,ny
               do i=1,nx
                  b(i,j,k,l) = b(i,j,k,l) - fmul1(i,j,k-1)*b(i,j,k-1,l)
                  b(i,j,k+1,l) = b(i,j,k+1,l) &
                      - fmul2(i,j,k-1)*b(i,j,k-1,l)
               enddo
            enddo
         enddo

         k=nz
         do j=1,ny
            do i=1,nx
               b(i,j,k,l) = b(i,j,k,l) - fmul1(i,j,k-1)*b(i,j,k-1,l)
            enddo
         enddo

         do j=1,ny
            do i=1,nx
               b(i,j,nz,l) = b(i,j,nz,l) / diag(i,j,nz)
               b(i,j,nz-1,l) = (b(i,j,nz-1,l) &
                   - upperd1(i,j,nz-1)*b(i,j,nz,l))/diag(i,j,nz-1)
            enddo
         enddo

         do k=nz-2,1,-1
            do j=1,ny
               do i=1,nx
                  b(i,j,k,l) = (b(i,j,k,l) - upperd1(i,j,k)*b(i,j,k+1,l) &
                      - upperd2(i,j,k)*b(i,j,k+2,l))/diag(i,j,k)
               enddo
            enddo
         enddo

         do k=1,nz
            call dfftw_execute( planf(k,l) )
         enddo

      enddo

      return
      end
