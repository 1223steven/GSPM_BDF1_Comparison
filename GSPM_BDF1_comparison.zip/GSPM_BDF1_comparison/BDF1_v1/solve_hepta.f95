      subroutine solve_hepta( b, diag, fmul1, fmul2, fmul3, upperd1, &
          upperd2, upperd3, planf, planb, nx, ny, nz )
      implicit double precision( a-h, o-z )
      implicit integer( i-n )

      double precision b(nx, ny, nz, 3)
      double precision diag(nx, ny, nz), upperd1(nx, ny, nz), &
          upperd2(nx, ny, nz), upperd3(nx, ny, nz)
      double precision fmul1(nx, ny, nz), fmul2(nx, ny, nz), &
          fmul3(nx, ny, nz)
      integer*8 planf(nz,3), planb(nz,3)
!c
!c----- the LU has been performed already, so fmul1 and fmul2 have
!c     the multipliers
!c
      do l=1,3

         do k=1,nz
            call dfftw_execute( planb(k,l) )
         enddo

         do k=2,nz-2
            do j=1,ny
               do i=1,nx
                  b(i,j,k,l) = b(i,j,k,l) - fmul1(i,j,k-1)*b(i,j,k-1,l)
                  b(i,j,k+1,l) = b(i,j,k+1,l) &
                      - fmul2(i,j,k-1)*b(i,j,k-1,l)
                  b(i,j,k+2,l) = b(i,j,k+2,l) &
                      - fmul3(i,j,k-1)*b(i,j,k-1,l)
               enddo
            enddo
         enddo

         k=nz-1
         do j=1,ny
            do i=1,nx
               b(i,j,k,l) = b(i,j,k,l) - fmul1(i,j,k-1)*b(i,j,k-1,l)
               b(i,j,k+1,l) = b(i,j,k+1,l) - fmul2(i,j,k-1)*b(i,j,k-1,l)
            enddo
         enddo

         k=nz
         do j=1,ny
            do i=1,nx
               b(i,j,k,l) = b(i,j,k,l) - fmul1(i,j,k-1)*b(i,j,k-1,l)
            enddo
         enddo

         do j=1,ny
            do i=1,nx
               b(i,j,nz,l) = b(i,j,nz,l) / diag(i,j,nz)
               b(i,j,nz-1,l) = (b(i,j,nz-1,l) &
                   - upperd1(i,j,nz-1)*b(i,j,nz,l))/diag(i,j,nz-1)
               b(i,j,nz-2,l) = (b(i,j,nz-2,l) &
                   - upperd1(i,j,nz-2)*b(i,j,nz-1,l)- &
                   upperd2(i,j,nz-2)*b(i,j,nz,l))/diag(i,j,nz-2)
            enddo
         enddo

         do k=nz-3,1,-1
            do j=1,ny
               do i=1,nx
                  b(i,j,k,l) = (b(i,j,k,l) &
                      - upperd1(i,j,k)*b(i,j,k+1,l) &
                      - upperd2(i,j,k)*b(i,j,k+2,l) &
                      - upperd3(i,j,k)*b(i,j,k+3,l))/diag(i,j,k)
               enddo
            enddo
         enddo

         do k=1,nz
            call dfftw_execute( planf(k,l) )
         enddo
!c
!c----- rescale
!c
         scale = 1.d0 / (4*nx*ny)
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  b(i,j,k,l) = scale * b(i,j,k,l)
               enddo
            enddo
         enddo

      enddo

      return
      end
