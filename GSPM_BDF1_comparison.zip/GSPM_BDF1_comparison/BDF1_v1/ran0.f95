      function ran0(idum)
      integer idum, ia, im, iq, ir, mask
      real*8 ran0, am
      parameter(ia=16807,im=2147483647,am=1.d0/im,iq=127773,ir=2836,&
          mask=123459876)
!c
!c     Minimal random generator of Park and Miller. Returns a uniform
!c     random deviate between 0.0 and 1.0. Set or reset idum to any integer
!c     value (except the unlikely value MASK) to initialize the sequence;
!c     idum must not be alteres between calls for succesive deviates
!c     in a sequence
!c
      integer k
      idum = ieor(idum,mask)
      k = idum/iq
      idum = ia*(idum-k*iq)-ir*k
      if (idum.lt.0) idum = idum+im
      ran0 = am*idum
      idum = ieor(idum,mask)
      return
      end
