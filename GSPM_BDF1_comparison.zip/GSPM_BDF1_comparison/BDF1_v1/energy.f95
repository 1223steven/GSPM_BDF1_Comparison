      subroutine energy( u, emfu, xtrnlu, nx, ny, &
          nz, dx, dy, dz, q, eps, a_fm, etaSF_fm, &
          chi, beta1, beta2, eng_magu )!, eng_cplu, eng_spin )
      implicit double precision(a-h, o-z)
      implicit integer(i-n)
!c
!c----- variables for the magnetization in the first layer
!c
      double precision u(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision emfu(nx, ny, nz, 3)
      double precision xtrnlu(nx, ny, nz, 3)
!c
!c----- variables for the spin accumulation
!c
!!!      double precision s(0:nx+1, 0:ny+1, 0:nz+1, 3)
!c
!c----- energies
!c
      double precision eng_magu(3), eng_cplu!, eng_spin(2)
!c
!c----- Landau-Lifshitz energy
!c
!c----- anisotropy energy in u
!c
      eng_magu(1) = 0.d0
      do k=1,nz
         do j=1,ny
            do i=1,nx
               eng_magu(1) = eng_magu(1) + u(i,j,k,2)**2 + u(i,j,k,3)**2
            enddo
         enddo
      enddo
      eng_magu(1) = dx * dy * dz * q * eng_magu(1)
!c
!c----- exchange energy in u
!c
      eng_magu(2) = 0.d0
      do k=1,nz
         do j=1,ny
            do i=1,nx
               eng_magu(2) = eng_magu(2) + &
                   ((u(i+1,j,k,1)-u(i-1,j,k,1))/(2.d0*dx))**2+ &
                   ((u(i+1,j,k,2)-u(i-1,j,k,2))/(2.d0*dx))**2+ &
                   ((u(i+1,j,k,3)-u(i-1,j,k,3))/(2.d0*dx))**2+ &
                   ((u(i,j+1,k,1)-u(i,j-1,k,1))/(2.d0*dy))**2+ &
                   ((u(i,j+1,k,2)-u(i,j-1,k,2))/(2.d0*dy))**2+ &
                   ((u(i,j+1,k,3)-u(i,j-1,k,3))/(2.d0*dy))**2+ &
                   ((u(i,j,k+1,1)-u(i,j,k-1,1))/(2.d0*dz))**2+ &
                   ((u(i,j,k+1,2)-u(i,j,k-1,2))/(2.d0*dz))**2+ &
                   ((u(i,j,k+1,3)-u(i,j,k-1,3))/(2.d0*dz))**2
            enddo
         enddo
      enddo
      eng_magu(2) = dx * dy * dz * eps * eng_magu(2)
!c
!c----- stray + external field energy in u
!c
      eng_magu(3) = 0.d0
      do k=1,nz
         do j=1,ny
            do i=1,nx
               eng_magu(3) = eng_magu(3) + &
                   (emfu(i,j,k,1)+2.d0*xtrnlu(i,j,k,1))*u(i,j,k,1)+ &
                   (emfu(i,j,k,2)+2.d0*xtrnlu(i,j,k,2))*u(i,j,k,2)+ &
                   (emfu(i,j,k,3)+2.d0*xtrnlu(i,j,k,3))*u(i,j,k,3)
            enddo
         enddo
      enddo
      eng_magu(3) = - dx * dy * dz * .5d0 * eng_magu(3)
!c
!c----- coupling energy between spin and u
!c
!!!      eng_cplu = 0.d0
!!!      do k=1,nz
!!!         do j=1,ny
!!!            do i=1,nx
!!!               eng_cplu = eng_cplu + u(i,j,k,1)*s(i,j,k,1) + &
!!!                   u(i,j,k,2)*s(i,j,k,2) + u(i,j,k,3)*s(i,j,k,3)
!!!            enddo
!!!         enddo
!!!      enddo
!!!      eng_cplu = - chi * dx * dy * dz * eng_cplu
!c
!c----- energy of the spin accumulation
!c
!!!      eng_spin(1) = 0.d0
!!!      do k=1,nz
!!!         do j=1,ny
!!!            do i=1,nx
!!!               eng_spin(1) = eng_spin(1) + a_fm * ( &
!!!                   ((s(i+1,j,k,1)-s(i-1,j,k,1))/(2.d0*dx))**2+ &
!!!                   ((s(i+1,j,k,2)-s(i-1,j,k,2))/(2.d0*dx))**2+ &
!!!                   ((s(i+1,j,k,3)-s(i-1,j,k,3))/(2.d0*dx))**2+ &
!!!                   ((s(i,j+1,k,1)-s(i,j-1,k,1))/(2.d0*dy))**2+ &
!!!                   ((s(i,j+1,k,2)-s(i,j-1,k,2))/(2.d0*dy))**2+ &
!!!                   ((s(i,j+1,k,3)-s(i,j-1,k,3))/(2.d0*dy))**2+ &
!!!                   ((s(i,j,k+1,1)-s(i,j,k-1,1))/(2.d0*dz))**2+ &
!!!                   ((s(i,j,k+1,2)-s(i,j,k-1,2))/(2.d0*dz))**2+ &
!!!                   ((s(i,j,k+1,3)-s(i,j,k-1,3))/(2.d0*dz))**2)
!!!            enddo
!!!         enddo
!!!      enddo
!!!
!!!      eng_spin(1) = dx * dy * dz * eng_spin(1)
!!!
!!!      eng_spin(2) = 0.d0
!!!      do k=1,nz
!!!         do j=1,ny
!!!            do i=1,nx
!!!               eng_spin(2) = eng_spin(2) + etaSF_fm*( &
!!!                   s(i,j,k,1)**2+s(i,j,k,2)**2+s(i,j,k,3)**2)
!!!            enddo
!!!         enddo
!!!      enddo
!!!
!!!      eng_spin(2) = dx * dy * dz * eng_spin(2)

      return
      end

