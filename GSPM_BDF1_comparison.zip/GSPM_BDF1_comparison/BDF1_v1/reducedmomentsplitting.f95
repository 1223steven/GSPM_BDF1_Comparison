!c
!c----- fully second order
!c
      subroutine reducedmomentsplitting(u, s0, s1, gs, Js0, Js1, gJs, &
          diags, upperds, fmuls, ratio, &
          planf_be_s, planb_be_s, sx, sy, sz, sxm, sym, szm, nx, ny, &
          nz, dt, dx, dy, dz, beta, a_fm, etaSF_fm, etaJ_fm, sigma )
      implicit double precision(a-h, o-z)
      implicit integer(i-n)
!c
!c----- variables for the magnetization in the first layer
!c
      double precision u(0:nx+1, 0:ny+1, 0:nz+1, 3)
!c
!c----- variables for the spin accumulation
!c
      double precision s0(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision s1(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision gs(nx, ny, nz, 3)

      double precision Js0(0:nx+1, 0:ny+1, 0:nz+1, 3, 3)
      double precision Js1(0:nx+1, 0:ny+1, 0:nz+1, 3, 3)
      double precision gJs(0:nx+1, 0:ny+1, 0:nz+1, 3, 3)
!c
!c----- variables for the backward euler (pentadiagonal system)
!c
      double precision diags(nx, ny, nz), upperds(nx, ny, nz), &
          fmuls(nx, ny, nz)
!c
!c----- variables for the Fourier transform of s in the plane
!c
      integer*8 planf_be_s(nz, 3), planb_be_s(nz, 3)
!c
!c----- temporary variables to compute the coupling (m,s_z) term
!c
      double precision sx(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision sy(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision sz(0:nx+1, 0:ny+1, 0:nz+1, 3)

      double precision sxm(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision sym(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision szm(0:nx+1, 0:ny+1, 0:nz+1, 3)

      double precision rot(3,3), w(3), u0(3), v0(3), tmp_s0(3), tmp_s(3)
      double precision ratio
!c
!c----- we do a splitting: first the local terms (ODE)
!c
      ratio2 = ratio*ratio
      versedet = 1.d0 / (1.d0 + ratio2)
!c
!c----- In the first layer
!c
      dcs = dcos( dt * etaJ_fm )
      dsn = dsin( dt * etaJ_fm )

      dxp = dexp( - dt * etaSF_fm )

      do k=1,nz
         do j=1,ny
            do i=1,nx
!c
!c----- define the rotation matrix
!c
               do jj=1,3
                  do ii=1,3
                     rot(ii,jj) = 0.d0
                  enddo
               enddo

               tmp = dsqrt( u(i,j,k,2)**2 + u(i,j,k,3)**2 )

               if( tmp .lt. 1.d-15 ) then
!c
!c----- rotation matrix is the identity matrix
!c
                  do ii=1,3
                     rot(ii,ii) = 1.d0
                  enddo

               else

                  rot(1,1) = u(i,j,k,1)
                  rot(1,2) = u(i,j,k,2)
                  rot(1,3) = u(i,j,k,3)

                  rot(2,1) = 0.d0
                  rot(2,2) =  u(i,j,k,3) / tmp
                  rot(2,3) = -u(i,j,k,2) / tmp

                  rot(3,1) = -tmp
                  rot(3,2) = u(i,j,k,1)*u(i,j,k,2) / tmp
                  rot(3,3) = u(i,j,k,1)*u(i,j,k,3) / tmp
               endif
!c
!c----- rotate s(t_n) (with Givens rotation)
!c
                  do ii=1,3
                     s1(i,j,k,ii) = 0.d0
                     do ll=1,3
                        s1(i,j,k,ii) = s1(i,j,k,ii) &
                            + rot(ii,ll) * s0(i,j,k,ll)
                     enddo
                  enddo
!c
!c----- solve ODE exactly
!c
                  tmp = dcs * s1(i,j,k,2) - dsn * s1(i,j,k,3)
                  s1(i,j,k,3) = dsn * s1(i,j,k,2) + dcs * s1(i,j,k,3)
                  s1(i,j,k,2) =  tmp
!c
!c----- rotate back with the Givens rotation
!c
                  do ii=1,3
                     w(ii) = 0.d0
                     do ll=1,3
                        w(ii) = w(ii) + rot(ll,ii) * s1(i,j,k,ll)
                     enddo
                  enddo
!c
!c----- multiply by exp(-a(z)dt)
!c
                  do ii=1,3
                     s1(i,j,k,ii) = dxp * w(ii)
                  enddo
!c               endif
            enddo
         enddo
      enddo
!c
!c----- compute the right hand side
!c
!c----- compute the derivative of s w.r.t. x and y
!c
      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  sx(i,j,k,l) = (s0(i+1,j,k,l)-s0(i-1,j,k,l))/(2.d0*dx)
                  sy(i,j,k,l) = (s0(i,j+1,k,l)-s0(i,j-1,k,l))/(2.d0*dy)
               enddo
            enddo
         enddo
      enddo
!c
!c----- first we compute the derivative of s w.r.t. z
!c
      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  sz(i,j,k,l) = &
                      (s0(i,j,k+1,l)-s0(i,j,k-1,l)) / (2.d0 * dz)
               enddo
            enddo
         enddo
      enddo
!c
!c----- compute the product of sx with m
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               tmp = u(i,j,k,1)*sx(i,j,k,1) + u(i,j,k,2)*sx(i,j,k,2) &
                   + u(i,j,k,3)*sx(i,j,k,3)

               sxm(i,j,k,1) = tmp * u(i,j,k,1)
               sxm(i,j,k,2) = tmp * u(i,j,k,2)
               sxm(i,j,k,3) = tmp * u(i,j,k,3)
            enddo
         enddo
      enddo
!c
!c----- compute the product of sy with m
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               tmp = u(i,j,k,1)*sy(i,j,k,1) + u(i,j,k,2)*sy(i,j,k,2) &
                   + u(i,j,k,3)*sy(i,j,k,3)

               sym(i,j,k,1) = tmp * u(i,j,k,1)
               sym(i,j,k,2) = tmp * u(i,j,k,2)
               sym(i,j,k,3) = tmp * u(i,j,k,3)
            enddo
         enddo
      enddo
!c
!c----- compute the product of sz with m
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               tmp = u(i,j,k,1)*sz(i,j,k,1) + u(i,j,k,2)*sz(i,j,k,2) &
                   + u(i,j,k,3)*sz(i,j,k,3)

               szm(i,j,k,1) = tmp * u(i,j,k,1)
               szm(i,j,k,2) = tmp * u(i,j,k,2)
               szm(i,j,k,3) = tmp * u(i,j,k,3)
            enddo
         enddo
      enddo
!c
!c----- assemble the right hand side
!c
      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  Js0(i,j,k,1,l) = sigma * u(i,j,k,l) &
              -  a_fm * ( -  beta * sxm(i,j,k,l) )
                  Js0(i,j,k,2,l) = sigma * 0.d0 &
              -  a_fm * ( -  beta * sym(i,j,k,l) )
                  Js0(i,j,k,3,l) = sigma * 0.d0 &
              -  a_fm * ( -  beta * szm(i,j,k,l) )

                  Js1(i,j,k,1,l) = &
              -  a_fm * ( s1(i+1,j,k,l) - s1(i-1,j,k,l) ) / (2.d0*dx)
                  Js1(i,j,k,2,l) = &
              -  a_fm * ( s1(i,j+1,k,l) - s1(i,j-1,k,l) ) / (2.d0*dy)
                  Js1(i,j,k,3,l) = &
              -  a_fm * ( s1(i,j,k+1,l) - s1(i,j,k-1,l) ) / (2.d0*dz)
               enddo
            enddo
         enddo
      enddo

      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
               gJs(i,j,k,l,1) = versedet * ( &
              Js0(i,j,k,l,1) * ( 1.d0 + ratio2 * u(i,j,k,1)**2 ) &
            + Js0(i,j,k,l,2) * ( ratio * u(i,j,k,3) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,2) ) &
            + Js0(i,j,k,l,3) * (-ratio * u(i,j,k,2) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,3) ) &
            + Js1(i,j,k,l,1) * (-ratio2 + ratio2 * u(i,j,k,1)**2 ) &
            + Js1(i,j,k,l,2) * ( ratio * u(i,j,k,3) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,2) ) &
            + Js1(i,j,k,l,3) * (-ratio * u(i,j,k,2) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,3) ) )

               gJs(i,j,k,l,2) = versedet * ( &
              Js0(i,j,k,l,1) * (-ratio * u(i,j,k,3) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,2) ) &
            + Js0(i,j,k,l,2) * ( 1.d0 + ratio2 * u(i,j,k,2)**2 ) &
            + Js0(i,j,k,l,3) * ( ratio * u(i,j,k,1) &
                               + ratio2 * u(i,j,k,2) * u(i,j,k,3) ) &
            + Js1(i,j,k,l,1) * (-ratio * u(i,j,k,3) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,2) ) &
            + Js1(i,j,k,l,2) * (-ratio2 + ratio2 * u(i,j,k,2)**2 ) &
            + Js1(i,j,k,l,3) * ( ratio * u(i,j,k,1) &
                               + ratio2 * u(i,j,k,2) * u(i,j,k,3) ) )

               gJs(i,j,k,l,3) = versedet * ( &
              Js0(i,j,k,l,1) * ( ratio * u(i,j,k,2) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,3) ) &
            + Js0(i,j,k,l,2) * (-ratio * u(i,j,k,1) &
                               + ratio2 * u(i,j,k,2) * u(i,j,k,3) ) &
            + Js0(i,j,k,l,3) * ( 1.d0 + ratio2 * u(i,j,k,3)**2 ) &
            + Js1(i,j,k,l,1) * ( ratio * u(i,j,k,2) &
                               + ratio2 * u(i,j,k,1) * u(i,j,k,3) ) &
            + Js1(i,j,k,l,2) * (-ratio * u(i,j,k,1) &
                               + ratio2 * u(i,j,k,2) * u(i,j,k,3) ) &
            + Js1(i,j,k,l,3) * (-ratio2 + ratio2 * u(i,j,k,3)**2 ) )
               enddo
            enddo
         enddo
      enddo
!c
!c----- boundary conditions
!c
      do l2=1,3
      do l1=1,3
         k=0
         do j=1,ny
            do i=1,nx
               gJs(i,j,k,l1,l2) = - gJs(i,j,k+1,l1,l2)
            enddo
         enddo
         k=nz
         do j=1,ny
            do i=1,nx
               gJs(i,j,k+1,l1,l2) = - gJs(i,j,k,l1,l2)
            enddo
         enddo
         j=0
         do k=1,nz
            do i=1,nx
               gJs(i,j,k,l1,l2) = - gJs(i,j+1,k,l1,l2)
            enddo
         enddo
         j=ny
         do k=1,nz
            do i=1,nx
               gJs(i,j+1,k,l1,l2) = - gJs(i,j,k,l1,l2)
            enddo
         enddo
         i=0
         do k=1,nz
            do j=1,ny
               gJs(i,j,k,l1,l2) = - gJs(i+1,j,k,l1,l2)
            enddo
         enddo
         i=nx
         do k=1,nz
            do j=1,ny
               gJs(i+1,j,k,l1,l2) = - gJs(i,j,k,l1,l2)
            enddo
         enddo
      enddo
      enddo
!c
!c----- assemble the right hand side
!c
      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  gs(i,j,k,l) = s1(i,j,k,l) - dt * ( &
                (gJs(i+1,j,k,1,l) - gJs(i-1,j,k,1,l)) / (2.d0 * dx) &
              + (gJs(i,j+1,k,2,l) - gJs(i,j-1,k,2,l)) / (2.d0 * dy) &
              + (gJs(i,j,k+1,3,l) - gJs(i,j,k-1,3,l)) / (2.d0 * dz))
               enddo
            enddo
         enddo
      enddo
!c
!c----- solve the system of equations
!c
!c      write(*,*) 'Entering tri...'
      call solve_tri( gs, planf_be_s, planb_be_s, &
          diags, fmuls, upperds, nx, ny, nz )

      do k=1,nz
         do j=1,ny
            do i=1,nx
               s1(i,j,k,1) = gs(i,j,k,1)
               s1(i,j,k,2) = gs(i,j,k,2)
               s1(i,j,k,3) = gs(i,j,k,3)
            enddo
         enddo
      enddo

      return
      end
