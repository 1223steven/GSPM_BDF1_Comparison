#include <sys/time.h>

double second_()
{
	struct timeval time;
	struct timezone tz;

	gettimeofday(&time, &tz);

	return( (double) time.tv_sec + ( (double) time.tv_usec ) / 1000000 );
}
