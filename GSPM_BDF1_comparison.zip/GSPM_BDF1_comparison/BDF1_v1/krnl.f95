      subroutine krnl( kernel, work, khat, mx, my, mz, nw )
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      parameter( tol=1.d-12 )
!c
!c----- Computes the convolution kernels for the stray field.
!c
!c----- External functions
!c
      external dkxx
      external dkxy
      external dkxz

      external dkyy
      external dkyz

!c      external dkzz
!c
!c----- Local variables
!c
      double precision kernel(0:mx-1, 0:my-1, 0:mz-1, 6)
      double complex khat( mx/2+1, my, mz, 6 )

      double precision dx
      double precision dy
      double precision dz
!c
!c----- Variables for the adaptive gauss routine
!c
      double precision work(nw)
      double precision a(2)
      double precision b(2)
      double precision lambda
      double precision mu
      double precision nu
!c
!c----- Timing
!c
      double precision t1
      double precision t2
!c
!c----- Variables for the FFT
!c
      integer*8 planf(6)
!c
!c----- Temporary variable
!c
      double precision tmp
!c
!c----- Common variables
!c
      common/param/dx, dy, dz, lambda, mu, nu, pi
!c
!c----- Initialization
!c
      pi = 4.d0 * datan( 1.d0 )

      nx = mx / 2
      ny = my / 2
      nz = mz / 2

      open(7,file='parameters.kernel')
      write(7,*) mx, my, mz
      write(7,*) dx, dy, dz
      close(7)
!c
!c----- Create plans
!c
      write(*,*) 'Creating plans....'
      t1 = second()
      do j=1,6
         call dfftw_plan_dft_r2c_3d( planf(j), mx, my, mz, &
             kernel(0,0,0,j), khat(1,1,1,j), FFTW_MEASURE )
      enddo
      t2 = second()
      write(*,*) 'Plans created in ', t2-t1, ' seconds.'
!c
!c----- First the interaction of X with itself
!c
      t1 = second()

      i=0
      j=0
      k=0
      call demag( dy/2, dz/2, dx/2, kernel(0,0,0,1) )
      kernel(0,0,0,1) = -kernel(0,0,0,1)

      i=1
      j=0
      k=0
      call demag( dy/2, dz/2, dx, tmp )
      kernel(1,0,0,1) = -tmp - kernel(0,0,0,1)

      i=0
      j=1
      k=0
      call demag( dy, dz/2, dx/2, tmp )
      kernel(0,1,0,1) = -tmp - kernel(0,0,0,1)

      i=0
      j=0
      k=1
      call demag( dy/2, dz, dx/2, tmp )
      kernel(0,0,1,1) = -tmp - kernel(0,0,0,1)

      a(1) = -.5d0
      a(2) = -.5d0

      b(1) =  .5d0
      b(2) =  .5d0

      do k=0,nz-1
         do j=0,ny-1
            do i=0,nx-1
               if ((i+j+k).gt.1) then
                  lambda = i * 1.d0
                  mu = j * 1.d0
                  nu = k * 1.d0

                  call gauss2d(a,b,tmp,dkxx,work,nw,tol,1,ierror)
                  if (ierror.ne.0) then
                     write(*,*) 'Error in value (',i,',',j,',',k,',1)'
                     stop
                  endif

                  kernel(i,j,k,1) = tmp
!c                  write(*,*) i,j,k,tmp
               endif
            enddo
         enddo
      enddo
!c
!c----- Kernel symmetries.
!c
      do k=0,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = k

               kernel(mx-i,j,k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = k

               kernel(i,my-j,k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = k

               kernel(mx-i,my-j,k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=0,nx-1
               lambda = i
               mu = j
               nu = -k

               kernel(i,j,mz-k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = -k

               kernel(mx-i,j,mz-k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = -k

               kernel(i,my-j,mz-k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = -k

               kernel(mx-i,my-j,mz-k,1) = kernel(i,j,k,1)
            enddo
         enddo
      enddo

      t2 = second()
      write(*,*) 'Interaction between X and X: ', t2-t1, ' seconds.'

      write(*,*) 'kernelxx(0,0,0) = ', kernel(0,0,0,1)
      write(*,*) 'kernelxx(1,0,0) = ', kernel(1,0,0,1)
      write(*,*) 'kernelxx(0,1,0) = ', kernel(0,1,0,1)
      write(*,*) 'kernelxx(0,0,1) = ', kernel(0,0,1,1)
      write(*,*) 'kernelxx(1,1,0) = ', kernel(1,1,0,1)
      write(*,*) 'kernelxx(1,0,1) = ', kernel(1,0,1,1)
      write(*,*) 'kernelxx(0,1,1) = ', kernel(0,1,1,1)
      write(*,*) 'kernelxx(1,1,1) = ', kernel(1,1,1,1)
!c
!c----- Interaction of X with Y
!c
      kernel(0,0,0,2) = 0.d0
      kernel(1,0,0,2) = 0.d0
      kernel(0,1,0,2) = 0.d0
      kernel(0,0,1,2) = 0.d0

      t1 = second()
      do k=0,nz-1
         do j=0,ny-1
            do i=0,nx-1

               if( (i.eq.0).or.(j.eq.0) ) then
                  kernel(i,j,k,2) = 0.d0
               else
!c               if ((i+j+k).gt.1) then
                  lambda = i * 1.d0
                  mu = j * 1.d0
                  nu = k * 1.d0

                  call gauss2d(a,b,tmp,dkxy,work,nw,tol,1,ierror)
                  if (ierror.ne.0) then
                     write(*,*) 'Error in value (',i,',',j,',',k,',2)'
                     stop
                  endif

                  kernel(i,j,k,2) = tmp
               endif
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = k

               kernel(mx-i,j,k,2) = - kernel(i,j,k,2)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = k

               kernel(i,my-j,k,2) = - kernel(i,j,k,2)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = k

               kernel(mx-i,my-j,k,2) = kernel(i,j,k,2)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=0,nx-1
               lambda = i
               mu = j
               nu = -k

               kernel(i,j,mz-k,2) = kernel(i,j,k,2)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = -k

               kernel(mx-i,j,mz-k,2) = - kernel(i,j,k,2)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = -k

               kernel(i,my-j,mz-k,2) = - kernel(i,j,k,2)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = -k

               kernel(mx-i,my-j,mz-k,2) = kernel(i,j,k,2)
            enddo
         enddo
      enddo
      t2 = second()

      write(*,*) 'Interaction between X and Y: ', t2-t1, ' seconds.'

      write(*,*) 'kernelxy(0,0,0) = ', kernel(0,0,0,2)
      write(*,*) 'kernelxy(1,0,0) = ', kernel(1,0,0,2)
      write(*,*) 'kernelxy(0,1,0) = ', kernel(0,1,0,2)
      write(*,*) 'kernelxy(0,0,1) = ', kernel(0,0,1,2)
      write(*,*) 'kernelxy(1,1,0) = ', kernel(1,1,0,2)
      write(*,*) 'kernelxy(1,0,1) = ', kernel(1,0,1,2)
      write(*,*) 'kernelxy(0,1,1) = ', kernel(0,1,1,2)
      write(*,*) 'kernelxy(1,1,1) = ', kernel(1,1,1,2)
!c
!c----- Interaction of X with Z
!c
      kernel(0,0,0,3) = 0.d0
      kernel(1,0,0,3) = 0.d0
      kernel(0,1,0,3) = 0.d0
      kernel(0,0,1,3) = 0.d0

      t1 = second()
      do k=0,nz-1
         do j=0,ny-1
            do i=0,nx-1
               if ((i+j+k).gt.1) then
                  lambda = i * 1.d0
                  mu = j * 1.d0
                  nu = k * 1.d0

                  call gauss2d(a,b,tmp,dkxz,work,nw,tol,1,ierror)
                  if (ierror.ne.0) then
                     write(*,*) 'Error in value (',i,',',j,',',k,',3)'
                     stop
                  endif

                  kernel(i,j,k,3) = tmp
               endif
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = k

               kernel(mx-i,j,k,3) = - kernel(i,j,k,3)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = k

               kernel(i,my-j,k,3) = kernel(i,j,k,3)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=0,nx-1
               lambda = i
               mu = j
               nu = -k

               kernel(i,j,mz-k,3) = -kernel(i,j,k,3)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = k

               kernel(mx-i,my-j,k,3) = - kernel(i,j,k,3)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = -k

               kernel(mx-i,j,mz-k,3) = kernel(i,j,k,3)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = -k

               kernel(i,my-j,mz-k,3) = - kernel(i,j,k,3)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = -k

               kernel(mx-i,my-j,mz-k,3) = kernel(i,j,k,3)
            enddo
         enddo
      enddo
      t2 = second()

      write(*,*) 'Interaction between X and Z: ', t2-t1, ' seconds.'

      write(*,*) 'kernelxz(0,0,0) = ', kernel(0,0,0,3)
      write(*,*) 'kernelxz(1,0,0) = ', kernel(1,0,0,3)
      write(*,*) 'kernelxz(0,1,0) = ', kernel(0,1,0,3)
      write(*,*) 'kernelxz(0,0,1) = ', kernel(0,0,1,3)
      write(*,*) 'kernelxz(1,1,0) = ', kernel(1,1,0,3)
      write(*,*) 'kernelxz(1,0,1) = ', kernel(1,0,1,3)
      write(*,*) 'kernelxz(0,1,1) = ', kernel(0,1,1,3)
      write(*,*) 'kernelxz(1,1,1) = ', kernel(1,1,1,3)
!c
!c----- kernel for the interaction of Y with itself
!c
      t1 = second()

      i=0
      j=0
      k=0
      call demag(dz/2, dx/2, dy/2, kernel(0,0,0,4))
      kernel(0,0,0,4) =  - kernel(0,0,0,4)

      i=1
      j=0
      k=0
      call demag(dz/2, dx/2, dy, tmp)
      kernel(0,1,0,4) = - tmp - kernel(0,0,0,4)

      i=0
      j=1
      k=0
      call demag(dz, dx/2, dy/2, tmp)
      kernel(0,0,1,4) = - tmp - kernel(0,0,0,4)

      i=0
      j=0
      k=1
      call demag(dz/2, dx, dy/2, tmp)
      kernel(1,0,0,4) = - tmp - kernel(0,0,0,4)

      a(1) = -.5d0
      a(2) = -.5d0

      b(1) =  .5d0
      b(2) =  .5d0

      do k=0,nz-1
         do j=0,ny-1
            do i=0,nx-1
               if ((i+j+k).gt.1) then
                  lambda = i * 1.d0
                  mu = j * 1.d0
                  nu = k * 1.d0

                  call gauss2d(a,b,tmp,dkyy,work,nw,tol,1,ierror)
                  if (ierror.ne.0) then
                     write(*,*) 'Error in value (',i,',',j,',',k,',1)'
                     stop
                  endif

                  kernel(i,j,k,4) = tmp
               endif
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = k

               kernel(mx-i,j,k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = k

               kernel(i,my-j,k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = k

               kernel(mx-i,my-j,k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=0,nx-1
               lambda = i
               mu = j
               nu = -k

               kernel(i,j,mz-k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = -k

               kernel(mx-i,j,mz-k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = -k

               kernel(i,my-j,mz-k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = -k

               kernel(mx-i,my-j,mz-k,4) = kernel(i,j,k,4)
            enddo
         enddo
      enddo

      t2 = second()
      write(*,*) 'Interaction between Y and Y: ', t2-t1, ' seconds.'

      write(*,*) 'kernelyy(0,0,0) = ', kernel(0,0,0,4)
      write(*,*) 'kernelyy(1,0,0) = ', kernel(1,0,0,4)
      write(*,*) 'kernelyy(0,1,0) = ', kernel(0,1,0,4)
      write(*,*) 'kernelyy(0,0,1) = ', kernel(0,0,1,4)
      write(*,*) 'kernelyy(1,1,0) = ', kernel(1,1,0,4)
      write(*,*) 'kernelyy(1,0,1) = ', kernel(1,0,1,4)
      write(*,*) 'kernelyy(0,1,1) = ', kernel(0,1,1,4)
      write(*,*) 'kernelyy(1,1,1) = ', kernel(1,1,1,4)

      t1 = second()
!c
!c----- Interaction of Y with Z
!c
      kernel(0,0,0,5) = 0.d0
      kernel(1,0,0,5) = 0.d0
      kernel(0,1,0,5) = 0.d0
      kernel(0,0,1,5) = 0.d0

      t1 = second()
      do k=0,nz-1
         do j=0,ny-1
            do i=0,nx-1
               if ((i+j+k).gt.1) then
                  lambda = i * 1.d0
                  mu = j * 1.d0
                  nu = k * 1.d0

                  call gauss2d(a,b,tmp,dkyz,work,nw,tol,1,ierror)
                  if (ierror.ne.0) then
                     write(*,*) 'Error in value (',i,',',j,',',k,',5)'
                     stop
                  endif

                  kernel(i,j,k,5) = tmp
               endif
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = k

               kernel(mx-i,j,k,5) =  kernel(i,j,k,5)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = k

               kernel(i,my-j,k,5) = - kernel(i,j,k,5)
            enddo
         enddo
      enddo

      do k=0,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = k

               kernel(mx-i,my-j,k,5) = - kernel(i,j,k,5)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=0,nx-1
               lambda = i
               mu = j
               nu = -k

               kernel(i,j,mz-k,5) = - kernel(i,j,k,5)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=0,ny-1
            do i=1,nx-1
               lambda = - i
               mu = j
               nu = -k

               kernel(mx-i,j,mz-k,5) = - kernel(i,j,k,5)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=0,nx-1
               lambda = i
               mu = - j
               nu = -k

               kernel(i,my-j,mz-k,5) =  kernel(i,j,k,5)
            enddo
         enddo
      enddo

      do k=1,nz-1
         do j=1,ny-1
            do i=1,nx-1
               lambda = - i
               mu = - j
               nu = -k

               kernel(mx-i,my-j,mz-k,5) = kernel(i,j,k,5)
            enddo
         enddo
      enddo
      t2 = second()

      write(*,*) 'Interaction between Y and Z: ', t2-t1, ' seconds.'

      write(*,*) 'kernelyz(0,0,0) = ', kernel(0,0,0,5)
      write(*,*) 'kernelyz(1,0,0) = ', kernel(1,0,0,5)
      write(*,*) 'kernelyz(0,1,0) = ', kernel(0,1,0,5)
      write(*,*) 'kernelyz(0,0,1) = ', kernel(0,0,1,5)
      write(*,*) 'kernelyz(1,1,0) = ', kernel(1,1,0,5)
      write(*,*) 'kernelyz(1,0,1) = ', kernel(1,0,1,5)
      write(*,*) 'kernelyz(0,1,1) = ', kernel(0,1,1,5)
      write(*,*) 'kernelyz(1,1,1) = ', kernel(1,1,1,5)
!c
!c----- Interaction of Z with itself
!c
      t1 = second()

      do k=0,mz-1
         do j=0,my-1
            do i=0,mx-1
               if ((i+j+k).eq.0) then
                  kernel(i,j,k,6) = -1.d0 - kernel(i,j,k,4) &
                      - kernel(i,j,k,1)
               else
                  kernel(i,j,k,6) = 0.d0 - kernel(i,j,k,4) &
                      - kernel(i,j,k,1)
               endif
            enddo
         enddo
      enddo
      t2 = second()

      write(*,*) 'Interaction between Z and Z: ', t2-t1, ' seconds.'

      write(*,*) 'kernelzz(0,0,0) = ', kernel(0,0,0,6)
      write(*,*) 'kernelzz(1,0,0) = ', kernel(1,0,0,6)
      write(*,*) 'kernelzz(0,1,0) = ', kernel(0,1,0,6)
      write(*,*) 'kernelzz(0,0,1) = ', kernel(0,0,1,6)
      write(*,*) 'kernelzz(1,1,0) = ', kernel(1,1,0,6)
      write(*,*) 'kernelzz(1,0,1) = ', kernel(1,0,1,6)
      write(*,*) 'kernelzz(0,1,1) = ', kernel(0,1,1,6)
      write(*,*) 'kernelzz(1,1,1) = ', kernel(1,1,1,6)
!c
!c----- scale the kernels
!c
      scale = 1.d0/dble(mx*my*mz)
      do k=0,mz-1
         do j=0,my-1
            do i=0,mx-1
               kernel(i,j,k,1) = scale * kernel(i,j,k,1)
               kernel(i,j,k,2) = scale * kernel(i,j,k,2)
               kernel(i,j,k,3) = scale * kernel(i,j,k,3)
               kernel(i,j,k,4) = scale * kernel(i,j,k,4)
               kernel(i,j,k,5) = scale * kernel(i,j,k,5)
               kernel(i,j,k,6) = scale * kernel(i,j,k,6)
            enddo
         enddo
      enddo
!c
!c----- write the kernels
!c
      t1 = second()
      do j=1,6
         call dfftw_execute( planf(j) )
      enddo
      t2 = second()

      write(*,*) 'Fourier Transform computed in ', t2-t1,' seconds.'

      write(*,*) 'Storing Kernels....'
      open(7,file='kernels.7',form='unformatted')
      write(7) khat
      close(7)
      write(*,*) 'Kernels computed and stored in file kernels.7'
      write(*,*)
!c
!c----- destroy plans
!c
      do j=1,6
         call dfftw_destroy_plan( planf(j) )
      enddo

      return
      end
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine dkxx(z,f)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision z(2)
      double precision f

      double precision dx
      double precision dy
      double precision dz

      double precision lambda
      double precision mu
      double precision nu

      double precision pi

      common/param/dx, dy, dz, lambda, mu, nu, pi

      t = dy * ( mu + ( z(2)-z(1) ) )

      u0 = (lambda+1.d0)*dx
      u1 = lambda*dx
      u2 = (lambda-1.d0)*dx

      f =  ( - dk( u0, mu, nu, dx, dy, dz, t, pi ) &
            + 2.d0 * dk( u1, mu, nu, dx, dy, dz, t, pi ) &
            - dk( u2, mu, nu, dx, dy, dz, t, pi ) ) * dy / (dx*dz)

      return
      end
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine dkxy(z,f)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision z(2)
      double precision f

      double precision dx
      double precision dy
      double precision dz

      double precision lambda
      double precision mu
      double precision nu

      double precision pi

      common/param/dx, dy, dz, lambda, mu, nu, pi

      s0 = (lambda - .5d0 - z(1)) * dx
      s1 = (lambda + .5d0 - z(1)) * dx

      t0 = (mu - .5d0 + z(2)) * dy
      t1 = (mu + .5d0 + z(2)) * dy

      f = ( dk( s1, mu, nu, dx, dy, dz, t0, pi ) &
          - dk( s0, mu, nu, dx, dy, dz, t0, pi ) &
          - dk( s1, mu, nu, dx, dy, dz, t1, pi ) &
          + dk( s0, mu, nu, dx, dy, dz, t1, pi ) ) / dz

      return
      end
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine dkxz(z,f)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision z(2)
      double precision f

      double precision dx
      double precision dy
      double precision dz

      double precision lambda
      double precision mu
      double precision nu

      double precision pi

      common/param/dx, dy, dz, lambda, mu, nu, pi

      s0 = (lambda - .5d0 - z(1)) * dx
      s1 = (lambda + .5d0 - z(1)) * dx

      t0 = (nu - .5d0 + z(2)) * dz
      t1 = (nu + .5d0 + z(2)) * dz

      f =  -( dk( s0, nu, mu, dx, dz, dy, t0, pi ) &
          - dk( s1, nu, mu, dx, dz, dy, t0, pi ) &
          - dk( s0, nu, mu, dx, dz, dy, t1, pi ) &
          + dk( s1, nu, mu, dx, dz, dy, t1, pi ) ) / dy

      return
      end
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine dkyy(z,f)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision z(2)
      double precision f

      double precision dx
      double precision dy
      double precision dz

      double precision lambda
      double precision mu
      double precision nu

      double precision pi

      common/param/dx, dy, dz, lambda, mu, nu, pi

      t = dx * (lambda + (z(2)-z(1)))

      u0 = (mu+1.d0)*dy
      u1 =  mu*dy
      u2 = (mu-1.d0)*dy

      f =  (- dk( u0, mu, nu, dx, dy, dz, t, pi ) &
          + 2.d0*dk( u1, mu, nu, dx, dy, dz, t, pi ) &
          - dk( u2, mu, nu, dx, dy, dz, t, pi )) * dx / (dy*dz)

      return
      end
!cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine dkyz(z,f)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)

      double precision z(2)
      double precision f

      double precision dx
      double precision dy
      double precision dz

      double precision lambda
      double precision mu
      double precision nu

      double precision pi

      common/param/dx, dy, dz, lambda, mu, nu, pi

      s0 = (mu - .5d0 - z(1)) * dy
      s1 = (mu + .5d0 - z(1)) * dy

      t0 = (nu - .5d0 + z(2)) * dz
      t1 = (nu + .5d0 + z(2)) * dz

      f = -( dk( s0, nu, lambda, dy, dz, dx, t0, pi ) &
          - dk( s1, nu, lambda, dy, dz, dx, t0, pi ) &
          - dk( s0, nu, lambda, dy, dz, dx, t1, pi ) &
          + dk( s1, nu, lambda, dy, dz, dx, t1, pi ) ) / dx

      return
      end
!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine demag(a, b, c, f)
      implicit double precision (a-h,o-z)
      implicit integer (i-n)
!c
!c     Amikam Aharoni,
!c     "Demagnetizing factors for rectangular ferromagnetic prisms",
!c     Journal of Applied Physics, Vol. 83(6), 1998, pp. 3432--3434.
!c
      double precision a, b, c, f, pi

      pi = 4.d0*datan(1.0d0)

      t1 = (b**2-c**2)/(2.d0*b*c)* &
          dlog((b**2+c**2)/(dsqrt(a**2+b**2+c**2)+a)**2)

      t2 = (a**2-c**2)/(2.d0*a*c)* &
          dlog((a**2+c**2)/(dsqrt(a**2+b**2+c**2)+b)**2)

      t3 = b/(2.d0*c)* &
          dlog((dsqrt(a**2+b**2)+a)**2/b**2)

      t4 = a/(2.d0*c)* &
          dlog((dsqrt(a**2+b**2)+b)**2/a**2)

      t5 = c/(2.d0*a)* &
          dlog(c**2/(dsqrt(b**2+c**2)+b)**2)

      t6 = c/(2.d0*b)* &
          dlog(c**2/(dsqrt(a**2+c**2)+a)**2)

      t7 = 2.d0*datan(a*b/(c*dsqrt(a**2+b**2+c**2)))

      t8 = (a**3+b**3-2.d0*c**3)/(3.d0*a*b*c)

      t9 = (a**2+b**2-2.d0*c**2)/(3.d0*a*b*c)*dsqrt(a**2+b**2+c**2)

      t10 = (c/(a*b))*(dsqrt(a**2+c**2)+dsqrt(b**2+c**2))

      t11 = -(dsqrt(a**2+b**2)**3+dsqrt(b**2+c**2)**3 &
          +dsqrt(c**2+a**2)**3)/(3.d0*a*b*c)

      f = t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9 + t10 + t11

      f = f / pi

      return
      end
!ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      double precision function dk( u0, mu, nu, dx, dy, dz, t, pi )
      implicit double precision( a-h, o-z )
      implicit integer( i-n )

      double precision lambda
      double precision mu
      double precision nu

      double precision dx
      double precision dy
      double precision dz

      double precision t
      double precision pi

      s0 = (nu + 1.d0) * dz
      s1 =  nu * dz
      s2 = (nu - 1.d0) * dz

      alpha = dsqrt(u0*u0 + t*t)
      alpha2 = alpha*alpha

      tt0 = dsqrt( alpha2 + s0*s0 )
      tt1 = dsqrt( alpha2 + s1*s1 )
      tt2 = dsqrt( alpha2 + s2*s2 )

      rr0 = s0 + tt0
      rr1 = s1 + tt1
      rr2 = s2 + tt2

      dk = ( s1 * dlog( rr1*rr1 / (rr0*rr2) ) + dz * dlog( rr2 / rr0 ) &
          + tt0 - 2.d0 * tt1 + tt2 ) / (4.d0 * pi )

      return
      end
