subroutine BDF2GMRES_solver(MAX_LOCAL_SIZE,HYPRE_PARCSR,local_size, extra,&
            ilower,iupper,mpi_comm,nnl,nnx,cols,values,mat_counter,rhs,print_solution,&
            solver_id,myid,g)

implicit none

 include 'mpif.h'

      integer    MAX_LOCAL_SIZE
      integer    HYPRE_PARCSR

!      parameter  (MAX_LOCAL_SIZE=123000)

!c     the following is from HYPRE.c
!      parameter  (HYPRE_PARCSR=5555)

      integer    ierr
      integer    num_procs, myid
      integer    local_size, extra
      integer    n, solver_id, print_solution
      integer    nnz, ilower, iupper, i
      integer    precond_id
      double precision h, h2,t1,t2
      double precision rhs_values(MAX_LOCAL_SIZE)
      double precision x_values(MAX_LOCAL_SIZE)
      integer    rows(MAX_LOCAL_SIZE)
      integer :: nnl,nnx
      integer    cols(nnl,nnx)
      double precision values(nnl,nnx)
      integer    num_iterations,mat_counter(nnl,1), i_index(iupper+1,1)
      double precision final_res_norm, tol

      integer    mpi_comm

      integer*8  parcsr_A
      integer*8  AA        ! means :  HYPRE_TYPE
      integer*8  bb        ! means :  HYPRE_TYPE
      integer*8  x_hat        ! means :  HYPRE_TYPE
      integer*8  par_b    ! means :  HYPRE_TYPE
      integer*8  par_x    ! means :  HYPRE_TYPE
      integer*8  solver   ! means :  HYPRE_TYPE
      integer*8  precond  ! means :  HYPRE_TYPE

!      double precision :: A_values(273,1)
!      integer :: A_index(273,2)

!      integer :: nonzero_row_index(nn,1), nonzero_col_index(nn,1)
!      double precision :: nonzero_value(nn,1)

      integer :: ii,jj
      double precision :: g(nnl,1)
      double precision :: rhs(nnl,1)

!!!c-----------------------------------------------------------------------
!!!c     Initialize MPI
!!!c-----------------------------------------------------------------------
!!
!!      call MPI_INIT(ierr)
!!      call MPI_COMM_RANK(MPI_COMM_WORLD, myid, ierr)
!!      call MPI_COMM_SIZE(MPI_COMM_WORLD, num_procs, ierr)
!!      mpi_comm = MPI_COMM_WORLD
!      t1 = second()
      call HYPRE_IJMatrixCreate(mpi_comm, ilower,&
     iupper, ilower, iupper, AA, ierr)
!     t2 = second()
!     write(*,*) 'timing cost3 is'
!     write(*,*) t2-t1


!c     Choose a parallel csr format storage (see the User's Manual)
!     t1 = second()
      call HYPRE_IJMatrixSetObjectType(AA, HYPRE_PARCSR, ierr)
!     t2 = second()
!     write(*,*) 'timing cost4 is'
!     write(*,*) t2-t1
!c     Initialize before setting coefficients
!      t1 =second()
      call HYPRE_IJMatrixInitialize(AA, ierr)
!      t2 = second()
!     write(*,*) 'timing cost5 is'
!     write(*,*) t2-t1

!write(*,*) 'A_index, A_values are :'
!write(*,*) A_index(:,2)

!write(*,*) 'ilower are :'
!write(*,*) ilower
!t1 =second()

!! do i = ilower, iupper
!!!i = 1
!!      nnz = 0
!!      ! here generate the elements
!!          do ii=1,counter
!!              if ( (nonzero_row_index(ii,1)-1).EQ.i ) then
!!                  nnz = nnz+1
!!                  cols(i+1,nnz) = nonzero_col_index(ii,1)-1
!!                  values(i+1,nnz) = nonzero_value(ii,1)
!!              endif
!!          enddo
!!          nnz = nnz + 1
!!          mat_counter(i+1,1) = nnz-1
!!!c        Set the values for row i
!!    call HYPRE_IJMatrixSetValues(AA, 1, nnz-1, i, cols(i+1,:), values(i+1,:), ierr)
!!
!!enddo
!write(*,*) 'mat_counter is'
!write(*,*) mat_counter
!write(*,*) 'cols is'
!write(*,*) cols
!mat_counter = 1
!i_index = 1
!cols = 1
!cols(1,1:5) = 1
!cols(2:,:) = 1
!values = 1

do i=ilower, iupper
    i_index(i+1,1) = i
    call HYPRE_IJMatrixSetValues(AA, 1, mat_counter(i+1,1), i, cols(i+1,:), values(i+1,:), ierr)
enddo
!!
!!
!call HYPRE_IJMatrixSetValues(AA, nnl, mat_counter(:,1), i_index(:,1), cols(:,:), values(:,:), ierr) ! this is very slow
!call HYPRE_IJMatrixSetValues(AA, 1, nnz-1, i, cols, values, ierr)
!HYPRE_IJMatrixSetValues(AA,2,5,2,nonzero_col_index, nonzero_value,ierr)
!do i=ilower, iupper
!    i_index(i+1,1) = i
!enddo

!call HYPRE_IJMatrixGetValues(AA, iupper, mat_counter, i_index, nonzero_col_index, nonzero_value, ierr)
!      t2 = second()
!     write(*,*) 'timing cost6 is'
!     write(*,*) t2-t1

!c     Assemble after setting the coefficients
      call HYPRE_IJMatrixAssemble(AA, ierr)

!c     Get parcsr matrix object
      call HYPRE_IJMatrixGetObject(AA, parcsr_A, ierr)


!c     Create the rhs and solution
      call HYPRE_IJVectorCreate(mpi_comm,ilower, iupper, bb, ierr)
      call HYPRE_IJVectorSetObjectType(bb, HYPRE_PARCSR, ierr)
      call HYPRE_IJVectorInitialize(bb, ierr)

      call HYPRE_IJVectorCreate(mpi_comm, ilower, iupper, x_hat, ierr)
      call HYPRE_IJVectorSetObjectType(x_hat, HYPRE_PARCSR, ierr)
      call HYPRE_IJVectorInitialize(x_hat, ierr)

!c     Set the rhs values to h^2 and the solution to zero
!write(*,*) 'h2 is'
!write(*,*) h2
      do i = 1, local_size
         rows(i) = ilower + i -1
         rhs_values(i) = rhs(rows(i)+1,1)
         x_values(i) = 0.0
      enddo

      call HYPRE_IJVectorSetValues(bb, local_size, rows, rhs_values, ierr)
      call HYPRE_IJVectorSetValues(x_hat, local_size, rows, x_values, ierr)


      call HYPRE_IJVectorAssemble(bb, ierr)
      call HYPRE_IJVectorAssemble(x_hat, ierr)

!c get the x and b objects

      call HYPRE_IJVectorGetObject(bb, par_b, ierr)
      call HYPRE_IJVectorGetObject(x_hat, par_x, ierr)

!c     Choose a solver and solve the system

!*********** choose the solver which is the one of the following:
!(1st) BoomerAMG solver : solver_id = 0 ;
!(2nd) PCG solver (with DS preconditioner) : solver_id = 50 ；
!(3th) PCG solver (with AMG preconditioner) :solver_id = 1 ;
!(4th) PCG solver (with ParaSails preconditioner) : solver_id = 8 ;
!*****************************************************************
          ! the first method : BoomerAMG
          ! solver_id = 0
!********************* begin the BOOMERAMG solver ******************

! here on preconditioner, only the BoomerAMG as the solver
! note that only BoomerAMG is not convergent when (n>7)

      if ( solver_id .eq. 0 ) then

!c        Create solver
         call HYPRE_BoomerAMGCreate(solver, ierr)


!c        Set some parameters (See Reference Manual for more parameters)

!c        print solve info + parameters
         call HYPRE_BoomerAMGSetPrintLevel(solver, 0, ierr)
!c        old defaults, Falgout coarsening, mod. class. interpolation
!!         call HYPRE_BoomerAMGSetOldDefault(solver, ierr)

         call HYPRE_BoomerAMGSetCoarsenType( solver, 6, ierr)
         call HYPRE_BoomerAMGSetInterpType( solver, 0, ierr)
         call HYPRE_BoomerAMGSetPMaxElmts( solver, 2, ierr)

!c        G-S/Jacobi hybrid relaxation
         call HYPRE_BoomerAMGSetRelaxType(solver, 6, ierr)
!c        C/F relaxation
         call HYPRE_BoomerAMGSetRelaxOrder(solver, 1, ierr)
!c        Sweeeps on each level

         call HYPRE_BoomerAMGSetNumSweeps(solver, 2, ierr)
!c         maximum number of levels
         call HYPRE_BoomerAMGSetMaxLevels(solver, 40, ierr)
!c        conv. tolerance
         call HYPRE_BoomerAMGSetTol(solver, 1.0d-7, ierr)

!         maximum iterations:
         call HYPRE_BoomerAMGSetMaxIter(solver, 200, ierr)

!c        Now setup and solve!
         call HYPRE_BoomerAMGSetup(solver, parcsr_A, par_b, par_x, ierr)
         call HYPRE_BoomerAMGSolve(solver, parcsr_A, par_b, par_x, ierr)


!c        Run info - needed logging turned on
         call HYPRE_BoomerAMGGetNumIterations(solver, num_iterations,ierr)
         call HYPRE_BoomerAMGGetFinalReltvRes(solver, final_res_norm,ierr)


         if ( myid .eq. 0 ) then
            print *
            print '(A,I2)', " Iterations = ", num_iterations
            print '(A,ES16.8)', &
                 " Final Relative Residual Norm = ", final_res_norm
            print *
         endif

!c        Destroy solver
         call HYPRE_BoomerAMGDestroy(solver, ierr)
!********************* end the BOOMERAMG solver **************


         ! the second method : PCG (with DS)
         ! solver_id = 50
!********************* begin the PCG solver (with DS preconditioner) ******


!c     PCG (with DS)
      elseif ( solver_id .eq. 50 ) then


!c        Create solver
         call HYPRE_ParCSRPCGCreate(MPI_COMM_WORLD, solver, ierr)

!c        Set some parameters (See Reference Manual for more parameters)
         call HYPRE_ParCSRPCGSetMaxIter(solver, 1000, ierr)
         call HYPRE_ParCSRPCGSetTol(solver, 1.0d-11, ierr)
         call HYPRE_ParCSRPCGSetTwoNorm(solver, 1, ierr)
         call HYPRE_ParCSRPCGSetPrintLevel(solver, 0, ierr)
         call HYPRE_ParCSRPCGSetLogging(solver, 1, ierr)

!c        set ds (diagonal scaling) as the pcg preconditioner
         precond_id = 1
         call HYPRE_ParCSRPCGSetPrecond(solver, precond_id, &
             precond, ierr)



!c        Now setup and solve!
         call HYPRE_ParCSRPCGSetup(solver, parcsr_A, par_b,par_x, ierr)
         call HYPRE_ParCSRPCGSolve(solver, parcsr_A, par_b,par_x, ierr)


!c        Run info - needed logging turned on

        call HYPRE_ParCSRPCGGetNumIterations(solver, num_iterations,ierr)
        call HYPRE_ParCSRPCGGetFinalRelative(solver, final_res_norm,ierr)

       if ( myid .eq. 0 ) then
            print *
            print *, "Iterations = ", num_iterations
            print *, "Final Relative Residual Norm = ", final_res_norm
            print *
         endif

!c       Destroy solver
        call HYPRE_ParCSRPCGDestroy(solver, ierr)

!********************* end the PCG solver (with DS preconditioner) ***********


         ! the third method : PCG with AMG preconditioner
         ! solver_id = 1
!********************* begin the PCG solver (with AMG preconditioner) ******

!c     PCG with AMG preconditioner
      elseif ( solver_id == 1 ) then

!c        Create solver
         call HYPRE_ParCSRPCGCreate(MPI_COMM_WORLD, solver, ierr)

!c        Set some parameters (See Reference Manual for more parameters)
         call HYPRE_ParCSRPCGSetMaxIter(solver, 1000, ierr)
         call HYPRE_ParCSRPCGSetTol(solver, 1.0d-11, ierr)
         call HYPRE_ParCSRPCGSetTwoNorm(solver, 1, ierr)
         call HYPRE_ParCSRPCGSetPrintLevel(solver, 0, ierr)
         call HYPRE_ParCSRPCGSetLogging(solver, 1, ierr)

!c        Now set up the AMG preconditioner and specify any parameters

         call HYPRE_BoomerAMGCreate(precond, ierr)


!c        Set some parameters (See Reference Manual for more parameters)

!c        print less solver info since a preconditioner
         call HYPRE_BoomerAMGSetPrintLevel(precond, 0, ierr);
!c        Falgout coarsening
         call HYPRE_BoomerAMGSetCoarsenType(precond, 6, ierr)
!c        old defaults
         call HYPRE_BoomerAMGSetOldDefault(precond, ierr)
!c        SYMMETRIC G-S/Jacobi hybrid relaxation
         call HYPRE_BoomerAMGSetRelaxType(precond, 6, ierr)
!c        Sweeeps on each level
         call HYPRE_BoomerAMGSetNumSweeps(precond, 1, ierr)
!c        conv. tolerance
         call HYPRE_BoomerAMGSetTol(precond, 1.0d-7, ierr)
!c        do only one iteration!
         call HYPRE_BoomerAMGSetMaxIter(precond, 1, ierr)

!c        set amg as the pcg preconditioner
         precond_id = 2
         call HYPRE_ParCSRPCGSetPrecond(solver, precond_id,&
             precond, ierr)


!c        Now setup and solve!
         call HYPRE_ParCSRPCGSetup(solver, parcsr_A, par_b,&
                                 par_x, ierr)
         call HYPRE_ParCSRPCGSolve(solver, parcsr_A, par_b,&
                                 par_x, ierr)


!c        Run info - needed logging turned on

        call HYPRE_ParCSRPCGGetNumIterations(solver, num_iterations,ierr)
        call HYPRE_ParCSRPCGGetFinalRelative(solver, final_res_norm,ierr)

       if ( myid .eq. 0 ) then
            print *
            print *, "Iterations = ", num_iterations
            print *, "Final Relative Residual Norm = ", final_res_norm
            print *
         endif

!c       Destroy precond and solver

        call HYPRE_BoomerAMGDestroy(precond, ierr)
        call HYPRE_ParCSRPCGDestroy(solver, ierr)
!********************* end the PCG solver (with AMG preconditioner) ******

        ! the fourth method : PCG with ParaSails preconditioner
        ! solver_id = 8
!********************* begin the PCG solver (with ParaSails preconditioner) ******


!c     PCG with ParaSails
      elseif ( solver_id .eq. 8 ) then

!c        Create solver
         call HYPRE_ParCSRPCGCreate(MPI_COMM_WORLD, solver, ierr)

!c        Set some parameters (See Reference Manual for more parameters)
         call HYPRE_ParCSRPCGSetMaxIter(solver, 1000, ierr)
         call HYPRE_ParCSRPCGSetTol(solver, 1.0d-11, ierr)
         call HYPRE_ParCSRPCGSetTwoNorm(solver, 1, ierr)
         call HYPRE_ParCSRPCGSetPrintLevel(solver, 0, ierr)
         call HYPRE_ParCSRPCGSetLogging(solver, 1, ierr)

!c        Now set up the Parasails preconditioner and specify any parameters
         call HYPRE_ParaSailsCreate(MPI_COMM_WORLD, precond,ierr)
         call HYPRE_ParaSailsSetParams(precond, 0.1d0, 1, ierr)
         call HYPRE_ParaSailsSetFilter(precond, 0.05d0, ierr)
         call HYPRE_ParaSailsSetSym(precond, 1)
         call HYPRE_ParaSailsSetLogging(precond, 3, ierr)

!c        set parsails as the pcg preconditioner
         precond_id = 4
         call HYPRE_ParCSRPCGSetPrecond(solver, precond_id,precond, ierr)


!c        Now setup and solve!
         call HYPRE_ParCSRPCGSetup(solver, parcsr_A, par_b,par_x, ierr)
         call HYPRE_ParCSRPCGSolve(solver, parcsr_A, par_b,par_x, ierr)


!c        Run info - needed logging turned on

        call HYPRE_ParCSRPCGGetNumIterations(solver, num_iterations,ierr)
        call HYPRE_ParCSRPCGGetFinalRelative(solver, final_res_norm, ierr)

       if ( myid .eq. 0 ) then
            print *
            print *, "Iterations = ", num_iterations
            print *, "Final Relative Residual Norm = ", final_res_norm
            print *
         endif

!c       Destroy precond and solver

        call HYPRE_ParaSailsDestroy(precond, ierr)
        call HYPRE_ParCSRPCGDestroy(solver, ierr)
!********************* end the PCG solver (with ParaSails preconditioner) ******
! start the ParCSR GMRES Solver
!c     GMRES
      elseif ( solver_id .eq. 11 ) then
!!!!      !c        Create solver
!!!!         call HYPRE_ParCSRGMRESCreate(MPI_COMM_WORLD, solver, ierr)
!!!!
!!!!!c        Set some parameters (See Reference Manual for more parameters)
!!!!         call HYPRE_ParCSRGMRESSetMaxIter(solver, 10**3, ierr) ! need to change
!!!!         call HYPRE_ParCSRGMRESSetTol(solver, 1.0d-7, ierr)
!!!!!         call HYPRE_ParCSRGMRESSetTwoNorm(solver, 2, ierr)
!!!!         call HYPRE_ParCSRGMRESSetPrintLevel(solver, 0, ierr)
!!!!         call HYPRE_ParCSRGMRESSetLogging(solver, 1, ierr)
!!!!
!!!!!c        Now set up the AMG preconditioner and specify any parameters
!!!!
!!!!         call HYPRE_BoomerAMGCreate(precond, ierr)
!!!!!t2 = second()
!!!!!write(*,*) 'AMGsolver 3 is:'
!!!!!write(*,*) t2-t1
!!!!!t1 = second()
!!!!
!!!!!c        Set some parameters (See Reference Manual for more parameters)
!!!!
!!!!!c        print less solver info since a preconditioner
!!!!         call HYPRE_BoomerAMGSetPrintLevel(precond, 0, ierr);
!!!!!c        Falgout coarsening
!!!!         call HYPRE_BoomerAMGSetCoarsenType(precond, 10, ierr)
!!!!!c        old defaults
!!!!!         call HYPRE_BoomerAMGSetOldDefault(precond, ierr)
!!!!!         call HYPRE_BoomerAMGSetCoarsenType( solver, 6, ierr)
!!!!         call HYPRE_BoomerAMGSetInterpType( precond, 6, ierr)
!!!!         call HYPRE_BoomerAMGSetPMaxElmts( precond, 2, ierr)
!!!!
!!!!!c        SYMMETRIC G-S/Jacobi hybrid relaxation (This is vital to adjust for our sysytem)
!!!!         call HYPRE_BoomerAMGSetRelaxType(precond, 0, ierr)
!!!!
!!!!
!!!!
!!!!!c        Sweeeps on each level
!!!!         call HYPRE_BoomerAMGSetNumSweeps(precond, 2, ierr)
!!!!!c        conv. tolerance
!!!!         call HYPRE_BoomerAMGSetTol(precond, 1.0d-7, ierr)
!!!!!c        do only one iteration!
!!!!         call HYPRE_BoomerAMGSetMaxIter(precond, 4, ierr)
!!!!
!!!!!c        set amg as the pcg preconditioner
!!!!         precond_id = 2
!!!!         call HYPRE_ParCSRGMRESSetPrecond(solver, precond_id,&
!!!!             precond, ierr)
!!!!
!!!!
!!!!!c        Now setup and solve!
!!!!         call HYPRE_ParCSRGMRESSetup(solver, parcsr_A, par_b,par_x,&
!!!!         ierr)
!!!!!         call HYPRE_ParCSRPCGSetup(solver, parcsr_A, par_b,par_x)
!!!!!         write(*,*) 'ierr is'
!!!!!         write(*,*) ierr
!!!!!t2 = second()
!!!!!write(*,*) 'AMGsolver 4 is:'
!!!!!write(*,*) t2-t1
!!!!!t1 = second()
!!!!         call HYPRE_ParCSRGMRESSolve(solver, parcsr_A, par_b,&
!!!!                                 par_x, ierr)
!!!!
!!!!!t2 = second()
!!!!!write(*,*) 'AMGsolver solve is:'
!!!!!write(*,*) t2-t1
!!!!!t1 = second()
!!!!!c        Run info - needed logging turned on
!!!!
!!!!!        call HYPRE_ParCSRGMRESGetNumIterations(solver, num_iterations,ierr)
!!!!!        call HYPRE_ParCSRGMRESGetFinalRelative(solver, final_res_norm,ierr)
!!!!!
!!!!!       if ( myid .eq. 0 ) then
!!!!!            print *
!!!!!            print *, "Iterations = ", num_iterations
!!!!!            print *, "Final Relative Residual Norm = ", final_res_norm
!!!!!            print *
!!!!!         endif
!!!!
!!!!!c       Destroy precond and solver
!!!!
!!!!        call HYPRE_BoomerAMGDestroy(precond, ierr)
!!!!        call HYPRE_ParCSRGMRESDestroy(solver, ierr)

      !c        Create solver
         call HYPRE_ParCSRGMRESCreate(MPI_COMM_WORLD, solver, ierr)

!c        Set some parameters (See Reference Manual for more parameters)
         call HYPRE_ParCSRGMRESSetMaxIter(solver, 10**3, ierr)
         call HYPRE_ParCSRGMRESSetTol(solver, 1.0d-11, ierr)
!         call HYPRE_ParCSRGMRESSetTwoNorm(solver, 1, ierr)
         call HYPRE_ParCSRGMRESSetPrintLevel(solver, 0, ierr)
         call HYPRE_ParCSRGMRESSetLogging(solver, 1, ierr)
!c        Now setup and solve!
         call HYPRE_ParCSRGMRESSetup(solver, parcsr_A, par_b,par_x, ierr)
         call HYPRE_ParCSRGMRESSolve(solver, parcsr_A, par_b,par_x, ierr)

!!         precond_id = 1 !(DS preconditioner)
!!         call HYPRE_ParCSRGMRESSetPrecond(solver, precond_id, &
!!             precond, ierr)
!c        Run info - needed logging turned on

!        call HYPRE_ParCSRGMRESGetNumIterations(solver, num_iterations,ierr)
!        call HYPRE_ParCSRGMRESGetFinalRelative(solver, final_res_norm, ierr)

!       if ( myid .eq. 0 ) then
!            print *
!            print *, "Iterations = ", num_iterations
!            print *, "Final Relative Residual Norm = ", final_res_norm
!            print *
!         endif

!c       Destroy solver

        call HYPRE_ParCSRGMRESDestroy(solver, ierr)


! start ParCSR FlexGMRES Solver
!c     FlexGMRES GMRES
      elseif ( solver_id .eq. 12 ) then
         call HYPRE_ParCSRFlexGMRESCreate(MPI_COMM_WORLD, solver, ierr)

!c        Set some parameters (See Reference Manual for more parameters)
         call HYPRE_ParCSRFlexGMRESSetMaxIter(solver, 1000, ierr)
         call HYPRE_ParCSRFlexGMRESSetTol(solver, 1.0d-7, ierr)
!         call HYPRE_ParCSRGMRESSetTwoNorm(solver, 1, ierr)
         call HYPRE_ParCSRFlexGMRESSetPrintLevel(solver, 2, ierr)
         call HYPRE_ParCSRFlexGMRESSetLogging(solver, 1, ierr)
!c        Now setup and solve!
         call HYPRE_ParCSRFlexGMRESSetup(solver, parcsr_A, par_b,par_x, ierr)
         call HYPRE_ParCSRFlexGMRESSolve(solver, parcsr_A, par_b,par_x, ierr)

         call HYPRE_ParCSRFlexGMRESDestroy(solver, ierr)

! start ParCSR LGMRES Solver
!  LGMRES
        elseif ( solver_id .eq. 13 ) then
            call HYPRE_ParCSRLGMRESCreate(MPI_COMM_WORLD, solver, ierr)

!c          Set some parameters (See Reference Manual for more parameters)
            call HYPRE_ParCSRLGMRESSetMaxIter(solver, 1000, ierr)
            call HYPRE_ParCSRLGMRESSetTol(solver, 1.0d-7, ierr)
!           call HYPRE_ParCSRGMRESSetTwoNorm(solver, 1, ierr)
            call HYPRE_ParCSRLGMRESSetPrintLevel(solver, 2, ierr)
            call HYPRE_ParCSRLGMRESSetLogging(solver, 1, ierr)
!c          Now setup and solve!
            call HYPRE_ParCSRLGMRESSetup(solver, parcsr_A, par_b,par_x, ierr)
            call HYPRE_ParCSRLGMRESSolve(solver, parcsr_A, par_b,par_x, ierr)

            call HYPRE_ParCSRLGMRESDestroy(solver, ierr)

! start ParCSR BiCGSTAB Solver
!   BiCGSTAB
        elseif ( solver_id .eq. 14 ) then
            call HYPRE_ParCSRBiCGSTABCreate(MPI_COMM_WORLD, solver, ierr)

!c          Set some parameters (See Reference Manual for more parameters)
            call HYPRE_ParCSRBiCGSTABSetMaxIter(solver, 1000, ierr)
            call HYPRE_ParCSRBiCGSTABSetTol(solver, 1.0d-11, ierr)
!           call HYPRE_ParCSRGMRESSetTwoNorm(solver, 1, ierr)
!            call HYPRE_ParCSRBiCGSTABSetPrintLevel(solver, 2, ierr)
!            call HYPRE_ParCSRBiCGSTABSetLogging(solver, 1, ierr)
!c          Now setup and solve!
            call HYPRE_ParCSRBiCGSTABSetup(solver, parcsr_A, par_b,par_x, ierr)
            call HYPRE_ParCSRBiCGSTABSolve(solver, parcsr_A, par_b,par_x, ierr)

            call HYPRE_ParCSRBiCGSTABDestroy(solver, ierr)

 ! start ParCSR Hybrid Solver
 ! Hybrid
        elseif ( solver_id .eq. 15 ) then
            call HYPRE_ParCSRHybridCreate(solver, ierr)
!c          Set some parameters (See Reference Manual for more parameters)
!            call HYPRE_ParCSRHybridSetMaxIter(solver, 1000, ierr)
            call HYPRE_ParCSRHybridSetTol(solver, 1.0d-7, ierr)
           call HYPRE_ParCSRHybridSetTwoNorm(solver, 1, ierr)
            call HYPRE_ParCSRHybridSetPrintLevel(solver, 2, ierr)
            call HYPRE_ParCSRHybridSetLogging(solver, 1, ierr)
!c          Now setup and solve!
            call HYPRE_ParCSRHybridSetup(solver, parcsr_A, par_b,par_x, ierr)
            call HYPRE_ParCSRHybridSolve(solver, parcsr_A, par_b,par_x, ierr)

            call HYPRE_ParCSRHybridDestroy(solver, ierr)

!      else
!         if ( myid .eq. 0 ) then
!           print *,'Invalid solver id specified'
!           stop
!         endif
      endif

!c     Print the solution
      if ( print_solution .ne. 0 ) then
!         call HYPRE_IJVectorPrint(x, "ij", ierr)
!call HYPRE_IJVectorSetValues(b, local_size, rows, rhs_values, ierr)
          call HYPRE_IJVectorGetValues(x_hat, local_size, rows, g, ierr)
!         call HYPRE_IJVectorPrint(x, g, ierr)
      endif

!c     Clean up

      call HYPRE_IJMatrixDestroy(AA, ierr)
      call HYPRE_IJVectorDestroy(bb, ierr)
      call HYPRE_IJVectorDestroy(x_hat, ierr)

!!!c     Finalize MPI
!!      call MPI_Finalize(ierr)
!open(1,file='ij.00000')

!!!write(*,*) 'g(1,1)'
!!!write(*,*) g(1,1)
!!!write(*,*) 'g(2,1),g(3,1)'
!!!write(*,*) g(2,1),g(3,1)
!!!write(*,*) 'g(4,1),g(5,1),g(6,1),g(7,1)'
!!!write(*,*) g(4,1),g(5,1),g(6,1),g(7,1)

!read(1,*) ( g(ii,1),g(ii,2), ii=1,50)
!close(1)

      return


end subroutine BDF2GMRES_solver
