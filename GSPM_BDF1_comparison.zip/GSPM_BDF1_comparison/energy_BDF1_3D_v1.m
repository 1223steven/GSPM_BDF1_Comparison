% A test problem for 2nd-order Semi-Implicit method
% solve the Laudau-Lifshitz eqn 
% 
% BDF2 with damping
%
% clear all;
% clc; close all; clear; 
format long;
% h = waitbar(0,'Please wait...'); % build the process bar
tic;
xleft = 0.0;
xright = 1.0;
yleft = 0.0;
yright = 1.0;
zleft = 0.0;
zright = 1.0;
T = 1.d-1;
T0 = 0.0;

Nx = 20.0; 
Ny = 20.0;
Nz = 20.0;
nnl = 3*Nx*Ny*Nz;
% nn_BDF1 = 925696; %136(2); %1472(4); %13312(8); %112640(16); %925696(32); % obtained by code: D3_BDF2_Damp_initialize_v2.f95 ; file: BDF1_counter
% nn = 222400; %288(2); %3168(4); %28800(8); %244224(16);482400(20);1652400(30) %2009088(32); % obtained by code: D3_BDF2_Damp_initialize_v2.f95; file: BDF2_counter_iter
dx = (xright-xleft)/Nx; % for BDF2: 63*N^3-54*N^2
dy = (yright-yleft)/Ny; % for BDF1: 29*N^3-24*N^2
dz = (zright-zleft)/Nz;


x = xleft+dx/2:dx:xright-dx/2;
y = yleft+dy/2:dy:yright-dy/2;
z = zleft+dz/2:dz:zright-dz/2;

% X = x.^2.*(ones(1,Nx)-x).^2;        % change variable 
% X_prime = 4*x.^3-6*x.^2+2*x;         % the derivative of X
% X_prime_2 = 12*x.^2-12*x+2*ones(1,Nx); % the derivative of X_prime
% 
% Y = y.^2.*(ones(1,Ny)-y).^2;        % change variable 
% Y_prime = 4*y.^3-6*y.^2+2*y;         % the derivative of X
% Y_prime_2 = 12*y.^2-12*y+2*ones(1,Ny); % the derivative of X_prime
% 
% Z = z.^2.*(ones(1,Nz)-z).^2;        % change variable 
% Z_prime = 4*z.^3-6*z.^2+2*z;         % the derivative of X
% Z_prime_2 = 12*z.^2-12*z+2*ones(1,Nz); % the derivative of X_prime

Nt = 40;
dt = (T-T0)/Nt;
% damping parameter
% alpha = 1.d-3;
% alpha = 1.d-2;

alpha = 0.01;

% alpha = 0.d0;
tol = 1.d-11;
maxit = 10^3;
% tic;

% initial condition

m0 = zeros(3*Nx,Ny,Nz);
% mt = m0;
m1 = m0;
% toc;
% tic;
% the first initialized strategy (according to the exact sol)

t = T0;
% for k=1:Nz
%     for j=1:Ny
% %     m0(:,j,k) = [cos(X'*Y(j)*Z(k))*sin(t); 
% %                  sin(X'*Y(j)*Z(k))*sin(t); 
% %                  ones(size(X'))*cos(t)];  
%              
%     m0(:,j,k) = [cos(cos(pi*x'))*sin(0.01);
%                  sin(cos(pi*x'))*sin(0.01);
%                  ones(size(x'))*cos(0.01)];
%              
%     end
% end

% Init S state

% for k = 1:Nz
%     for j = 1:Ny
%         for i = 1:Nx
%             if x(i) < xright/5.0
%                 m0(i,j,k) = 0.0;
%                 m0(i+Nx,j,k) = 1.0;
%                 m0(i+2*Nx,j,k) = 0.0;
%             elseif x(i) > 4.0*xright/5.0
%                 m0(i,j,k) = 0.0;
%                 m0(i+Nx,j,k) = 1.0;
%                 m0(i+2*Nx,j,k) = 0.0;
%             else
%                 m0(i,j,k) = 1.0;
%                 m0(i+Nx,j,k) = 0.0;
%                 m0(i+2*Nx,j,k) = 0.0;
%             end
%         end
%     end
% end


% Init C state

for k = 1:Nz
    for j = 1:Ny
        for i = 1:Nx
            if x(i) < xright/5.0
                m0(i,j,k) = 0.0;
                m0(i+Nx,j,k) = 1.0;
                m0(i+2*Nx,j,k) = 0.0;
            elseif x(i) > 4.0*xright/5.0
                m0(i,j,k) = 0.0;
                m0(i+Nx,j,k) = -1.0;
                m0(i+2*Nx,j,k) = 0.0;
            else
                m0(i,j,k) = 1.0;
                m0(i+Nx,j,k) = 0.0;
                m0(i+2*Nx,j,k) = 0.0;
            end
        end
    end
end



% t = T0 + dt;
% for k=1:Nz
%     for j=1:Ny
%       m1(:,j,k) = [cos(cos(pi*x')*cos(pi*y(j))*cos(pi*z(k)))*sin(t);
%                    sin(cos(pi*x')*cos(pi*y(j))*cos(pi*z(k)))*sin(t);
%                    ones(size(x'))*cos(t)];
%     end
% end

% toc;
% tic;
% % m0_prime = m0;
%============================================
% to get the second step using BDF1

% Create the sparse matrix for block
e = ones(Nx,1);
Ax = spdiags([e -2*e e],-1:1,Nx,Nx);
Ax(1,1) = -1; 
Ax(Nx,Nx) = -1;
Ax = dt*Ax/dx^2;
Iy = dt/dy^2*speye(Nx,Nx);
Iz = dt/dz^2*speye(Nx,Nx);
Cy = zeros(3*Nx,3*Nx);
Cz = Cy;
E = Cy;
% the right hand side term
% b2 = m0;
% b3 = m0;
b = m0;
% nonzero_row_index = zeros(nn_BDF1,1);
% nonzero_col_index = zeros(nn_BDF1,1);
% nonzero_value = zeros(nn_BDF1,1);
EPS = 0;

% m = reshape(m1,3*Nx*Ny*Nz,1);

%============================================

% t = T0 + dt;
% for k=1:Nz
%     for j=1:Ny
%       m1(:,j,k) = [cos(X'*Y(j)*Z(k))*sin(t); 
%                    sin(X'*Y(j)*Z(k))*sin(t); 
%                    ones(size(X'))*cos(t)];  
%     end
% end
% m1 = reshape(m1,3*Nx*Ny*Nz,1);

% err = max(abs(m-m1)) % the infty norm

% % m1_prime = m1;
% m = reshape(m1,3*Nx*Ny*Nz,1)
% reinitialize for diag element
% nonzero_row_index = zeros(nn,1);
% nonzero_col_index = zeros(nn,1);
% nonzero_value = zeros(nn,1);

x_exact_prime = zeros(1,3,Nx,Ny,Nz);
y_exact_prime = zeros(1,3,Nx,Ny,Nz);
z_exact_prime = zeros(1,3,Nx,Ny,Nz);
       
difference_x = zeros(size(x_exact_prime));
difference_y = zeros(size(y_exact_prime));
difference_z = zeros(size(z_exact_prime));

mt_p = zeros(3*Nx,Ny,Nz);

En = zeros(1,Nt+1);
% En = zeros(1,Nt);

mt_p = m0;
% ----- energy ----
for k=1:Nz
    for j=1:Ny
        for i=1:Nx
            
            if i==1
                difference_x(:,:,i,j,k) =[(-mt_p(1,j,k)+mt_p(2,j,k))/(2*dx),...
                                          (-mt_p(Nx+1,j,k)+mt_p(Nx+2,j,k))/(2*dx),...
                                          (-mt_p(2*Nx+1,j,k)+mt_p(2*Nx+2,j,k))/(2*dx)];
                                      
                                      
           
            
            elseif i==Nx
                difference_x(:,:,i,j,k) = [(-mt_p(Nx-1,j,k)+mt_p(Nx,j,k))/(2*dx),...
                                           (-mt_p(Nx+Nx-1,j,k)+mt_p(Nx+Nx,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+Nx-1,j,k)+mt_p(2*Nx+Nx,j,k))/(2*dx)];
                                       
            
            
            else
                difference_x(:,:,i,j,k) = [(-mt_p(i-1,j,k)+0*mt_p(i,j,k)+mt_p(i+1,j,k))/(2*dx),...
                                           (-mt_p(Nx+i-1,j,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i+1,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+i-1,j,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i+1,j,k))/(2*dx)];
                                       
               
            end
         
            
            if j==1
                
                                      
                difference_y(:,:,i,j,k) =[(-mt_p(i,1,k)+mt_p(i,2,k))/(2*dy),...
                                          (-mt_p(Nx+i,1,k)+mt_p(Nx+i,2,k))/(2*dy),...
                                          (-mt_p(2*Nx+i,1,k)+mt_p(2*Nx+i,2,k))/(2*dy)];
                                      
                
                                      
            
            
            elseif j==Ny
                
                                       
                difference_y(:,:,i,j,k) = [(-mt_p(i,Ny-1,k)+mt_p(i,Ny,k))/(2*dy),...
                                           (-mt_p(Nx+i,Ny-1,k)+mt_p(Nx+i,Ny,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,Ny-1,k)+mt_p(2*Nx+i,Ny,k))/(2*dy)];
                                       
                
            
            
                  
                 
            else
                
                difference_y(:,:,i,j,k) = [(-mt_p(i,j-1,k)+0*mt_p(i,j,k)+mt_p(i,j+1,k))/(2*dy),...
                                           (-mt_p(Nx+i,j-1,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j+1,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,j-1,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j+1,k))/(2*dy)];
                                       
                 
            end
            
            if k==1
                
                difference_z(:,:,i,j,k) =[(-mt_p(i,j,1)+mt_p(i,j,2))/(2*dz),...
                                          (-mt_p(Nx+i,j,1)+mt_p(Nx+i,j,2))/(2*dz),...
                                          (-mt_p(2*Nx+i,j,1)+mt_p(2*Nx+i,j,2))/(2*dz)];
                                      
            
            elseif k==Nz
                            
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,Nz-1)+mt_p(i,j,Nz))/(2*dz),...
                                           (-mt_p(Nx+i,j,Nz-1)+mt_p(Nx+i,j,Nz))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,Nz-1)+mt_p(2*Nx+i,j,Nz))/(2*dz)];
            
            
            
            else
                        
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,k-1)+0*mt_p(i,j,k)+mt_p(i,j,k+1))/(2*dz),...
                                           (-mt_p(Nx+i,j,k-1)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j,k+1))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,k-1)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j,k+1))/(2*dz)];
                                       
            end
            
%             difference_x(:,:,i,j,k) = [(mt_p(i+1,j,k)-mt_p(i,j,k))/dx, (mt_p(Nx+i+1,j,k)-mt_p(Nx+i,j,k))/dx, (mt_p(2*(Nx-1)+i+3,j,k)-mt_p(2*(Nx-1)+i+2,j,k))/dx];          
        end
    end
end

% comput 
En(1,1) = sum(sum(sum(sum(difference_x.^2 + difference_y.^2 + difference_z.^2))))*dx*dy*dz;
 
% toc;
for nsteps=1:Nt
% nsteps = 2;

t =  T0 + (nsteps-1)*dt;

mm = m0;
mhat = m0;

% mhat_reshape(:,:,:,1) = mhat(1:Nx,:,:);
% mhat_reshape(:,:,:,2) = mhat(Nx+1:2*Nx,:,:);
% mhat_reshape(:,:,:,3) = mhat(2*Nx+1:3*Nx,:,:);
% 
% % [r_norm3] = NablaNormSq_3rd( Nx, Ny, Nz, dx, dy, dz, mhat_reshape );
% [r_norm3] = NablaNormSq_v3( Nx, Ny, Nz, dx, dy, dz, mhat_reshape );
% 
% malpha(1:Nx,:,:) = r_norm3.*mhat(1:Nx,:,:);
% malpha(Nx+1:2*Nx,:,:) = r_norm3.*mhat(Nx+1:2*Nx,:,:);
% malpha(2*Nx+1:3*Nx,:,:) = r_norm3.*mhat(2*Nx+1:3*Nx,:,:);

% t2 =  T0 + (nsteps-2)*dt;
% t3 =  T0 + (nsteps-1)*dt;
% tic;
for k=1:Nz
    for j=1:Ny
%        phi = (Y(j)*Z(k))^2*(X_prime).^2+(X*Z(k)).^2*(Y_prime(j))^2+(X*Y(j)).^2*(Z_prime(k))^2;
%        psi = Y(j)*Z(k)*X_prime_2+X*Z(k)*Y_prime_2(j)+X*Y(j)*Z_prime_2(k);
%        b2(:,j,k) = [cos(t2)*cos(X'*Y(j)*Z(k))+sin(t2)*cos(t2)*(sin(X'*Y(j)*Z(k)).*phi'-cos(X'*Y(j)*Z(k)).*psi')+alpha*(cos(t2)*cos(t2)*sin(t2)*cos(X'*Y(j)*Z(k)).*phi'+sin(t2)*sin(X'*Y(j)*Z(k)).*psi');
%                    cos(t2)*sin(X'*Y(j)*Z(k))-sin(t2)*cos(t2)*(cos(X'*Y(j)*Z(k)).*phi'+sin(X'*Y(j)*Z(k)).*psi')+alpha*(cos(t2)*cos(t2)*sin(t2)*sin(X'*Y(j)*Z(k)).*phi'-sin(t2)*cos(X'*Y(j)*Z(k)).*psi');
%                    -sin(t2)*ones(Nx,1)+sin(t2)*sin(t2)*psi'-alpha*sin(t2)*sin(t2)*cos(t2)*phi'];
               
%        b3(:,j,k) = [cos(t3)*cos(X'*Y(j)*Z(k))+sin(t3)*cos(t3)*(sin(X'*Y(j)*Z(k)).*phi'-cos(X'*Y(j)*Z(k)).*psi')+alpha*(cos(t3)*cos(t3)*sin(t3)*cos(X'*Y(j)*Z(k)).*phi'+sin(t3)*sin(X'*Y(j)*Z(k)).*psi');
%                    cos(t3)*sin(X'*Y(j)*Z(k))-sin(t3)*cos(t3)*(cos(X'*Y(j)*Z(k)).*phi'+sin(X'*Y(j)*Z(k)).*psi')+alpha*(cos(t3)*cos(t3)*sin(t3)*sin(X'*Y(j)*Z(k)).*phi'-sin(t3)*cos(X'*Y(j)*Z(k)).*psi');
%                    -sin(t3)*ones(Nx,1)+sin(t3)*sin(t3)*psi'-alpha*sin(t3)*sin(t3)*cos(t3)*phi'];

       a = cos(pi*x)*cos(pi*y(j))*cos(pi*z(k));
       ax = -pi*sin(pi*x)*cos(pi*y(j))*cos(pi*z(k));
       ay = -pi*sin(pi*y(j))*cos(pi*x)*cos(pi*z(k));
       az = -pi*sin(pi*z(k))*cos(pi*x)*cos(pi*y(j));
       
       % for sol
       u = cos(a)*sin(t);
       v = sin(a)*sin(t);
       w = ones(size(a))*cos(t);
       
       ux = -sin(a).*ax*sin(t);
       vx = cos(a).*ax*sin(t);
       wx = zeros(size(a));
       
       uy = -sin(a).*ay*sin(t);
       vy = cos(a).*ay*sin(t);
       wy = zeros(size(a));
       
       uz = -sin(a).*az*sin(t);
       vz = cos(a).*az*sin(t);
       wz = zeros(size(a));
       
       
       uxx = -cos(a).*ax.*ax*sin(t)-sin(a)*(-pi^2).*a*sin(t);
       uyy = -cos(a).*ay.*ay*sin(t)-sin(a)*(-pi^2).*a*sin(t);
       uzz = -cos(a).*az.*az*sin(t)-sin(a)*(-pi^2).*a*sin(t);
       du = uxx+uyy+uzz;
       
       vxx = -sin(a).*ax.*ax*sin(t)+cos(a)*(-pi^2).*a*sin(t);
       vyy = -sin(a).*ay.*ay*sin(t)+cos(a)*(-pi^2).*a*sin(t);
       vzz = -sin(a).*az.*az*sin(t)+cos(a)*(-pi^2).*a*sin(t);
       dv = vxx+vyy+vzz;
       
       wxx = zeros(size(a));
       wyy = zeros(size(a));
       wzz = zeros(size(a));
       dw = wxx+wyy+wzz;
       
       ut = cos(a)*cos(t);
       vt = sin(a)*cos(t);
       wt = -ones(size(a))*sin(t);
       
               
       b(:,j,k) = [(ut +(v.*dw-w.*dv)+alpha*(v.*(u.*dv-v.*du)-w.*(w.*du-u.*dw) ) )';
                   (vt +(w.*du-u.*dw)+alpha*(w.*(v.*dw-w.*dv)-u.*(u.*dv-v.*du) ) )';
                   (wt +(u.*dv-v.*du)+alpha*(u.*(w.*du-u.*dw)-v.*(v.*dw-w.*dv) ) )'];
               
    end
end

% toc;
% tic;
% b1 = 2.0*reshape(m1,3*Nx*Ny*Nz,1)-1.0/2.0*reshape(m0,3*Nx*Ny*Nz,1)+dt*reshape(2*b3-b2,3*Nx*Ny*Nz,1); % extrapolation
% b1 = 2.0*reshape(m1,3*Nx*Ny*Nz,1)-1.0/2.0*reshape(m0,3*Nx*Ny*Nz,1)+dt*reshape(b2,3*Nx*Ny*Nz,1);
% b1 = reshape(mm,3*Nx*Ny*Nz,1)+dt*reshape(b2,3*Nx*Ny*Nz,1)+alpha*dt*reshape(malpha,3*Nx*Ny*Nz,1);

% b1 = reshape(mm,3*Nx*Ny*Nz,1)+dt*reshape(b,3*Nx*Ny*Nz,1);

b1 = reshape(mm,3*Nx*Ny*Nz,1);

counter = 0;

for kk = 1:Nz
   for jj=1:Ny

       Cy(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,jj,kk)).^2+(mhat(2*Nx+1:3*Nx,jj,kk)).^2))*Iy,...
                  -sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)-alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iy,...
                  sparse(diag(mhat(Nx+1:2*Nx,jj,kk)+alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iy;
                  sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)+alpha*(mhat(1:Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iy,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,jj,kk)).^2+(mhat(1:Nx,jj,kk)).^2))*Iy,...
                  -sparse(diag(mhat(1:Nx,jj,kk)-alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iy;
                  -sparse(diag(mhat(Nx+1:2*Nx,jj,kk)-alpha*(mhat(1:Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iy,...
                  sparse(diag(mhat(1:Nx,jj,kk)+alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iy,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,jj,kk)).^2+(mhat(Nx+1:2*Nx,jj,kk)).^2))*Iy];

       Cz(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,jj,kk)).^2+(mhat(2*Nx+1:3*Nx,jj,kk)).^2))*Iz,...
                  -sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)-alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iz,...
                  sparse(diag(mhat(Nx+1:2*Nx,jj,kk)+alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iz;
                  sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)+alpha*(mhat(1:Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iz,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,jj,kk)).^2+(mhat(1:Nx,jj,kk)).^2))*Iz,...
                  -sparse(diag(mhat(1:Nx,jj,kk)-alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iz;
                  -sparse(diag(mhat(Nx+1:2*Nx,jj,kk)-alpha*(mhat(1:Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iz,...
                  sparse(diag(mhat(1:Nx,jj,kk)+alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iz,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,jj,kk)).^2+(mhat(Nx+1:2*Nx,jj,kk)).^2))*Iz];

        E(:,:) = [speye(Nx,Nx)-alpha*sparse(diag((mhat(Nx+1:2*Nx,jj,kk)).^2+(mhat(2*Nx+1:3*Nx,jj,kk)).^2))*(Ax-Iy-Iz),...
                  -sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)-alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*(Ax-Iy-Iz),...
                  sparse(diag(mhat(Nx+1:2*Nx,jj,kk)+alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*(Ax-Iy-Iz);
                  sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)+alpha*(mhat(1:Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*(Ax-Iy-Iz),...
                  speye(Nx,Nx)-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,jj,kk)).^2+(mhat(1:Nx,jj,kk)).^2))*(Ax-Iy-Iz),...
                  -sparse(diag(mhat(1:Nx,jj,kk)-alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*(Ax-Iy-Iz);
                  -sparse(diag(mhat(Nx+1:2*Nx,jj,kk)-alpha*(mhat(1:Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*(Ax-Iy-Iz),...
                  sparse(diag(mhat(1:Nx,jj,kk)+alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*(Ax-Iy-Iz),...
                  speye(Nx,Nx)-alpha*sparse(diag((mhat(1:Nx,jj,kk)).^2+(mhat(Nx+1:2*Nx,jj,kk)).^2))*(Ax-Iy-Iz)]; 
     

       % one error: jj, and kk
       
%        Cy(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,j,k)).^2+(mhat(2*Nx+1:3*Nx,j,k)).^2))*Iy,...
%                        -sparse(diag(mhat(2*Nx+1:3*Nx,j,k)-alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iy,...
%                        sparse(diag(mhat(Nx+1:2*Nx,j,k)+alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iy;
%                        sparse(diag(mhat(2*Nx+1:3*Nx,j,k)+alpha*(mhat(1:Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iy,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,j,k)).^2+(mhat(1:Nx,j,k)).^2))*Iy,...
%                        -sparse(diag(mhat(1:Nx,j,k)-alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iy;
%                        -sparse(diag(mhat(Nx+1:2*Nx,j,k)-alpha*(mhat(1:Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iy,...
%                        sparse(diag(mhat(1:Nx,j,k)+alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iy,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,j,k)).^2+(mhat(Nx+1:2*Nx,j,k)).^2))*Iy];
%                    
%         Cz(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,j,k)).^2+(mhat(2*Nx+1:3*Nx,j,k)).^2))*Iz,...
%                        -sparse(diag(mhat(2*Nx+1:3*Nx,j,k)-alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iz,...
%                        sparse(diag(mhat(Nx+1:2*Nx,j,k)+alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iz;
%                        sparse(diag(mhat(2*Nx+1:3*Nx,j,k)+alpha*(mhat(1:Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iz,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,j,k)).^2+(mhat(1:Nx,j,k)).^2))*Iz,...
%                        -sparse(diag(mhat(1:Nx,j,k)-alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iz;
%                        -sparse(diag(mhat(Nx+1:2*Nx,j,k)-alpha*(mhat(1:Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iz,...
%                        sparse(diag(mhat(1:Nx,j,k)+alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iz,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,j,k)).^2+(mhat(Nx+1:2*Nx,j,k)).^2))*Iz];
% 
%         E(:,:) = [3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((mhat(Nx+1:2*Nx,j,k)).^2+(mhat(2*Nx+1:3*Nx,j,k)).^2))*S,...
%                      -sparse(diag(mhat(2*Nx+1:3*Nx,j,k)-alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(1:Nx,j,k))))*S,...
%                      sparse(diag(mhat(Nx+1:2*Nx,j,k)+alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(1:Nx,j,k))))*S;
%                      sparse(diag(mhat(2*Nx+1:3*Nx,j,k)+alpha*(mhat(1:Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*S,...
%                      3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,j,k)).^2+(mhat(1:Nx,j,k)).^2))*S,...
%                      -sparse(diag(mhat(1:Nx,j,k)-alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*S;
%                      -sparse(diag(mhat(Nx+1:2*Nx,j,k)-alpha*(mhat(1:Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*S,...
%                      sparse(diag(mhat(1:Nx,j,k)+alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*S,...
%                      3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((mhat(1:Nx,j,k)).^2+(mhat(Nx+1:2*Nx,j,k)).^2))*S]; 
%         


       
%         if (kk==1)&&(jj==Ny)
%             E2=E(:,:);
%         end
                 
        for ii=1:3*Nx
            for ll=1:3*Nx
                if abs(Cy(ii,ll))>EPS
                    if jj == 1
%                         nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+ii;
%                         nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx+ll;
%                         nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;
                    elseif jj==Ny
%                         nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(Ny-1)+ii;
%                         nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(Ny-2)+ll;
%                         nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;
                    else 
%                         nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii;
%                         nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-2)+ll;
%                         nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;

%                         nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii;
%                         nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*jj+ll;
%                         nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;
                    end          
                end
                
                if abs(E(ii,ll))>EPS
                    if (kk==1)&&(jj==1)
%                         nonzero_row_index(counter+1,1) = ii;
%                         nonzero_col_index(counter+1,1) = ll;
%                         nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk==1)&&(jj==Ny)
%                         nonzero_row_index(counter+1,1) = 3*Nx*(Ny-1)+ii;
%                         nonzero_col_index(counter+1,1) = 3*Nx*(Ny-1)+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                        
                        
                    end
                    
                    if (kk==Nz)&&(jj==1)&&(Nz>=2)
%                         nonzero_row_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+ii;
%                         nonzero_col_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk==Nz)&&(jj==Ny)&&(Nz>=2)
%                         nonzero_row_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ii;
%                         nonzero_col_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(E(ii,ll)-Cy(ii,ll))>EPS
                    if (jj~=1)&&(jj~=Ny)&&(kk==1)
%                         nonzero_row_index(counter+1,1) = 3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll)-Cy(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (jj~=1)&&(jj~=Ny)&&(kk==Nz)&&(Nz>=2)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll)-Cy(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(E(ii,ll)-Cz(ii,ll))>EPS
                    if (kk~=1)&&(kk~=Nz)&&(jj==1)&&(Nz>=3)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+ii;
%                         nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll)-Cz(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk~=1)&&(kk~=Nz)&&(jj==Ny)&&(Nz>=3)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll)-Cz(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(E(ii,ll)-Cy(ii,ll)-Cz(ii,ll))>EPS
                    if (kk~=1)&&(kk~=Nz)&&(jj~=1)&&(jj~=Ny)&&(Nz>=3)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = E(ii,ll)-Cy(ii,ll)-Cz(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(Cz(ii,ll))>EPS
                    if (kk==1)&&(Nz>=2)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*kk*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk==Nz)&&(Nz>=2)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk~=1)&&(kk~=Nz)&&(Nz>=3)
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*kk*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                        
%                         nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
%                         nonzero_col_index(counter+1,1) = 3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll;
%                         nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                    end
                end 
            end
        
        end
       
   end
end

nonzero_row_index = zeros(counter,1);
nonzero_col_index = zeros(counter,1);
nonzero_value = zeros(counter,1);


% generate the index (row and colomn) and corresponding value
counter = 0;

for kk = 1:Nz
   for jj=1:Ny

       Cy(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,jj,kk)).^2+(mhat(2*Nx+1:3*Nx,jj,kk)).^2))*Iy,...
                  -sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)-alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iy,...
                  sparse(diag(mhat(Nx+1:2*Nx,jj,kk)+alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iy;
                  sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)+alpha*(mhat(1:Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iy,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,jj,kk)).^2+(mhat(1:Nx,jj,kk)).^2))*Iy,...
                  -sparse(diag(mhat(1:Nx,jj,kk)-alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iy;
                  -sparse(diag(mhat(Nx+1:2*Nx,jj,kk)-alpha*(mhat(1:Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iy,...
                  sparse(diag(mhat(1:Nx,jj,kk)+alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iy,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,jj,kk)).^2+(mhat(Nx+1:2*Nx,jj,kk)).^2))*Iy];

       Cz(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,jj,kk)).^2+(mhat(2*Nx+1:3*Nx,jj,kk)).^2))*Iz,...
                  -sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)-alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iz,...
                  sparse(diag(mhat(Nx+1:2*Nx,jj,kk)+alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*Iz;
                  sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)+alpha*(mhat(1:Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iz,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,jj,kk)).^2+(mhat(1:Nx,jj,kk)).^2))*Iz,...
                  -sparse(diag(mhat(1:Nx,jj,kk)-alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*Iz;
                  -sparse(diag(mhat(Nx+1:2*Nx,jj,kk)-alpha*(mhat(1:Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iz,...
                  sparse(diag(mhat(1:Nx,jj,kk)+alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*Iz,...
                  sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,jj,kk)).^2+(mhat(Nx+1:2*Nx,jj,kk)).^2))*Iz];

        E(:,:) = [speye(Nx,Nx)-alpha*sparse(diag((mhat(Nx+1:2*Nx,jj,kk)).^2+(mhat(2*Nx+1:3*Nx,jj,kk)).^2))*(Ax-Iy-Iz),...
                  -sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)-alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*(Ax-Iy-Iz),...
                  sparse(diag(mhat(Nx+1:2*Nx,jj,kk)+alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(1:Nx,jj,kk))))*(Ax-Iy-Iz);
                  sparse(diag(mhat(2*Nx+1:3*Nx,jj,kk)+alpha*(mhat(1:Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*(Ax-Iy-Iz),...
                  speye(Nx,Nx)-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,jj,kk)).^2+(mhat(1:Nx,jj,kk)).^2))*(Ax-Iy-Iz),...
                  -sparse(diag(mhat(1:Nx,jj,kk)-alpha*(mhat(2*Nx+1:3*Nx,jj,kk)).*(mhat(Nx+1:2*Nx,jj,kk))))*(Ax-Iy-Iz);
                  -sparse(diag(mhat(Nx+1:2*Nx,jj,kk)-alpha*(mhat(1:Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*(Ax-Iy-Iz),...
                  sparse(diag(mhat(1:Nx,jj,kk)+alpha*(mhat(Nx+1:2*Nx,jj,kk)).*(mhat(2*Nx+1:3*Nx,jj,kk))))*(Ax-Iy-Iz),...
                  speye(Nx,Nx)-alpha*sparse(diag((mhat(1:Nx,jj,kk)).^2+(mhat(Nx+1:2*Nx,jj,kk)).^2))*(Ax-Iy-Iz)]; 
     

       % one error: jj, and kk
       
%        Cy(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,j,k)).^2+(mhat(2*Nx+1:3*Nx,j,k)).^2))*Iy,...
%                        -sparse(diag(mhat(2*Nx+1:3*Nx,j,k)-alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iy,...
%                        sparse(diag(mhat(Nx+1:2*Nx,j,k)+alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iy;
%                        sparse(diag(mhat(2*Nx+1:3*Nx,j,k)+alpha*(mhat(1:Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iy,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,j,k)).^2+(mhat(1:Nx,j,k)).^2))*Iy,...
%                        -sparse(diag(mhat(1:Nx,j,k)-alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iy;
%                        -sparse(diag(mhat(Nx+1:2*Nx,j,k)-alpha*(mhat(1:Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iy,...
%                        sparse(diag(mhat(1:Nx,j,k)+alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iy,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,j,k)).^2+(mhat(Nx+1:2*Nx,j,k)).^2))*Iy];
%                    
%         Cz(:,:) = [sparse(zeros(Nx))-alpha*sparse(diag((mhat(Nx+1:2*Nx,j,k)).^2+(mhat(2*Nx+1:3*Nx,j,k)).^2))*Iz,...
%                        -sparse(diag(mhat(2*Nx+1:3*Nx,j,k)-alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iz,...
%                        sparse(diag(mhat(Nx+1:2*Nx,j,k)+alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(1:Nx,j,k))))*Iz;
%                        sparse(diag(mhat(2*Nx+1:3*Nx,j,k)+alpha*(mhat(1:Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iz,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,j,k)).^2+(mhat(1:Nx,j,k)).^2))*Iz,...
%                        -sparse(diag(mhat(1:Nx,j,k)-alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*Iz;
%                        -sparse(diag(mhat(Nx+1:2*Nx,j,k)-alpha*(mhat(1:Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iz,...
%                        sparse(diag(mhat(1:Nx,j,k)+alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*Iz,...
%                        sparse(zeros(Nx))-alpha*sparse(diag((mhat(1:Nx,j,k)).^2+(mhat(Nx+1:2*Nx,j,k)).^2))*Iz];
% 
%         E(:,:) = [3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((mhat(Nx+1:2*Nx,j,k)).^2+(mhat(2*Nx+1:3*Nx,j,k)).^2))*S,...
%                      -sparse(diag(mhat(2*Nx+1:3*Nx,j,k)-alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(1:Nx,j,k))))*S,...
%                      sparse(diag(mhat(Nx+1:2*Nx,j,k)+alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(1:Nx,j,k))))*S;
%                      sparse(diag(mhat(2*Nx+1:3*Nx,j,k)+alpha*(mhat(1:Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*S,...
%                      3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((mhat(2*Nx+1:3*Nx,j,k)).^2+(mhat(1:Nx,j,k)).^2))*S,...
%                      -sparse(diag(mhat(1:Nx,j,k)-alpha*(mhat(2*Nx+1:3*Nx,j,k)).*(mhat(Nx+1:2*Nx,j,k))))*S;
%                      -sparse(diag(mhat(Nx+1:2*Nx,j,k)-alpha*(mhat(1:Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*S,...
%                      sparse(diag(mhat(1:Nx,j,k)+alpha*(mhat(Nx+1:2*Nx,j,k)).*(mhat(2*Nx+1:3*Nx,j,k))))*S,...
%                      3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((mhat(1:Nx,j,k)).^2+(mhat(Nx+1:2*Nx,j,k)).^2))*S]; 
%         


       
%         if (kk==1)&&(jj==Ny)
%             E2=E(:,:);
%         end
                 
        for ii=1:3*Nx
            for ll=1:3*Nx
                if abs(Cy(ii,ll))>EPS
                    if jj == 1
                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+ii;
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx+ll;
                        nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;
                    elseif jj==Ny
                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(Ny-1)+ii;
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(Ny-2)+ll;
                        nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;
                    else 
                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii;
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-2)+ll;
                        nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;

                        nonzero_row_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*(jj-1)+ii;
                        nonzero_col_index(counter+1,1) = (kk-1)*3*Nx*Ny+3*Nx*jj+ll;
                        nonzero_value(counter+1,1) = Cy(ii,ll);
                        counter = counter+1;
                    end          
                end
                
                if abs(E(ii,ll))>EPS
                    if (kk==1)&&(jj==1)
                        nonzero_row_index(counter+1,1) = ii;
                        nonzero_col_index(counter+1,1) = ll;
                        nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk==1)&&(jj==Ny)
                        nonzero_row_index(counter+1,1) = 3*Nx*(Ny-1)+ii;
                        nonzero_col_index(counter+1,1) = 3*Nx*(Ny-1)+ll;
                        nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                        
                        
                    end
                    
                    if (kk==Nz)&&(jj==1)&&(Nz>=2)
                        nonzero_row_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+ii;
                        nonzero_col_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+ll;
                        nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk==Nz)&&(jj==Ny)&&(Nz>=2)
                        nonzero_row_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ii;
                        nonzero_col_index(counter+1,1) = 3*Nx*Ny*(Nz-1)+3*Nx*(Ny-1)+ll;
                        nonzero_value(counter+1,1) = E(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(E(ii,ll)-Cy(ii,ll))>EPS
                    if (jj~=1)&&(jj~=Ny)&&(kk==1)
                        nonzero_row_index(counter+1,1) = 3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = E(ii,ll)-Cy(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (jj~=1)&&(jj~=Ny)&&(kk==Nz)&&(Nz>=2)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = E(ii,ll)-Cy(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(E(ii,ll)-Cz(ii,ll))>EPS
                    if (kk~=1)&&(kk~=Nz)&&(jj==1)&&(Nz>=3)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+ii;
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+ll;
                        nonzero_value(counter+1,1) = E(ii,ll)-Cz(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk~=1)&&(kk~=Nz)&&(jj==Ny)&&(Nz>=3)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = E(ii,ll)-Cz(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(E(ii,ll)-Cy(ii,ll)-Cz(ii,ll))>EPS
                    if (kk~=1)&&(kk~=Nz)&&(jj~=1)&&(jj~=Ny)&&(Nz>=3)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = E(ii,ll)-Cy(ii,ll)-Cz(ii,ll);
                        counter = counter+1;
                    end
                end
                
                if abs(Cz(ii,ll))>EPS
                    if (kk==1)&&(Nz>=2)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*kk*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk==Nz)&&(Nz>=2)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                    end
                    
                    if (kk~=1)&&(kk~=Nz)&&(Nz>=3)
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*kk*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                        
                        nonzero_row_index(counter+1,1) = 3*(kk-1)*Nx*Ny+3*(jj-1)*Nx+ii;
                        nonzero_col_index(counter+1,1) = 3*(kk-2)*Nx*Ny+3*(jj-1)*Nx+ll;
                        nonzero_value(counter+1,1) = Cz(ii,ll);
                        counter = counter+1;
                    end
                end 
            end
        
        end
       
   end
end

A = sparse(nonzero_row_index,nonzero_col_index,nonzero_value,nnl,nnl);

% % %     for k=1:Nz
% % %         for j=1:Ny
% % %         Cy(:,:,j,k) = [sparse(zeros(Nx))-alpha*sparse(diag((2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).^2+(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).^2))*Iy,  -sparse(diag(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)-alpha*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k))))*Iy,  sparse(diag(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)+alpha*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k))))*Iy;
% % %                        sparse(diag(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)+alpha*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k))))*Iy, sparse(zeros(Nx))-alpha*sparse(diag((2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).^2+(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).^2))*Iy,   -sparse(diag(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)-alpha*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k))))*Iy;
% % %                        -sparse(diag(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)-alpha*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k))))*Iy,  sparse(diag(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)+alpha*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k))))*Iy,  sparse(zeros(Nx))-alpha*sparse(diag((2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).^2+(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).^2))*Iy];
% % %         Cz(:,:,j,k) = [sparse(zeros(Nx))-alpha*sparse(diag((2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).^2+(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).^2))*Iz,  -sparse(diag(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)-alpha*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k))))*Iz,  sparse(diag(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)+alpha*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k))))*Iz;
% % %                        sparse(diag(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)+alpha*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k))))*Iz, sparse(zeros(Nx))-alpha*sparse(diag((2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).^2+(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).^2))*Iz,   -sparse(diag(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)-alpha*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k))))*Iz;
% % %                        -sparse(diag(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)-alpha*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k))))*Iz,  sparse(diag(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)+alpha*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k))))*Iz,  sparse(zeros(Nx))-alpha*sparse(diag((2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).^2+(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).^2))*Iz];
% % % 
% % %         E(:,:,j,k) = [3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).^2+(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).^2))*(Ax-Iy-Iz),  -sparse(diag(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)-alpha*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k))))*(Ax-Iy-Iz),  sparse(diag(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)+alpha*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k))))*(Ax-Iy-Iz);
% % %                      sparse(diag(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)+alpha*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k))))*(Ax-Iy-Iz), 3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).^2+(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).^2))*(Ax-Iy-Iz),   -sparse(diag(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)-alpha*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k)).*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k))))*(Ax-Iy-Iz);
% % %                      -sparse(diag(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)-alpha*(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k))))*(Ax-Iy-Iz),  sparse(diag(2*m1(1:Nx,j,k)-m0(1:Nx,j,k)+alpha*(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).*(2*m1(2*Nx+1:3*Nx,j,k)-m0(2*Nx+1:3*Nx,j,k))))*(Ax-Iy-Iz),  3.0/2.0*speye(Nx,Nx)-alpha*sparse(diag((2*m1(1:Nx,j,k)-m0(1:Nx,j,k)).^2+(2*m1(Nx+1:2*Nx,j,k)-m0(Nx+1:2*Nx,j,k)).^2))*(Ax-Iy-Iz)]; 
% % %         end
% % %     end
%     toc;
    % for B 1
    % the initialization
%     tic;
% % %    B1 = zeros(3*Nx*Ny); 
% % %    B2 = B1;
% % %    D = B1;
% % %    C = B1;
% % %    
% % %    B1(1:3*Nx,1:3*Nx) = E(:,:,1,1);% the first row
% % %    B1(1:3*Nx,3*Nx+1:2*3*Nx) = Cy(:,:,1,1);
% % %    for  j=2:Ny-1
% % %    B1((j-1)*3*Nx+1:j*3*Nx,(j-2)*3*Nx+1:(j-1)*3*Nx) = Cy(:,:,j,1);% the second middle row 
% % %    B1((j-1)*3*Nx+1:j*3*Nx,(j-1)*3*Nx+1:j*3*Nx) = E(:,:,j,1)-Cy(:,:,j,1);
% % %    B1((j-1)*3*Nx+1:j*3*Nx,j*3*Nx+1:(j+1)*3*Nx)  = Cy(:,:,j,1);
% % %    end
   
% % %   B1(3*Nx*(Ny-1)+1:3*Nx*Ny,3*Nx*(Ny-1)+1:3*Nx*Ny) = E(:,:,Ny,1); % the final row
% % %   B1(3*Nx*(Ny-1)+1:3*Nx*Ny,3*Nx*(Ny-2)+1:3*Nx*(Ny-1)) = Cy(:,:,Ny,1);
% % % 
% % %    % for B 2
% % %    B2(1:3*Nx,1:3*Nx) = E(:,:,1,Nz);% the first row
% % %    B2(1:3*Nx,3*Nx+1:2*3*Nx) = Cy(:,:,1,Nz);
% % %  for j=2:Ny-1
% % %    B2((j-1)*3*Nx+1:j*3*Nx,(j-2)*3*Nx+1:(j-1)*3*Nx) = Cy(:,:,j,Nz);% the second middle row 
% % %    B2((j-1)*3*Nx+1:j*3*Nx,(j-1)*3*Nx+1:j*3*Nx) = E(:,:,j,Nz)-Cy(:,:,j,Nz);
% % %    B2((j-1)*3*Nx+1:j*3*Nx,j*3*Nx+1:(j+1)*3*Nx)  = Cy(:,:,j,Nz);
% % %  end
   
% % %   B2(3*Nx*(Ny-1)+1:3*Nx*Ny,3*Nx*(Ny-1)+1:3*Nx*Ny) = E(:,:,Ny,Nz); % the final row
% % %   B2(3*Nx*(Ny-1)+1:3*Nx*Ny,3*Nx*(Ny-2)+1:3*Nx*(Ny-1)) = Cy(:,:,Ny,Nz);
% % %  
% % %   A = zeros(3*Nx*Ny*Nz);
 
% % % A(1:3*Nx*Ny,1:3*Nx*Ny) = B1;
% % % A(3*Nx*Ny*(Nz-1)+1:3*Nx*Ny*Nz,3*Nx*Ny*(Nz-1)+1:3*Nx*Ny*Nz) = B2;
% toc;
% tic;
% % %   for k=2:Nz-1
% % %    
% % %   D(1:3*Nx,1:3*Nx) = E(:,:,1,k)-Cz(:,:,1,k);%the first row
% % %   D(1:3*Nx,3*Nx+1:2*3*Nx) = Cy(:,:,1,k);
% % %   
% % %   % the midle circle
% % %   for j=2:Ny-1
% % %   D((j-1)*3*Nx+1:j*3*Nx,(j-2)*3*Nx+1:(j-1)*3*Nx) = Cy(:,:,j,k);% the second row
% % %   D((j-1)*3*Nx+1:j*3*Nx,(j-1)*3*Nx+1:j*3*Nx) = E(:,:,j,k)-Cy(:,:,j,k)-Cz(:,:,j,k);
% % %   D((j-1)*3*Nx+1:j*3*Nx,j*3*Nx+1:(j+1)*3*Nx) = Cy(:,:,j,k);
% % %   end
% % %   
% % %   D(3*Nx*(Ny-1)+1:3*Nx*Ny,3*Nx*(Ny-1)+1:3*Nx*Ny) = E(:,:,Ny,k)-Cz(:,:,Ny,k);% the final row
% % %   D(3*Nx*(Ny-1)+1:3*Nx*Ny,3*Nx*(Ny-2)+1:3*Nx*(Ny-1)) = Cy(:,:,Ny,k);
% % %   
% % %   A((k-1)*3*Nx*Ny+1:k*3*Nx*Ny,(k-1)*3*Nx*Ny+1:k*3*Nx*Ny) = D;
% % %   end
%   toc;
% for C
% the first row
% tic;
% % %   for j=1:Ny   
% % %      C((j-1)*3*Nx+1:j*3*Nx,(j-1)*3*Nx+1:j*3*Nx) = Cz(:,:,j,1);       
% % %   end
% % %   A(1:3*Nx*Ny,3*Nx*Ny+1:2*3*Nx*Ny) = C;
  % the middle row
% % % for k=2:Nz-1 
% % %   for j=1:Ny   
% % %      C((j-1)*3*Nx+1:j*3*Nx,(j-1)*3*Nx+1:j*3*Nx) = Cz(:,:,j,k);       
% % %   end
% % %   A((k-1)*3*Nx*Ny+1:k*3*Nx*Ny,(k-2)*3*Nx*Ny+1:(k-1)*3*Nx*Ny) = C;
% % %   A((k-1)*3*Nx*Ny+1:k*3*Nx*Ny,k*3*Nx*Ny+1:(k+1)*3*Nx*Ny) = C;
% % % end
% the final row
% % %   for j=1:Ny   
% % %      C((j-1)*3*Nx+1:j*3*Nx,(j-1)*3*Nx+1:j*3*Nx) = Cz(:,:,j,Nz);       
% % %   end
% % %   A((Nz-1)*3*Nx*Ny+1:Nz*3*Nx*Ny,(Nz-2)*3*Nx*Ny+1:(Nz-1)*3*Nx*Ny) = C;
% the counter nonzero element for matrix A
% % counter = 0;
% EPS = 0.d0;
% % for ii=1:3*Nx*Ny*Nz
% %     for jj=1:3*Nx*Ny*Nz
% %         if abs(A(ii,jj)) > EPS
% % %           fprintf('%d, %d, %e:\n',ii,jj,A(ii,jj));  
% %           counter = counter + 1;  
% %         end
% %     end
% % end
% % fprintf('The counter of nonzeros element:\n');  
% % counter
% % 
% % counter = zeros(1,3*Nx*Ny*Nz);
% % for ii=1:3*Nx*Ny*Nz
% %     counter1 = 0;
% %     for jj=1:3*Nx*Ny*Nz
% %         if abs(A(ii,jj)) > EPS
% %           fprintf('%d, %d, %3e:\n',ii,jj,A(ii,jj));  
% %           counter1= counter1 + 1;  
% %         end
% %     end
% % counter(1,ii) = counter1;
% % end
% % countermax = max(counter);
% % fprintf('The max cols num : %d \n',countermax);
% % fprintf('The rank of A \n');
% % E=rank(A)
%   toc;
% tic;
  m = A\b1;
%   m = gmres(A,b1,[],tol,maxit);
% m = inv(A)*b1;
  
% toc;
  % Projection onto S^2
%   norm_m = sqrt(sum(m.^2));
%   m = m./norm_m;
  mt = reshape(m,3*Nx,Ny,Nz);
  mt_p = mt;
  
%   for k=1:Nz
%       for j=1:Ny
%         norm_mt =sqrt(mt(1:Nx,j,k).^2+mt(Nx+1:2*Nx,j,k).^2+mt(2*Nx+1:3*Nx,j,k).^2);
%         mt_p(1:Nx,j,k) = mt(1:Nx,j,k)./norm_mt;
%         mt_p(Nx+1:2*Nx,j,k) = mt(Nx+1:2*Nx,j,k)./norm_mt;
%         mt_p(2*Nx+1:3*Nx,j,k) = mt(2*Nx+1:3*Nx,j,k)./norm_mt;
%       end
%   end


% %   m0_prime = m1_prime;
% %   m1_prime = mt; % without projection term
  % m = reshape(mt_p,3*Nx*Ny*Nz,1);
  m0 = mt_p;
%   m1 = mt_p;

% ----- energy ----
for k=1:Nz
    for j=1:Ny
        for i=1:Nx
            
            if i==1
                difference_x(:,:,i,j,k) =[(-mt_p(1,j,k)+mt_p(2,j,k))/(2*dx),...
                                          (-mt_p(Nx+1,j,k)+mt_p(Nx+2,j,k))/(2*dx),...
                                          (-mt_p(2*Nx+1,j,k)+mt_p(2*Nx+2,j,k))/(2*dx)];
                                      
                                      
           
            
            elseif i==Nx
                difference_x(:,:,i,j,k) = [(-mt_p(Nx-1,j,k)+mt_p(Nx,j,k))/(2*dx),...
                                           (-mt_p(Nx+Nx-1,j,k)+mt_p(Nx+Nx,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+Nx-1,j,k)+mt_p(2*Nx+Nx,j,k))/(2*dx)];
                                       
            
            
            else
                difference_x(:,:,i,j,k) = [(-mt_p(i-1,j,k)+0*mt_p(i,j,k)+mt_p(i+1,j,k))/(2*dx),...
                                           (-mt_p(Nx+i-1,j,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i+1,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+i-1,j,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i+1,j,k))/(2*dx)];
                                       
               
            end
         
            
            if j==1
                
                                      
                difference_y(:,:,i,j,k) =[(-mt_p(i,1,k)+mt_p(i,2,k))/(2*dy),...
                                          (-mt_p(Nx+i,1,k)+mt_p(Nx+i,2,k))/(2*dy),...
                                          (-mt_p(2*Nx+i,1,k)+mt_p(2*Nx+i,2,k))/(2*dy)];
                                      
                
                                      
            
            
            elseif j==Ny
                
                                       
                difference_y(:,:,i,j,k) = [(-mt_p(i,Ny-1,k)+mt_p(i,Ny,k))/(2*dy),...
                                           (-mt_p(Nx+i,Ny-1,k)+mt_p(Nx+i,Ny,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,Ny-1,k)+mt_p(2*Nx+i,Ny,k))/(2*dy)];
                                       
                
            
            
                  
                 
            else
                
                difference_y(:,:,i,j,k) = [(-mt_p(i,j-1,k)+0*mt_p(i,j,k)+mt_p(i,j+1,k))/(2*dy),...
                                           (-mt_p(Nx+i,j-1,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j+1,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,j-1,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j+1,k))/(2*dy)];
                                       
                 
            end
            
            if k==1
                
                difference_z(:,:,i,j,k) =[(-mt_p(i,j,1)+mt_p(i,j,2))/(2*dz),...
                                          (-mt_p(Nx+i,j,1)+mt_p(Nx+i,j,2))/(2*dz),...
                                          (-mt_p(2*Nx+i,j,1)+mt_p(2*Nx+i,j,2))/(2*dz)];
                                      
            
            elseif k==Nz
                            
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,Nz-1)+mt_p(i,j,Nz))/(2*dz),...
                                           (-mt_p(Nx+i,j,Nz-1)+mt_p(Nx+i,j,Nz))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,Nz-1)+mt_p(2*Nx+i,j,Nz))/(2*dz)];
            
            
            
            else
                        
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,k-1)+0*mt_p(i,j,k)+mt_p(i,j,k+1))/(2*dz),...
                                           (-mt_p(Nx+i,j,k-1)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j,k+1))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,k-1)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j,k+1))/(2*dz)];
                                       
            end
            
%             difference_x(:,:,i,j,k) = [(mt_p(i+1,j,k)-mt_p(i,j,k))/dx, (mt_p(Nx+i+1,j,k)-mt_p(Nx+i,j,k))/dx, (mt_p(2*(Nx-1)+i+3,j,k)-mt_p(2*(Nx-1)+i+2,j,k))/dx];          
        end
    end
end

% comput 
 En(1,nsteps+1) = sum(sum(sum(sum(difference_x.^2 + difference_y.^2 + difference_z.^2))))*dx*dy*dz;
% -----------------
  % waitbar(nsteps / Nt) %  Basic Wait Bar
fprintf('The iteration times: %d \n',nsteps);
end 
% close(h) % end the wait bar



t = T0 + Nt*dt;
% t = T0 + 2*dt;
mt_exact = zeros(3*Nx,Ny,Nz);
for k=1:Nz
    for j=1:Ny
%     mt_exact(:,j,k) = [cos(X'*Y(j)*Z(k))*sin(t); 
%                        sin(X'*Y(j)*Z(k))*sin(t); 
%                        ones(size(X'))*cos(t)];  
                   
    mt_exact(:,j,k) = [cos(cos(pi*x')*cos(pi*y(j))*cos(pi*z(k)))*sin(t); 
                       sin(cos(pi*x')*cos(pi*y(j))*cos(pi*z(k)))*sin(t); 
                       ones(size(x'))*cos(t)];   
    end
end
mt_exact = reshape(mt_exact,3*Nx*Ny*Nz,1);

% mt_exact
% m = reshape(m1,3*Nx*Ny*Nz,1);

ms = reshape(m0,3*Nx*Ny*Nz,1);
err = max(abs(ms-mt_exact))



% x_exact_prime = zeros(1,3,Nx,Ny,Nz);
% y_exact_prime = zeros(1,3,Nx,Ny,Nz);
% z_exact_prime = zeros(1,3,Nx,Ny,Nz);
       
       
% for k=1:Nz
%     for j=1:Ny
%         for i=1:Nx
%             a = cos(pi*x(i))*cos(pi*y(j))*cos(pi*z(k));
%             ax = -pi*sin(pi*x(i))*cos(pi*y(j))*cos(pi*z(k));
%             ay = -pi*sin(pi*y(j))*cos(pi*x(i))*cos(pi*z(k));
%             az = -pi*sin(pi*z(k))*cos(pi*x(i))*cos(pi*y(j));
%             
% %             a = x(i).^2.*(1-x(i)).^2*y(j)^2*(1-y(j))^2*z(k)^2*(1-z(k))^2;
% %        
% %             ax = (2*x(i).*(1-x(i)).^2-2*x(i).^2.*(1-x(i)))*y(j)^2*(1-y(j))^2*z(k)^2*(1-z(k))^2;
% %             ay = x(i).^2.*(1-x(i)).^2*(2*y(j)*(1-y(j))^2-2*y(j)^2*(1-y(j)))*z(k)^2.*(1-z(k))^2;
% %             az = x(i).^2.*(1-x(i)).^2*y(j)^2*(1-y(j))^2*(2*z(k)*(1-z(k))^2-2*z(k)^2*(1-z(k)));
%             
%             x_exact_prime(:,:,i,j,k) = [-sin(a)*ax*sin(t), cos(a)*ax*sin(t),0];
%             
%             y_exact_prime(:,:,i,j,k) = [-sin(a)*ay*sin(t), cos(a)*ay*sin(t),0];
%             
%             z_exact_prime(:,:,i,j,k) = [-sin(a)*az*sin(t), cos(a)*az*sin(t),0];
%             
% %     x_exact_prime(:,:,i,j,k) = [-YY(j)*ZZ(k)*X_prime(i)*sin(X(i)*YY(j)*ZZ(k))*sin(t),YY(j)*ZZ(k)*X_prime(i)*cos(X(i)*YY(j)*ZZ(k))*sin(t),0];
%         end
%     end
% end



% difference_x = zeros(size(x_exact_prime));
% difference_y = zeros(size(y_exact_prime));
% difference_z = zeros(size(z_exact_prime));


for k=1:Nz
    for j=1:Ny
        for i=1:Nx
            
            if i==1
                difference_x(:,:,i,j,k) =[(-mt_p(1,j,k)+mt_p(2,j,k))/(2*dx),...
                                          (-mt_p(Nx+1,j,k)+mt_p(Nx+2,j,k))/(2*dx),...
                                          (-mt_p(2*Nx+1,j,k)+mt_p(2*Nx+2,j,k))/(2*dx)];
                                      
                                      
           
            
            elseif i==Nx
                difference_x(:,:,i,j,k) = [(-mt_p(Nx-1,j,k)+mt_p(Nx,j,k))/(2*dx),...
                                           (-mt_p(Nx+Nx-1,j,k)+mt_p(Nx+Nx,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+Nx-1,j,k)+mt_p(2*Nx+Nx,j,k))/(2*dx)];
                                       
            
            
            else
                difference_x(:,:,i,j,k) = [(-mt_p(i-1,j,k)+0*mt_p(i,j,k)+mt_p(i+1,j,k))/(2*dx),...
                                           (-mt_p(Nx+i-1,j,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i+1,j,k))/(2*dx),...
                                           (-mt_p(2*Nx+i-1,j,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i+1,j,k))/(2*dx)];
                                       
               
            end
         
            
            if j==1
                
                                      
                difference_y(:,:,i,j,k) =[(-mt_p(i,1,k)+mt_p(i,2,k))/(2*dy),...
                                          (-mt_p(Nx+i,1,k)+mt_p(Nx+i,2,k))/(2*dy),...
                                          (-mt_p(2*Nx+i,1,k)+mt_p(2*Nx+i,2,k))/(2*dy)];
                                      
                
                                      
            
            
            elseif j==Ny
                
                                       
                difference_y(:,:,i,j,k) = [(-mt_p(i,Ny-1,k)+mt_p(i,Ny,k))/(2*dy),...
                                           (-mt_p(Nx+i,Ny-1,k)+mt_p(Nx+i,Ny,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,Ny-1,k)+mt_p(2*Nx+i,Ny,k))/(2*dy)];
                                       
                
            
            
                  
                 
            else
                
                difference_y(:,:,i,j,k) = [(-mt_p(i,j-1,k)+0*mt_p(i,j,k)+mt_p(i,j+1,k))/(2*dy),...
                                           (-mt_p(Nx+i,j-1,k)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j+1,k))/(2*dy),...
                                           (-mt_p(2*Nx+i,j-1,k)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j+1,k))/(2*dy)];
                                       
                 
            end
            
            if k==1
                
                difference_z(:,:,i,j,k) =[(-mt_p(i,j,1)+mt_p(i,j,2))/(2*dz),...
                                          (-mt_p(Nx+i,j,1)+mt_p(Nx+i,j,2))/(2*dz),...
                                          (-mt_p(2*Nx+i,j,1)+mt_p(2*Nx+i,j,2))/(2*dz)];
                                      
            
            elseif k==Nz
                            
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,Nz-1)+mt_p(i,j,Nz))/(2*dz),...
                                           (-mt_p(Nx+i,j,Nz-1)+mt_p(Nx+i,j,Nz))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,Nz-1)+mt_p(2*Nx+i,j,Nz))/(2*dz)];
            
            
            
            else
                        
                difference_z(:,:,i,j,k) = [(-mt_p(i,j,k-1)+0*mt_p(i,j,k)+mt_p(i,j,k+1))/(2*dz),...
                                           (-mt_p(Nx+i,j,k-1)+0*mt_p(Nx+i,j,k)+mt_p(Nx+i,j,k+1))/(2*dz),...
                                           (-mt_p(2*Nx+i,j,k-1)+0*mt_p(2*Nx+i,j,k)+mt_p(2*Nx+i,j,k+1))/(2*dz)];
                                       
            end
            
%             difference_x(:,:,i,j,k) = [(mt_p(i+1,j,k)-mt_p(i,j,k))/dx, (mt_p(Nx+i+1,j,k)-mt_p(Nx+i,j,k))/dx, (mt_p(2*(Nx-1)+i+3,j,k)-mt_p(2*(Nx-1)+i+2,j,k))/dx];          
        end
    end
end

% for k=1:Nz
%     for j=1:Ny-1
%         for i=1:Nx
%             difference_y(:,:,i,j,k) = [(mt_p(i,j+1,k)-mt_p(i,j,k))/dy, (mt_p(Nx+i,j+1,k)-mt_p(Nx+i,j,k))/dy, (mt_p(2*(Nx-1)+i+2,j+1,k)-mt_p(2*(Nx-1)+i+2,j,k))/dy];
%         end
%     end
% end
% 
% for k=1:Nz-1
%     for j=1:Ny
%         for i=1:Nx
%             difference_z(:,:,i,j,k) = [(mt_p(i,j,k+1)-mt_p(i,j,k))/dz, (mt_p(Nx+i,j,k+1)-mt_p(Nx+i,j,k))/dz, (mt_p(2*(Nx-1)+i+2,j,k+1)-mt_p(2*(Nx-1)+i+2,j,k))/dz];           
%         end
%     end
% end

% for k=1:Nz-1
%     for j=1:Ny-1
%         for i=1:Nx-1
%             difference(:,:,i,j,k) = [(mt(i+1,j,k)-mt(i,j,k))/dx, (mt(Nx+i+1,j,k)-mt(Nx+i,j,k))/dx, (mt(2*(Nx-1)+i+3,j,k)-mt(2*(Nx-1)+i+2,j,k))/dx;
%                                      (mt(i,j+1,k)-mt(i,j,k))/dy, (mt(Nx+i,j+1,k)-mt(Nx+i,j,k))/dy, (mt(2*(Nx-1)+i+2,j+1,k)-mt(2*(Nx-1)+i+2,j,k))/dy;
%                                      (mt(i,j,k+1)-mt(i,j,k))/dz, (mt(Nx+i,j,k+1)-mt(Nx+i,j,k))/dz, (mt(2*(Nx-1)+i+2,j,k+1)-mt(2*(Nx-1)+i+2,j,k))/dz];           
% %             difference(i,j,k) = (mt(i+1,j,k)-mt(i,j,k))./dx+(mt(i,j+1,k)-mt(i,j,k))./dy+(mt(i,j,k+1)-mt(i,j,k))./dz;
% %             difference(Nx-1+i,j,k) = (mt(Nx+i+1,j,k)-mt(Nx+i,j,k))./dx+(mt(Nx+i,j+1,k)-mt(Nx+i,j,k))./dy+(mt(Nx+i,j,k+1)-mt(Nx+i,j,k))./dz;
% %             difference(2*(Nx-1)+i,j,k) = (mt(2*(Nx-1)+i+3,j,k)-mt(2*(Nx-1)+i+2,j,k))./dx+(mt(2*(Nx-1)+i+2,j+1,k)-mt(2*(Nx-1)+i+2,j,k))./dy+(mt(2*(Nx-1)+i+2,j,k+1)-mt(2*(Nx-1)+i+2,j,k))./dz;
%         end
%     end
% end

% tt = linspace(0,T,Nt);

tt = linspace(0,T,Nt+1);

% % % err = max(abs(m-mt_exact)) % the infty norm
% err2 = sqrt(1.0/3.0*dx*dy*dz*sum((ms-mt_exact).^2)) % the 2-norm
% % % err_grad_2_difference = sqrt(1.0/3.0*dx*dy*dz*sum(sum(sum(sum(sum((difference-mt_exact_prime).^2))))))  %% the \nabla error \ell^2-norm  
% % % err_grad_2_difference = sqrt(1.0/(9.0*(Nx-1)*(Ny-1)*(Nz-1))*sum(sum(sum(sum(sum((difference-mt_exact_prime).^2))))))  %% the \nabla error \ell^2-norm  
% err_grad_2_difference = sqrt(1.0/(3.0*(Nx-1)*Ny*Nz)*(sum(sum(sum(sum((x_exact_prime-difference_x).^2))))+sum(sum(sum(sum((y_exact_prime-difference_y).^2))))+sum(sum(sum(sum((z_exact_prime-difference_z).^2))))));
% err_grad_2_H_1 = err2 + err_grad_2_difference % the H^1 norm

toc; 
