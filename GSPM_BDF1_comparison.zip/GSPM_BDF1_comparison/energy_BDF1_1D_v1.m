% A test problem for 1st-order Semi-Implicit method
% solve the Laudau-Lifshitz eqn 
% 
% BDF1 with damping
% E no tilde
% 1D

% ----- remark -----

% ---------------------------

% clear all;
format long;
% format compact;

% initialize the problem
T = 1.0d-1;
xleft = 0.0;
xright = 1.d0;
% xright = 0.32;
T0 = 0.0;
Nt = 100;
% Nt = ceil((2)^8);
dt = (T-T0)/Nt;

% dx = 5d-4;
% dx = 1d-4;
% dx = 5d-5;
% dx = 1/10^3;
% dx = 1/10^3;
% dx = 1/16;
% Nx = 8;
Nx = 2000;
dx = (xright-xleft)/Nx;

x = xleft+dx/2:dx:xright-dx/2;
% X = x.^2.*(ones(1,Nx)-x).^2;        % change variable 
% X_prime = 4*x.^3-6*x.^2+2*x;         % the derivative of X
% X_prime_2 = 12*x.^2-12*x+2*ones(1,Nx); % the derivative of X_prime


% damping parameter
% alpha = 0.d0;
% alpha = 0.01;
alpha = 0.2;

linestyles = {'-', '--', ':', '-.','-'}; 
figure;


tic;

% initial condition
% initial condition
t = T0;
% m0 = [cos(cos(pi*x))*sin(t); sin(cos(pi*x))*sin(t); ones(size(x))*cos(t)];
m0 = [cos(cos(pi*x))*sin(0.01); sin(cos(pi*x))*sin(0.01); ones(size(x))*cos(0.01)];
% t = T0+dt;
% m1 = [cos(cos(pi*x))*sin(t); sin(cos(pi*x))*sin(t); ones(size(x))*cos(t)];
% t = T0+2.*dt;
% m2 = [cos(cos(pi*x))*sin(t); sin(cos(pi*x))*sin(t); ones(size(x))*cos(t)];


m = zeros(size(m0));
f = zeros(size(m0));
mt0 = zeros(size(m0));
mt1 = zeros(size(m0));
mt = zeros(size(m0));

mhat = zeros(size(m0));
mtnorm = zeros(size(m0));


% Create the sparse matrix for inversion
% e = ones(Nx,1);
% A = spdiags([e -2*e e],-1:1,Nx,Nx);
% A(1,1) = -1; 
% A(Nx,Nx) = -1;
% A = 2.0/3.0*dt*A/dx^2;
B = speye(3*Nx,3*Nx);

% Create the sparse matrix for inversion
% e = ones(Nx,1);
% A = spdiags([-e 16*e -30*e 16*e -e],-2:2,Nx,Nx); % matrix A means -\Delta
% A(2,1) = 15;
% A(1,1) = -14;
% A(1,2) = 15;
% 
% A(Nx-1,Nx) = 15;
% A(Nx,Nx-1) = 15;
% A(Nx,Nx) = -14;
% % full(A)
% 
% % A = A/(12*dx^2); % Delta
% A = dt*A/(12*dx^2);

% for the discrete gradient
% M = spdiags([e -8*e 0*e 8*e -e],-2:2,Nx,Nx); % matrix A means -\Delta
% M(2,1) = -7;
% M(1,1) = -8;
% M(1,2) = 9;
% 
% M(Nx-1,Nx) = 7;
% M(Nx,Nx-1) = -9;
% M(Nx,Nx) = 8;

% full(M)
% M = M/(12*dx); % nabla

e = ones(Nx,1);
A = spdiags([e -2*e e],-1:1,Nx,Nx);
A(1,1) = -1; 
A(Nx,Nx) = -1;
A = dt*A/dx^2; % Delta

M = spdiags([-e 0*e e],-1:1,Nx,Nx); % matrix M means -\nabla
M(1,1) = -1;
M(Nx,Nx) = 1;
M = M/(2*dx); % nabla

E = zeros(1,Nt);

tic;

% 1st-order Semi-Implicit method
for j=1:Nt
% j=2;
    t =  T0 + (j-1)*dt;
    % the very important term f may be changed by the system 
%     f = [cos(t)*cos(X)-cos(t)*sin(t)*(X_prime_2.*cos(X)-X_prime.^2.*sin(X))+alpha*(X_prime_2.*sin(X)*sin(t)+X_prime.^2.*cos(X)*sin(t)*(cos(t))^2);
%          sin(X)*cos(t)+sin(t)*cos(t)*(-X_prime_2.*sin(X)-X_prime.^2.*cos(X))+alpha*(-X_prime_2.*cos(X)*sin(t)+X_prime.^2.*sin(X)*sin(t)*(cos(t))^2);
%          -sin(t)*ones(1,Nx)+X_prime_2*(sin(t))^2-alpha*(X_prime.^2*cos(t)*(sin(t))^2)];
     
%     a = -(cos(cos(pi*x)).*(-pi*sin(pi*x)).^2+sin(cos(pi*x)).*(-pi^2*cos(pi*x)))*sin(t);
%     b = (-sin(cos(pi*x)).*(-pi*sin(pi*x)).^2+cos(cos(pi*x)).*(-pi^2*cos(pi*x)))*sin(t);
%  
%     f = [cos(cos(pi*x))*cos(t)-cos(t)*b-alpha*a-alpha*pi^2*sin(pi*x).*sin(pi*x)*sin(t)*sin(t).*cos(cos(pi*x))*sin(t);
%         sin(cos(pi*x))*cos(t)+cos(t)*a-alpha*b-alpha*pi^2*sin(pi*x).*sin(pi*x)*sin(t)*sin(t).*sin(cos(pi*x))*sin(t);
%         -ones(size(x))*sin(t)+cos(cos(pi*x))*sin(t).*b-sin(cos(pi*x))*sin(t).*a-alpha*pi^2*sin(pi*x).*sin(pi*x)*sin(t)*sin(t)*cos(t)
%         ];
    
    
% m_t= -m\cross m_xx- alpha * m * (m* m_xx)
% f= m_t + m\cross m_xx + alpha * m * (m* m_xx)

% m = [cos(a)*sin(t); sin(a)*sin(t); ones(size(x))*cos(t)]

% m_t = [cos(a)*cos(t); sin(a)*cos(t); -ones(size(x))*sin(t)] 
% a = cos(pi*x);
% ax = -pi*sin(pi*x);
% axx = -pi^2*a;
% m_x = [-sin(a)*ax*sin(t); 
%        cos(a)*ax*sin(t); 
%        zeros(size(x))]

% m_xx = [(-cos(a)*ax*ax-sin(a)*axx)*sin(t); 
%        (-sin(a)*ax*ax+cos(a)*axx)*sin(t); 
%        zeros(size(x))]

% m cross m_xx = [-cos(t)*(-sin(a)*ax*ax+cos(a)*axx)*sin(t);
%                 cos(t)*(-cos(a)*ax*ax-sin(a)*axx)*sin(t);
%                 axx*sin(t)*sin(t)]


% m corss (m cross m_xx) =
% [sin(a)*axx*sin(t)+cos(a)*ax*ax*cos(t)*cos(t)*sin(t);
%  -cos(a)*axx*sin(t)+sin(a)*ax*ax*cos(t)*cos(t)*sin(t);
%  -ax*ax*sin(t)*sin(t)*cos(t)];

% correct f
% f = [cos(a)*cos(t)-cos(t)*(-sin(a)*ax*ax+cos(a)*axx)*sin(t)+alpha*(sin(a)*axx*sin(t)+cos(a)*ax*ax*cos(t)*cos(t)*sin(t));
%      sin(a)*cos(t)+cos(t)*(-cos(a)*ax*ax-sin(a)*axx)*sin(t)+alpha*(-cos(a)*axx*sin(t)+sin(a)*ax*ax*cos(t)*cos(t)*sin(t));
%      -ones(size(x))*sin(t)+axx*sin(t)*sin(t)+alpha*(-ax*ax*sin(t)*sin(t)*cos(t))];


    a = cos(pi*x);
    ax = -pi*sin(pi*x);
    axx = -pi^2*a;
    
    f = [cos(a)*cos(t)+(sin(a).*ax.*ax-cos(a).*axx)*sin(t)*cos(t)+alpha*(cos(a).*ax.*ax*sin(t)*cos(t)*cos(t)+axx.*sin(a)*sin(t) );
        sin(a)*cos(t)-(cos(a).*ax.*ax+sin(a).*axx)*sin(t)*cos(t)+alpha*(sin(a).*ax.*ax*sin(t)*cos(t)*cos(t)-axx.*cos(a)*sin(t));
        -ones(size(x))*sin(t)+axx*sin(t)*sin(t)+alpha*(-ax.*ax*sin(t)*sin(t)*cos(t))
    ];

    f = zeros(size(f));
    
%     mhat = 3*m2-3*m1+m0;
%     mhat = 2*m1-m0;
    mhat = m0;
    
%     mt1 = (3*m2-3*m1+m0)*M';
    
%     r_norm = (mt1(1,:)).*mt1(1,:) + (mt1(2,:)).*mt1(2,:) + (mt1(3,:)).*mt1(3,:);
       
%     B = [speye(Nx,Nx)-alpha*sparse(diag((2*m1(3,:)-m0(3,:)).^2+(2*m1(2,:)-m0(2,:)).^2))*A,sparse(diag(-(2*m1(3,:)-m0(3,:))+alpha*(2*m1(2,:)-m0(2,:)).*(2*m1(1,:)-m0(1,:))))*A,sparse(diag((2*m1(2,:)-m0(2,:))+alpha*(2*m1(3,:)-m0(3,:)).*(2*m1(1,:)-m0(1,:))))*A; ...
%          sparse(diag((2*m1(3,:)-m0(3,:))+alpha*(2*m1(1,:)-m0(1,:)).*(2*m1(2,:)-m0(2,:))))*A,speye(Nx,Nx)-alpha*sparse(diag((2*m1(3,:)-m0(3,:)).^2+(2*m1(1,:)-m0(1,:)).^2))*A,sparse(diag(-(2*m1(1,:)-m0(1,:))+alpha*(2*m1(3,:)-m0(3,:)).*(2*m1(2,:)-m0(2,:))))*A; ...
%          sparse(diag(-(2*m1(2,:)-m0(2,:))+alpha*(2*m1(1,:)-m0(1,:)).*(2*m1(3,:)-m0(3,:))))*A,sparse(diag((2*m1(1,:)-m0(1,:))+alpha*(2*m1(2,:)-m0(2,:)).*(2*m1(3,:)-m0(3,:))))*A,speye(Nx,Nx)-alpha*sparse(diag((2*m1(1,:)-m0(1,:)).^2+(2*m1(2,:)-m0(2,:)).^2))*A];

%     B = [11/6*speye(Nx,Nx)-alpha*sparse(diag((mhat(3,:)).^2+(mhat(2,:)).^2))*A,...
%          sparse(diag(-(mhat(3,:))+alpha*(mhat(2,:)).*(mhat(1,:))))*A,...
%          sparse(diag((mhat(2,:))+alpha*(mhat(3,:)).*(mhat(1,:))))*A; ...
%          sparse(diag((mhat(3,:))+alpha*(mhat(1,:)).*(mhat(2,:))))*A,...
%          11/6*speye(Nx,Nx)-alpha*sparse(diag((mhat(3,:)).^2+(mhat(1,:)).^2))*A,...
%          sparse(diag(-(mhat(1,:))+alpha*(mhat(3,:)).*(mhat(2,:))))*A; ...
%          sparse(diag(-(mhat(2,:))+alpha*(mhat(1,:)).*(mhat(3,:))))*A,...
%          sparse(diag((mhat(1,:))+alpha*(mhat(2,:)).*(mhat(3,:))))*A,...
%          11/6*speye(Nx,Nx)-alpha*sparse(diag((mhat(1,:)).^2+(mhat(2,:)).^2))*A];
     
     B = [speye(Nx,Nx)-alpha*sparse(diag((mhat(3,:)).^2+(mhat(2,:)).^2))*A,...
         sparse(diag(-(mhat(3,:))+alpha*(mhat(2,:)).*(mhat(1,:))))*A,...
         sparse(diag((mhat(2,:))+alpha*(mhat(3,:)).*(mhat(1,:))))*A; ...
         sparse(diag((mhat(3,:))+alpha*(mhat(1,:)).*(mhat(2,:))))*A,...
         speye(Nx,Nx)-alpha*sparse(diag((mhat(3,:)).^2+(mhat(1,:)).^2))*A,...
         sparse(diag(-(mhat(1,:))+alpha*(mhat(3,:)).*(mhat(2,:))))*A; ...
         sparse(diag(-(mhat(2,:))+alpha*(mhat(1,:)).*(mhat(3,:))))*A,...
         sparse(diag((mhat(1,:))+alpha*(mhat(2,:)).*(mhat(3,:))))*A,...
         speye(Nx,Nx)-alpha*sparse(diag((mhat(1,:)).^2+(mhat(2,:)).^2))*A];


%     B = [11/6*speye(Nx,Nx)-dt*alpha*A, dt*sparse(diag(-mhat(3,:)))*A, dt*sparse(diag(mhat(2,:)))*A;...
%          dt*sparse(diag(mhat(3,:)))*A, 11/6*speye(Nx,Nx)-dt*alpha*A, dt*sparse(-diag(mhat(1,:)))*A;...
%          dt*sparse(-diag(mhat(2,:)))*A, dt*sparse(diag(mhat(1,:)))*A, 11/6*speye(Nx,Nx)-dt*alpha*A];

%     mt0 = 3*m2 - 3/2*m1 + 1/3*m0;
%     mt0 = 2*m1 - 1/2*m0;
    mt0 = m0;
    
%     mtnorm(1,:) = alpha*dt*( r_norm.*mhat(1,:));
%     mtnorm(2,:) = alpha*dt*( r_norm.*mhat(2,:));
%     mtnorm(3,:) = alpha*dt*( r_norm.*mhat(3,:));
    
%     mt =  [mt0(1,:) + dt*f(1,:) + mtnorm(1,:) ...
%            mt0(2,:) + dt*f(2,:) + mtnorm(2,:) ...
%            mt0(3,:) + dt*f(3,:) + mtnorm(3,:)];       % the right term
       
    mt =  [mt0(1,:) + dt*f(1,:) ...
           mt0(2,:) + dt*f(2,:) ...
           mt0(3,:) + dt*f(3,:)];       % the right term
       
    mt=mt';
    mt = B\mt;
    m(1,:) = mt(1:Nx);
    m(2,:) = mt(Nx+1:2*Nx);
    m(3,:) = mt(2*Nx+1:3*Nx);
%     m0_prime = m1_prime;
%     m1_prime = m; 

    % Projection onto S^2
%     norm_m = sqrt(m(1,:).^2+m(2,:).^2+m(3,:).^2);
%     m(1,:) = m(1,:)./norm_m;
%     m(2,:) = m(2,:)./norm_m;
%     m(3,:) = m(3,:)./norm_m;
    
    m0 = m;
%     m1 = m2;
%     m1 = m;

    difference=m*M';
    E(1,j) = sum(sum(abs(difference.^2)))*dx;
    
   
    fprintf('The iteration times: %d \n',j);
end
toc;

% Compare with the exact solution
t = T;
       
m_exact = [cos(cos(pi*x))*sin(t); sin(cos(pi*x))*sin(t); ones(size(x))*cos(t)];

m_exact_prime = [sin(cos(pi*x))*pi.*sin(pi*x)*sin(t); 
                 -pi*cos(cos(pi*x)).*sin(pi*x)*sin(t); 
                 zeros(size(x))];
             
tt = linspace(0,T,Nt);

plot(tt,E(1,:), 'LineWidth', 3)

% xlabel('x','FontSize',20);
xlabel('Time $t$','FontSize',20,'Interpreter','latex');
ylabel('Energy','FontSize',20);
set(gca, 'FontSize', 15);  

% difference = zeros(size(m_exact_prime));
% 
% % for the first two cols
% difference(:,1) = (-8*m(:,1)+9*m(:,2)-m(:,3))./(12*dx);
% difference(:,2) = (-7*m(:,1)+0*m(:,2)+8*m(:,3)-m(:,4))./(12*dx);
% 
% for i=1:length(x)-4
%    difference(:,i+2) = (m(:,i)-8*m(:,i+1)+0*m(:,i+2)+8*m(:,i+3)-m(:,i+4))./(12*dx);
% end
% 
% % for the last two cols
% difference(:,length(x)) = (m(:,length(x)-2)-9*m(:,length(x)-1)+8*m(:,length(x)))./(12*dx);
% difference(:,length(x)-1) = (1*m(:,length(x)-3)-8*m(:,length(x)-2)+0*m(:,length(x)-1)+7*m(:,length(x)))./(12*dx);
% 
% err_infty = max(max(abs(m-m_exact))) % infinity-norm
% err2 = sqrt(dx*sum(sum((m-m_exact).^2))) % 2-norm
% err_grad_2_difference = sqrt(dx*sum(sum((difference-m_exact_prime).^2)));%% the \nabla error \ell^2-norm
% err_grad_2_H_1 = err2 + err_grad_2_difference % the H^1 norm

% err_inf = max(max(abs(m-m_exact))

difference=m*M';

err_infty = max(max(abs(m-m_exact))) % infinity-norm
err2 = sqrt(dx*sum(sum((m-m_exact).^2))) % 2-norm
err_grad_2_difference = sqrt(dx*sum(sum((difference-m_exact_prime).^2)));%% the \nabla error \ell^2-norm
err_grad_2_H_1 = err2 + err_grad_2_difference % the H^1 norm

% the norm 
norm = max(abs(sum(m.^2)-ones(1,Nx))) % preseving or not

% sqrt(dx*sum(sum((cc'-m_exact_prime(3,:)).^2)))

ee  = sum(m.^2) - ones(1,Nx);
err_L2 = sqrt( dx * sum( abs(ee).^2 ) )

mag_m = sqrt( sum(m.^2,1) );   % 1×Nx 行向量

min_abs_m = min( mag_m )   % min_j |m_j^n|
max_abs_m = max( mag_m )   % max_j |m_j^n|

% % clearvars -except E1 E2 E3 E4 E5 tt
% 
% linestyles = {'-', '--', ':', '-.','-'}; 
% % linestyles = {'-', '--', ':', '-.', '.'}; 
% plot(tt,E1(1,:),'LineStyle', linestyles{1}, 'LineWidth', 3)
% hold on
% plot(tt,E2(1,:),'LineStyle', linestyles{2},'LineWidth', 3)
% hold on
% plot(tt,E3(1,:),'LineStyle', linestyles{3},'LineWidth', 3)
% hold on
% plot(tt,E4(1,:),'LineStyle', linestyles{4},'LineWidth', 3)
% hold on
% plot(tt,E5(1,:),'LineStyle', linestyles{5},'LineWidth', 3)
% xlabel('Time $t$','FontSize',20,'Interpreter','latex');
% ylabel('Energy','FontSize',20);
% set(gca, 'FontSize', 15);  
% legend('$\alpha=0.$','$\alpha=0.01$','$\alpha=0.05$','$\alpha=0.1$','$\alpha=0.2$','Location', 'best','Interpreter','latex')


% proj and noproj
linestyles = {'-', '--'}; 
% linestyles = {'-', '--', ':', '-.', '.'}; 
plot(tt,E1(1,:),'LineStyle', linestyles{1}, 'LineWidth', 3)
hold on
plot(tt,E2(1,:),'LineStyle', linestyles{2},'LineWidth', 3)
hold on
xlabel('Time $t$','FontSize',20,'Interpreter','latex');
ylabel('Energy','FontSize',20);
set(gca, 'FontSize', 15);  
legend('BDF1 projection','BDF1 no projection', 'best','Interpreter','latex')


toc;