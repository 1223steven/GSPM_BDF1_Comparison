      subroutine bc( u, nx, ny, nz )
!      implicit double precision(a-h, o-z)
!      implicit integer(i-n)
      implicit none

      integer :: nx, ny, nz, i, j, k

      double precision u(0:nx+1, 0:ny+1, 0:nz+1, 3)
!      double precision s(0:nx+1, 0:ny+1, 0:nz+1, 3)
!c
!c----- boundary vondition for u
!c
      k=0
      do j=1,ny
         do i=1,nx
            u(i,j,k,1) = u(i,j,k+1,1)
            u(i,j,k,2) = u(i,j,k+1,2)
            u(i,j,k,3) = u(i,j,k+1,3)
         enddo
      enddo

      k=nz
      do j=1,ny
         do i=1,nx
            u(i,j,k+1,1) = u(i,j,k,1)
            u(i,j,k+1,2) = u(i,j,k,2)
            u(i,j,k+1,3) = u(i,j,k,3)
         enddo
      enddo

      j=0
      do k=1,nz
         do i=1,nx
            u(i,j,k,1) = u(i,j+1,k,1)
            u(i,j,k,2) = u(i,j+1,k,2)
            u(i,j,k,3) = u(i,j+1,k,3)
         enddo
      enddo

      j=ny
      do k=1,nz
         do i=1,nx
            u(i,j+1,k,1) = u(i,j,k,1)
            u(i,j+1,k,2) = u(i,j,k,2)
            u(i,j+1,k,3) = u(i,j,k,3)
         enddo
      enddo

      i=0
      do k=1,nz
         do j=1,ny
            u(i,j,k,1) = u(i+1,j,k,1)
            u(i,j,k,2) = u(i+1,j,k,2)
            u(i,j,k,3) = u(i+1,j,k,3)
         enddo
      enddo

      i=nx
      do k=1,nz
         do j=1,ny
            u(i+1,j,k,1) = u(i,j,k,1)
            u(i+1,j,k,2) = u(i,j,k,2)
            u(i+1,j,k,3) = u(i,j,k,3)
         enddo
      enddo
!c
!c----- boundary vondition for s
!c
!      k=0
!      do j=1,ny
!         do i=1,nx
!            s(i,j,k,1) = s(i,j,k+1,1)
!            s(i,j,k,2) = s(i,j,k+1,2)
!            s(i,j,k,3) = s(i,j,k+1,3)
!         enddo
!      enddo
!
!      k=nz
!      do j=1,ny
!         do i=1,nx
!            s(i,j,k+1,1) = s(i,j,k,1)
!            s(i,j,k+1,2) = s(i,j,k,2)
!            s(i,j,k+1,3) = s(i,j,k,3)
!         enddo
!      enddo

!      j=0
!      do k=1,nz
!         do i=1,nx
!            s(i,j,k,1) = s(i,j+1,k,1)
!            s(i,j,k,2) = s(i,j+1,k,2)
!            s(i,j,k,3) = s(i,j+1,k,3)
!         enddo
!      enddo

!      j=ny
!      do k=1,nz
!         do i=1,nx
!            s(i,j+1,k,1) = s(i,j,k,1)
!            s(i,j+1,k,2) = s(i,j,k,2)
!            s(i,j+1,k,3) = s(i,j,k,3)
!         enddo
!      enddo

!      i=0
!      do k=1,nz
!         do j=1,ny
!            s(i,j,k,1) = s(i+1,j,k,1)
!            s(i,j,k,2) = s(i+1,j,k,2)
!            s(i,j,k,3) = s(i+1,j,k,3)
!         enddo
!      enddo

!      i=nx
!      do k=1,nz
!         do j=1,ny
!            s(i+1,j,k,1) = s(i,j,k,1)
!            s(i+1,j,k,2) = s(i,j,k,2)
!            s(i+1,j,k,3) = s(i,j,k,3)
!         enddo
!      enddo

      return
      end
