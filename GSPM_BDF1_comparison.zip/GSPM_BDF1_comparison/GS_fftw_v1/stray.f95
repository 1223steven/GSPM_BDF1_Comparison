      subroutine stray( u, uhat, khat, work, emfu, planf, &
          planb, nx, ny, nz, mx, my, mz )
!      implicit double precision( a-h, o-z )
!      implicit integer( i-n )
      implicit none

      integer :: nx, ny, nz, mx, my, mz, i, j, k, l

!      double precision ::

      double precision u( 0:nx+1, 0:ny+1, 0:nz+1, 3 )
      double precision emfu( nx, ny, nz, 3 )

      double complex khat( mx/2+1, my, mz, 6 )

      double precision uhat( 0:mx-1, 0:my-1, 0:mz-1, 3 )
      double complex work( mx/2+1, my, mz, 3 )

      double complex k1, k2, k3, k4, k5, k6, w1, w2, w3
!c
!c----- Variables for the FFT
!c
      integer*8 planf(3), planb(3)

      do l=1,3
         do k=0,mz-1
            do j=0,my-1
               do i=0,mx-1
                  uhat(i,j,k,l) = 0.d0
               enddo
            enddo
         enddo
      enddo

      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  uhat(i-1,j-1,k-1,l) = u(i,j,k,l)
               enddo
            enddo
         enddo
      enddo

      do l=1,3
         call dfftw_execute( planf(l) )
      enddo

      do k=1,mz
         do j=1,my
            do i=1,mx/2+1
               w1 = work(i,j,k,1)
               w2 = work(i,j,k,2)
               w3 = work(i,j,k,3)

               k1 = khat(i,j,k,1)
               k2 = khat(i,j,k,2)
               k3 = khat(i,j,k,3)
               k4 = khat(i,j,k,4)
               k5 = khat(i,j,k,5)
               k6 = khat(i,j,k,6)

               work(i,j,k,1) = w1 * k1 + w2 * k2 + w3 * k3
               work(i,j,k,2) = w1 * k2 + w2 * k4 + w3 * k5
               work(i,j,k,3) = w1 * k3 + w2 * k5 + w3 * k6
            enddo
         enddo
      enddo

      do l=1,3
         call dfftw_execute( planb(l) )
      enddo

      do l=1,3
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  emfu(i,j,k,l) = uhat(i-1,j-1,k-1,l)
               enddo
            enddo
         enddo
      enddo

      return
      end
