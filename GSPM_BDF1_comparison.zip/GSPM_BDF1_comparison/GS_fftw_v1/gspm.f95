      subroutine gspm( u0, u, hu, gu, emfu, diagu_gm, fmulu_gm, &
             upperdu_gm, diagu_pj, fmulu_pj, upperdu_pj, planf_be_u, &
             planb_be_u, khat, convf, convb, uhat, work, nx, ny,  &
             nz, mx, my, mz, dx, dy, dz, q, dmpng, chi, xtrnlu, dt )
!      implicit double precision( a-h, o-z )
!      implicit integer( i-n )
      implicit none

      integer :: nx, ny, nz, mx, my, mz, i, j, k

      double precision :: dmpng, chi, dx, dy, dz, q, dt, tmp
!c
!c----- variables for the magnetization in the first layer
!c
      double precision u0(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision u(0:nx+1, 0:ny+1, 0:nz+1, 3)
      double precision hu(nx, ny, nz, 3), gu(nx, ny, nz, 3)
      double precision emfu(nx, ny, nz, 3), xtrnlu(nx,ny,nz,3)
!c
!c----- variables for the gspm, backward euler step (tridiagonal system)
!c
      double precision diagu_gm(nx, ny, nz), upperdu_gm(nx, ny, nz), &
          fmulu_gm(nx, ny, nz)
      double precision diagu_pj(nx, ny, nz), upperdu_pj(nx, ny, nz), &
          fmulu_pj(nx, ny, nz)
!c
!c----- variables for the Fourier transform of u in the plane
!c
      integer*8 planf_be_u(nz, 3), planb_be_u(nz, 3)
!c
!c----- variables for the spin accumulation
!c
!      double precision s(0:nx+1, 0:ny+1, 0:nz+1, 3)
!c
!c----- variables for the convolution
!c
      double complex khat( mx/2+1, my, mz, 6 )

      integer*8 convf(3), convb(3)
      double precision uhat( 0:mx-1, 0:my-1, 0:mz-1, 3 )
      double complex work( mx/2+1, my, mz, 3 )

      do k=1,nz
         do j=1,ny
            do i=1,nx
               u(i,j,k,1) = u0(i,j,k,1)
               u(i,j,k,2) = u0(i,j,k,2)
               u(i,j,k,3) = u0(i,j,k,3)
            enddo
         enddo
      enddo
!c
!c----- compute the effective field
!c
!c      write(*,*) 'Effective in'
      call effective( u, hu, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )
!c      write(*,*) 'Effective out'
!c
!c----- Compute Right Hand Side for Backward Euler
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               gu(i,j,k,2) = u0(i,j,k,2) + dt * hu(i,j,k,2)
               gu(i,j,k,3) = u0(i,j,k,3) + dt * hu(i,j,k,3)
            enddo
         enddo
      enddo
!c
!c----- Solve BE
!c
!c      write(*,*) 'Solve tri in'
!      call solve_tri( gu(1,1,1,2), planf_be_u(1,2), planb_be_u(1,2), &
!          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
!      call solve_tri( gu(1,1,1,3), planf_be_u(1,3), planb_be_u(1,3), &
!          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
      call solve_tri( gu(:,:,:,2), planf_be_u(:,2), planb_be_u(:,2), &
          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
      call solve_tri( gu(:,:,:,3), planf_be_u(:,3), planb_be_u(:,3), &
          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
!c      write(*,*) 'Solve tri out'

!c
!c----- Update u
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               u(i,j,k,1) = u0(i,j,k,1) &
                   - (u0(i,j,k,2)*gu(i,j,k,3)-u0(i,j,k,3)*gu(i,j,k,2))
            enddo
         enddo
      enddo
!c
!c----- Second sweep
!c
!c      write(*,*) 'Effective in'

      call effective( u, hu, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )

!c      write(*,*) 'Effective out'
!c
!c----- compute RHS
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               gu(i,j,k,1) = u(i,j,k,1) + dt * hu(i,j,k,1)
            enddo
         enddo
      enddo

!      call solve_tri( gu(1,1,1,1), planf_be_u(1,1), planb_be_u(1,1), &
!          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
  call solve_tri( gu(:,:,:,1), planf_be_u(:,1), planb_be_u(:,1), &
          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
!c
!c----- Update u
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               u(i,j,k,2) = u0(i,j,k,2) &
                   - (u0(i,j,k,3)*gu(i,j,k,1)-u(i,j,k,1)*gu(i,j,k,3))
            enddo
         enddo
      enddo
!c
!c----- Third sweep
!c
!c      write(*,*) 'Effective in'

      call effective( u, hu, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )

!c      write(*,*) 'Effective out'
!c
!c----- compute RHS
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               gu(i,j,k,2) = u(i,j,k,2) + dt * hu(i,j,k,2)
            enddo
         enddo
      enddo
!c
!c----- Solve BE
!c
!      call solve_tri( gu(1,1,1,2), planf_be_u(1,2), planb_be_u(1,2), &
!          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
      call solve_tri( gu(:,:,:,2), planf_be_u(:,2), planb_be_u(:,2), &
          diagu_gm, fmulu_gm, upperdu_gm, nx, ny, nz )
!c
!c----- Update u
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               u(i,j,k,3) = u0(i,j,k,3) &
                   - (u(i,j,k,1)*gu(i,j,k,2)-u(i,j,k,2)*gu(i,j,k,1))
            enddo
         enddo
      enddo
!c
!c----- Add the dissipation term
!c
!c      write(*,*) 'Effective in'
      call effective( u, hu, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )
!c      write(*,*) 'Effective out'
!c
!c----- Compute RHS
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               gu(i,j,k,1) = u(i,j,k,1) + dt * dmpng * hu(i,j,k,1)
               gu(i,j,k,2) = u(i,j,k,2) + dt * dmpng * hu(i,j,k,2)
               gu(i,j,k,3) = u(i,j,k,3) + dt * dmpng * hu(i,j,k,3)
            enddo
         enddo
      enddo
!c
!c----- Solve BE
!c
!!c      write(*,*) 'Solve tri in'
!      call solve_tri( gu(1,1,1,1), planf_be_u(1,1), planb_be_u(1,1), &
!          diagu_pj, fmulu_pj, upperdu_pj, nx, ny, nz )
!!c      write(*,*) 'Solve tri in'
!      call solve_tri( gu(1,1,1,2), planf_be_u(1,2), planb_be_u(1,2), &
!          diagu_pj, fmulu_pj, upperdu_pj, nx, ny, nz )
!!c      write(*,*) 'Solve tri in'
!      call solve_tri( gu(1,1,1,3), planf_be_u(1,3), planb_be_u(1,3), &
!          diagu_pj, fmulu_pj, upperdu_pj, nx, ny, nz )
!c      write(*,*) 'Solve tri in'

      call solve_tri( gu(:,:,:,1), planf_be_u(:,1), planb_be_u(:,1), &
          diagu_pj, fmulu_pj, upperdu_pj, nx, ny, nz )
!c      write(*,*) 'Solve tri in'
      call solve_tri( gu(:,:,:,2), planf_be_u(:,2), planb_be_u(:,2), &
          diagu_pj, fmulu_pj, upperdu_pj, nx, ny, nz )
!c      write(*,*) 'Solve tri in'
      call solve_tri( gu(:,:,:,3), planf_be_u(:,3), planb_be_u(:,3), &
          diagu_pj, fmulu_pj, upperdu_pj, nx, ny, nz )

!c      write(*,*) 'Solve tri out'
!c
!c----- Project to the unit sphere
!c
      do k=1,nz
         do j=1,ny
            do i=1,nx
               tmp = dsqrt(gu(i,j,k,1)**2+gu(i,j,k,2)**2 &
                   +gu(i,j,k,3)**2)
               u(i,j,k,1) = gu(i,j,k,1) / tmp
               u(i,j,k,2) = gu(i,j,k,2) / tmp
               u(i,j,k,3) = gu(i,j,k,3) / tmp
            enddo
         enddo
      enddo

      return
      end
