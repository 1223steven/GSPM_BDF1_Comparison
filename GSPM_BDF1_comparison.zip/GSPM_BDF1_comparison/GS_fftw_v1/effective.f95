      subroutine effective( u, hu, emfu, khat, &
          convf, convb, uhat, work, nx, ny, nz, &
          mx, my, mz, dx, dy, dz, q, chi, xtrnlu )
!      implicit double precision (a-h,o-z)
!      implicit integer (i-n)

      implicit none

      integer :: nx, ny, nz, mx, my, mz, i, j, k

      double precision :: q, dx, dy, dz, chi



      double precision u( 0:nx+1, 0:ny+1, 0:nz+1, 3 )
      double precision hu( nx, ny, nz, 3)
      double precision emfu( nx, ny, nz, 3 )
!c
!c----- spin accumulation
!c
!      double precision s(0:nx+1, 0:ny+1, 0:nz+1, 3)
!c
!c----- variables for the convolution
!c
      double complex khat( mx/2+1, my, mz, 6 )

      integer*8 convf(3), convb(3)
      double precision uhat( 0:mx-1, 0:my-1, 0:mz-1, 3 )
      double complex work( mx/2+1, my, mz, 3 )

      double precision xtrnlu( nx, ny, nz, 3 )
!c
!c----- compute effective field
!c
!c      write(*,*) 'Computing stray field...'
      call stray( u, uhat, khat, work, emfu, convf, &
          convb, nx, ny, nz, mx, my, mz )
!c      write(*,*) 'End...'

      do k=1,nz
         do j=1,ny
            do i=1,nx
!               hu(i,j,k,1) = emfu(i,j,k,1) + xtrnlu(i,j,k,1) &
!                   + chi*s(i,j,k,1)
!               hu(i,j,k,2) = -q*u(i,j,k,2) + emfu(i,j,k,2) + &
!                   xtrnlu(i,j,k,2) + chi*s(i,j,k,2)
!               hu(i,j,k,3) = -q*u(i,j,k,3) + emfu(i,j,k,3) + &
!                   xtrnlu(i,j,k,3) + chi*s(i,j,k,3)

               hu(i,j,k,1) = emfu(i,j,k,1) + xtrnlu(i,j,k,1)
               hu(i,j,k,2) = -q*u(i,j,k,2) + emfu(i,j,k,2) + &
                   xtrnlu(i,j,k,2)
               hu(i,j,k,3) = -q*u(i,j,k,3) + emfu(i,j,k,3) + &
                   xtrnlu(i,j,k,3)
            enddo
         enddo
      enddo

      return
      end

