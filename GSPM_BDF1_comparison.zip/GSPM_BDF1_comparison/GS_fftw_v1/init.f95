      subroutine init( u, x, y, z, xmax, ymax, &
          zmax, nx, ny, nz, irest, iter )
!      implicit double precision( a-h, o-z )
!      implicit integer( i-n )

      implicit none

      integer :: nx, ny, nz, iter, i, j, k, idum1, idum2, irest, iinitial

      double precision :: xmax, ymax, zmax, dx, dy, dz, psi, phi, tmp, pi, ran0

      double precision u(0:nx+1, 0:ny+1, 0:nz+1, 3)
!      double precision s(0:nx+1, 0:ny+1, 0:nz+1, 3)
!      double precision Js(0:nx+1, 0:ny+1, 0:nz+1, 3, 3)
      double precision x(nx), y(ny), z(nz)

      dx = x(2)-x(1)
      dy = y(2)-y(1)
      dz = z(2)-z(1)

      pi = 4.d0 * datan( 1.d0 )

!      iinitial = 0 ! head to head Neel Wall
!      iinitial = 110 ! head to head Neel Wall v1
      iinitial = 111 ! head to head Neel Wall v2


!      iinitial = 1 !random
!      iinitial = 2
!      iinitial = 3
!      iinitial = 4 ! this is compared with mumag Standard P1

!       iinitial = 5 ! Landau state; initial vertical
!       iinitial = 6 ! Landau state; initial horizontal
!       iinitial = 61 ! Landau state; initial horizontal v2

!       iinitial = 7 ! Diamond state;
!       iinitial = 8 ! C state;
!       iinitial = 9 ! S state;
!       iinitial = 10 ! Flower state;
!       iinitial = 11 ! Single crosstie;
!       iinitial = 12 ! Double crosstie;

!      iinitial = 13 ! tail to tail Neel Wall

!      iinitial = 14 ! magnetic strip vortex; two transverse domain wall
!			iinitial = 15




      if ( iinitial .eq. 1) then
         idum1 = -13
         idum2 = -1725

         do k=1,nz
            do j=1,ny
               do i=1,nx
                  phi = 2.d0 * pi * ran0(idum1)
                  psi = 3.d0 * pi * ran0(idum2)

                  u(i,j,k,1) = dcos(phi) * dcos(psi)
                  u(i,j,k,2) = dsin(phi) * dcos(psi)
                  u(i,j,k,3) = dsin(psi)
               enddo
            enddo
         enddo
      elseif ( iinitial .eq. 2) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( x(i).lt.(xmax/3.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( x(i).gt.(2.d0*xmax/3.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 3) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
!                  if( x(i).lt.(xmax/3.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
!                  elseif( x(i).gt.(2.d0*xmax/3.d0) ) then
!                     u(i,j,k,1) = 0.d0
!                     u(i,j,k,2) = 1.d0
!                     u(i,j,k,3) = 0.d0
!                  else
!                     u(i,j,k,1) = 1.d0
!                     u(i,j,k,2) = 0.d0
!                     u(i,j,k,3) = 0.d0
!                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 4) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
!                  if( x(i).lt.(xmax/3.d0) ) then
!                     u(i,j,k,1) = 0.d0
!                     u(i,j,k,2) = 1.d0
!                     u(i,j,k,3) = 0.d0
!                  elseif( x(i).gt.(2.d0*xmax/3.d0) ) then
!                     u(i,j,k,1) = 0.d0
!                     u(i,j,k,2) = 1.d0
!                     u(i,j,k,3) = 0.d0
!                  else
                     u(i,j,k,1) = 1.d0 ! standard p1
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
!                     u(i,j,k,1) = 0.d0 ! vortex
!                     u(i,j,k,2) = 0.d0
!                     u(i,j,k,3) = -1.d0
!                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 5) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( x(i).lt.(xmax/2.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
!                  elseif( x(i).gt.(xmax/2.d0) ) then
!                     u(i,j,k,1) = 0.d0
!                     u(i,j,k,2) = -1.d0
!                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 6) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (y(j).lt. ymax/2.d0) ) then
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = -1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
        elseif ( iinitial .eq. 61) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (y(j).lt. ymax/5.d0) ) then
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = -1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 7) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (y(j).gt. ymax/2.d0).and.(x(i).lt. xmax/2.d0) ) then
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  elseif( x(i).gt.(xmax/2.d0).and.(y(j).lt. ymax/2.d0) ) then
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = -1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 8) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (x(i).lt. xmax/5.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( x(i).gt.(4.d0*xmax/5.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 9) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (x(i).lt. xmax/5.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( x(i).gt.(4.d0*xmax/5.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 10) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (x(i).lt. xmax/10.d0).and.(y(j).lt. ymax/2.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).lt. xmax/10.d0).and.(y(j).gt. ymax/2.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).gt. 9.d0*xmax/10.d0).and.(y(j).lt. ymax/2.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).gt. 9.d0*xmax/10.d0).and.(y(j).gt. ymax/2.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
     elseif ( iinitial .eq. 11) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (x(i).lt. xmax/4.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).lt. 2.d0*xmax/4.d0).and.(x(i).gt. xmax/4.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).gt. 2.d0*xmax/4.d0).and.(x(i).lt. 3.d0*xmax/4.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 12) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  if( (x(i).lt. xmax/4.d0) ) then
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = 1.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).lt. 3.d0*xmax/4.d0).and.(x(i).gt. xmax/4.d0).and.(y(j).gt. ymax/2.d0) ) then
                     u(i,j,k,1) = 1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  elseif( (x(i).lt. 3.d0*xmax/4.d0).and.(x(i).gt. xmax/4.d0).and.(y(j).lt. ymax/2.d0) ) then
                     u(i,j,k,1) = -1.d0
                     u(i,j,k,2) = 0.d0
                     u(i,j,k,3) = 0.d0
                  else
                     u(i,j,k,1) = 0.d0
                     u(i,j,k,2) = -1.d0
                     u(i,j,k,3) = 0.d0
                  endif
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 13) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  tmp = (xmax/2.d0-x(i))/(2.d0*dx) ! this is tanh
                  u(i,j,k,1) = -(exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! tail to tail Neel Wall
                  u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
                  u(i,j,k,3) = 0.d0
               enddo
            enddo
         enddo
         
    elseif ( iinitial .eq. 15) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  u(i,j,k,1) = cos(cos(pi*x(i)))*sin(0.01d0)
                  u(i,j,k,2) = sin(cos(pi*x(i)))*sin(0.01d0)
                  u(i,j,k,3) = cos(0.01d0)
               enddo
            enddo
         enddo
    elseif ( iinitial .eq. 14) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
!!                  if( (y(j).gt. ymax/2.d0) ) then ! this is vortex 1 (consider distence between two transverse domain)
!!                    tmp = (5.d0*xmax/12.d0-x(i))/(4.d0*dx) ! this is tanh
!!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!!                    u(i,j,k,2) = -2.d0/(exp(tmp)+exp(-tmp))
!!                    u(i,j,k,3) = 0.d0
!!                  else
!!                    tmp = (7.d0*xmax/12.d0-x(i))/(4.d0*dx) ! this is tanh
!!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!!                    u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
!!                    u(i,j,k,3) = 0.d0
!!                  endif

                  if( (y(j).gt. ymax/2.d0) ) then ! this is vortex 2 (consider distence between two transverse domain)
                    tmp = (11.d0*xmax/24.d0-x(i))/(4.d0*dx) ! this is tanh
                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
                    u(i,j,k,2) = -2.d0/(exp(tmp)+exp(-tmp))
                    u(i,j,k,3) = 0.d0
                  else
                    tmp = (13.d0*xmax/24.d0-x(i))/(4.d0*dx) ! this is tanh
                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
                    u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
                    u(i,j,k,3) = 0.d0
                  endif

!!                  if( (y(j).gt. ymax/2.d0) ) then ! this is vortex 1 version 2(consider distence between two transverse domain)
!!                    tmp = (5.d0*xmax/12.d0-x(i))/(2.d0*dx) ! this is tanh
!!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!!                    u(i,j,k,2) = -2.d0/(exp(tmp)+exp(-tmp))
!!                    u(i,j,k,3) = 0.d0
!!                  else
!!                    tmp = (7.d0*xmax/12.d0-x(i))/(2.d0*dx) ! this is tanh
!!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!!                    u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
!!                    u(i,j,k,3) = 0.d0
!!                  endif

!!                  if( (y(j).gt. ymax/2.d0) ) then ! this is vortex 3 (consider distence between two transverse domain)
!!                    tmp = (xmax/12.d0-x(i))/(4.d0*dx) ! this is tanh
!!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!!                    u(i,j,k,2) = -2.d0/(exp(tmp)+exp(-tmp))
!!                    u(i,j,k,3) = 0.d0
!!                  else
!!                    tmp = (11.d0*xmax/12.d0-x(i))/(4.d0*dx) ! this is tanh
!!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!!                    u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
!!                    u(i,j,k,3) = 0.d0
!!                  endif

!                  if( (x(i).lt. xmax/2.d0) ) then
!                    tmp = (xmax/3.d0-x(i))/(4.d0*dx) ! this is tanh
!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!                    u(i,j,k,2) = -2.d0/(exp(tmp)+exp(-tmp))
!                    u(i,j,k,3) = 0.d0
!                  else
!                    tmp = (2.d0*xmax/3.d0-x(i))/(4.d0*dx) ! this is tanh
!                    u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
!                    u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
!                    u(i,j,k,3) = 0.d0
!                  endif
               enddo
            enddo
         enddo
      elseif ( iinitial .eq. 110) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  tmp = (xmax/2.d0-x(i))/(2.d0*dx) ! this is tanh
                  u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
                  u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
                  u(i,j,k,3) = 0.d0
               enddo
            enddo
         enddo
      elseif ( iinitial .eq. 111) then
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  tmp = (xmax/4.d0-x(i))/(2.d0*dx) ! this is tanh
                  u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
                  u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
                  u(i,j,k,3) = 0.d0
               enddo
            enddo
         enddo
      else
         do k=1,nz
            do j=1,ny
               do i=1,nx
                  tmp = (xmax/2.d0-x(i))/(2.d0*dx) ! this is tanh
                  u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp)) ! head to head Neel Wall
                  u(i,j,k,2) = -2.d0/(exp(tmp)+exp(-tmp))
                  u(i,j,k,3) = 0.d0
!                  tmp = (ymax/2.d0-y(j))/(2.d0*dy) ! this is tanh
!                  u(i,j,k,1) = (exp(tmp)-exp(-tmp))/(exp(tmp)+exp(-tmp))
!                  u(i,j,k,2) = 2.d0/(exp(tmp)+exp(-tmp))
!                  u(i,j,k,3) = 0.d0
               enddo
            enddo
         enddo
      endif

!      do k=1,nz
!         do j=1,ny
!            do i=1,nx
!               s(i,j,k,1) = 0.d0
!               s(i,j,k,2) = 0.d0
!               s(i,j,k,3) = 0.d0
!               do l2=1,3
!               do l1=1,3
!                  Js(i,j,k,l1,l2) = 0.d0
!               enddo
!               enddo
!            enddo
!         enddo
!      enddo

      iter = 0

      return
      end
