      subroutine solve_tri( b, planf, planb, diag, fmul, upperd, &
          nx, ny, nz )
!      implicit double precision( a-h, o-z )
!      implicit integer( i-n )
      implicit none

      integer :: nx, ny, nz, i, j, k

      double precision :: scale

      double precision b(nx, ny, nz)
      double precision diag(nx, ny, nz), upperd(nx, ny, nz), &
          fmul(nx, ny, nz)
      integer*8 planf(nz), planb(nz)
!c
!c----- fourier transform
!c
      do k=1,nz
         call dfftw_execute( planb(k) )
      enddo
!c
!c----- the LU has been performed already, so fmul has the multipliers
!c
      do k=2,nz
         do j=1,ny
            do i=1,nx
               b(i,j,k) = b(i,j,k) - fmul(i,j,k-1)*b(i,j,k-1)
            enddo
         enddo
      enddo

      do j=1,ny
         do i=1,nx
            b(i,j,nz) = b(i,j,nz) / diag(i,j,nz)
         enddo
      enddo

      do k=nz-1,1,-1
         do j=1,ny
            do i=1,nx
               b(i,j,k) = (b(i,j,k)-upperd(i,j,k)*b(i,j,k+1)) &
                   /diag(i,j,k)
            enddo
         enddo
      enddo

      do k=1,nz
         call dfftw_execute( planf(k) )
      enddo
!c
!c----- rescale
!c
      scale = 1.d0 / dble( 4 * nx * ny )

      do k=1,nz
         do j=1,ny
            do i=1,nx
               b(i,j,k) = b(i,j,k) * scale
            enddo
         enddo
      enddo

      return
      end
