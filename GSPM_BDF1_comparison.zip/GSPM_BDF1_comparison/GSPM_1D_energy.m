% hw5
% A test problem for GSPM
% damping parameter \alpha
%
% clear; clc; close all;
format long;
% h = waitbar(0,'Please wait...'); % build the process bar
% initialize the problem
T = 1.d-1;
xleft = 0.0;
xright = 1.0;
T0 = 0.0;

% dx =  5.d-4;

Nx = 2000;
dx = (xright-xleft)/Nx;

% Nx = floor((xright-xleft)/dx);
x = xleft+dx/2:dx:xright-dx/2;
X = x.^2.*(ones(1,Nx)-x).^2;
X_prime = 4*x.^3-6*x.^2+2*x;
X_prime_2 = 12*x.^2-12*x+2*ones(1,Nx);

% linestyles = {'-', '--', ':', '-.','-'}; 


% dt = 1.d-2;
% Nt = floor((T-T0)/dt);

Nt =100;
dt = (T-T0)/Nt;
% figure;

alpha = 0.2;
% alpha = 10.d0;
% alpha = 0.01;


% initial condition
t = T0;
% m_init = [cos(x.^2.*(ones(1,Nx)-x).^2)*sin(t); 
%           sin(x.^2.*(ones(1,Nx)-x).^2)*sin(t); 
%           ones(size(x))*cos(t)];
      
% t = T0+dt;
% m_init = [cos(cos(pi*x))*sin(t); sin(cos(pi*x))*sin(t); ones(size(x))*cos(t)];
m_init = [cos(cos(pi*x))*sin(0.01); sin(cos(pi*x))*sin(0.01); ones(size(x))*cos(0.01)];

% m_init = [cos(x)*sin(0.1); cos(x)*cos(0.1); sin(x)];

m = zeros(size(m_init));
m_tmp = zeros(size(m_init));
% m_damp = zeros(size(m_init));
f = zeros(size(m_init));
g = zeros(size(m_init));

% Create the sparse matrix for inversion
e = ones(Nx,1);
A = spdiags([e -2*e e],-1:1,Nx,Nx);
A(1,1) = -1; 
A(Nx,Nx) = -1;
A = A/dx^2;
B = speye(Nx,Nx) - alpha*dt*A;
A = speye(Nx,Nx) - dt*A;

M = spdiags([-e 0*e e],-1:1,Nx,Nx); % matrix M means -\nabla
M(1,1) = -1;
M(Nx,Nx) = 1;
M = M/(2*dx); % nabla

E = zeros(1,Nt);

tic;

for j=1:Nt
    % implicit Gauss-Seidel
    t =  T0 + (j-1)*dt; % version 3 : correct the force term f; good

% f = [cos(X)*cos(t)+cos(t)*sin(t)*sin(X).*(X_prime).^2-cos(t)*sin(t)*cos(X).*X_prime_2+...
%     alpha*sin(t)*sin(X).*X_prime_2+alpha*sin(t)*cos(t)^2*cos(X).*(X_prime).^2;
%     sin(X)*cos(t)-cos(t)*sin(t)*cos(X).*(X_prime).^2-cos(t)*sin(t)*sin(X).*X_prime_2-...
%     alpha*sin(t)*cos(X).*X_prime_2+alpha*cos(t)^2*sin(t)*sin(X).*(X_prime).^2;
%     -sin(t)*ones(size(X))+sin(t)^2*X_prime_2-alpha*sin(t)^2*cos(t)*sin(X).*(cos(X)+sin(X)).*((X_prime).^2-X_prime_2)];

    a = cos(pi*x);
    ax = -pi*sin(pi*x);
    axx = -pi^2*a;
    
f = [cos(a)*cos(t)+(sin(a).*ax.*ax-cos(a).*axx)*sin(t)*cos(t)+alpha*(cos(a).*ax.*ax*sin(t)*cos(t)*cos(t)+axx.*sin(a)*sin(t) );
        sin(a)*cos(t)-(cos(a).*ax.*ax+sin(a).*axx)*sin(t)*cos(t)+alpha*(sin(a).*ax.*ax*sin(t)*cos(t)*cos(t)-axx.*cos(a)*sin(t));
        -ones(size(x))*sin(t)+axx*sin(t)*sin(t)+alpha*(-ax.*ax*sin(t)*sin(t)*cos(t))
    ];

f = zeros(size(m_init));
    m_tmp = m_init;
%     m_tmp = m_init+dt*f;
    
%     g(1,:) = m_tmp(1,:)/A;
    g(2,:) = m_tmp(2,:)/A;
    g(3,:) = m_tmp(3,:)/A;
    
    m(1,:) = m_init(1,:) + g(2,:).*m_init(3,:) - g(3,:).*m_init(2,:) + dt*f(1,:);
%     m(1,:) = m_init(1,:) + g(2,:).*m_init(3,:) - g(3,:).*m_init(2,:);
    
    m_tmp = m; % update 
%     m_tmp = m+dt*f;
    
    
    g(1,:) = m_tmp(1,:)/A;
    
    m(2,:) = m_init(2,:) + g(3,:).*m(1,:) - g(1,:).*m_init(3,:) + dt*f(2,:);
%     m(2,:) = m_init(2,:) + g(3,:).*m(1,:) - g(1,:).*m_init(3,:);
    
    m_tmp = m; % update
%     m_tmp = m+dt*f;
    g(2,:) = m_tmp(2,:)/A;
    
    m(3,:) = m_init(3,:) + g(1,:).*m(2,:) - g(2,:).*m(1,:) + dt*f(3,:);
%     m(3,:) = m_init(3,:) + g(1,:).*m(2,:) - g(2,:).*m(1,:);
    
    % Heat flow without constraints
%     m(1,:) = m(1,:) + dt*f(1,:);  % Here, due to the zero BC, so we
%     neglect the BC
    m(1,:) = m(1,:)/B;
    
%     m(2,:) = m(2,:) + dt*f(2,:);
    
    m(2,:) = m(2,:)/B;
    
%     m(3,:) = m(3,:) + dt*f(3,:);
%     m(3,:) = B\m_damp(3,:)';
    m(3,:) = m(3,:)/B;
    
    % Projection onto S^2
%     norm_m = sqrt(m(1,:).^2+m(2,:).^2+m(3,:).^2);
%     m(1,:) = m(1,:)./norm_m;
%     m(2,:) = m(2,:)./norm_m;
%     m(3,:) = m(3,:)./norm_m;
    
    m_init = m;
    
    
    difference=m*M';
%    size(difference)
    E(1,j) = sum(sum(abs(difference.^2)))*dx;
   
%     hold on; box on;
%    plot(x,m(1,:))
   
%    hold on; box on;
%    plot(x,m(3,:),'LineStyle', linestyles{j}, 'LineWidth', 3)
%    
%    pause(0.3);
%     waitbar(j / Nt) %  Basic Wait Bar
fprintf('The iteration times: %d \n',j);
end
toc;

% legend('m_3(t=T0)','m_3(t=T0+dt)','m_3(t=T0+2*dt)','m_3(t=T0+3*dt)','m_3(t=T0+4*dt)','Location', 'best')
% xlabel('x','FontSize',20);
% ylabel('m_3','FontSize',20);

% Compare with the exact solution
t = T;
       
m_exact = [cos(cos(pi*x))*sin(t); sin(cos(pi*x))*sin(t); ones(size(x))*cos(t)];

m_exact_prime = [sin(cos(pi*x))*pi.*sin(pi*x)*sin(t); 
                 -pi*cos(cos(pi*x)).*sin(pi*x)*sin(t); 
                 zeros(size(x))];

    
tt = linspace(0,T,Nt);

% plot(tt,E1(1,:), 'LineWidth', 3)
% 
% % xlabel('x','FontSize',20);
% xlabel('Time $t$','FontSize',20,'Interpreter','latex');
% ylabel('Energy','FontSize',20);
% set(gca, 'FontSize', 15); 

% difference = zeros(size(m_exact_prime));
% 
% % for the first two cols
% difference(:,1) = (-8*m(:,1)+9*m(:,2)-m(:,3))./(12*dx);
% difference(:,2) = (-7*m(:,1)+0*m(:,2)+8*m(:,3)-m(:,4))./(12*dx);
% 
% for i=1:length(x)-4
%    difference(:,i+2) = (m(:,i)-8*m(:,i+1)+0*m(:,i+2)+8*m(:,i+3)-m(:,i+4))./(12*dx);
% end
% 
% % for the last two cols
% difference(:,length(x)) = (m(:,length(x)-2)-9*m(:,length(x)-1)+8*m(:,length(x)))./(12*dx);
% difference(:,length(x)-1) = (1*m(:,length(x)-3)-8*m(:,length(x)-2)+0*m(:,length(x)-1)+7*m(:,length(x)))./(12*dx);
% 
% err_infty = max(max(abs(m-m_exact))) % infinity-norm
% err2 = sqrt(dx*sum(sum((m-m_exact).^2))) % 2-norm
% err_grad_2_difference = sqrt(dx*sum(sum((difference-m_exact_prime).^2)));%% the \nabla error \ell^2-norm
% err_grad_2_H_1 = err2 + err_grad_2_difference % the H^1 norm

% err_inf = max(max(abs(m-m_exact))

difference=m*M';
% cc = M*(m(3,:)');

err_infty = max(max(abs(m-m_exact))) % infinity-norm
err2 = sqrt(dx*sum(sum((m-m_exact).^2))) % 2-norm
err_grad_2_difference = sqrt(dx*sum(sum((difference-m_exact_prime).^2)));%% the \nabla error \ell^2-norm
err_grad_2_H_1 = err2 + err_grad_2_difference % the H^1 norm

% the norm 
norm = max(abs(sum(m.^2)-ones(1,Nx))) % preseving or not

% sqrt(dx*sum(sum((cc'-m_exact_prime(3,:)).^2)))

toc;

% % clearvars -except E1 E2 E3 E4 E5 tt
% 
% linestyles = {'-', '--', ':', '-.','-'}; 
% % linestyles = {'-', '--', ':', '-.', '.'}; 
% plot(tt,E1(1,:),'LineStyle', linestyles{1}, 'LineWidth', 3)
% hold on
% plot(tt,E2(1,:),'LineStyle', linestyles{2},'LineWidth', 3)
% hold on
% plot(tt,E3(1,:),'LineStyle', linestyles{3},'LineWidth', 3)
% hold on
% plot(tt,E4(1,:),'LineStyle', linestyles{4},'LineWidth', 3)
% hold on
% plot(tt,E5(1,:),'LineStyle', linestyles{5},'LineWidth', 3)
% xlabel('Time $t$','FontSize',20,'Interpreter','latex');
% ylabel('Energy','FontSize',20);
% set(gca, 'FontSize', 15);  
% legend('$\alpha=0.$','$\alpha=0.01$','$\alpha=0.05$','$\alpha=0.1$','$\alpha=0.2$','Location', 'best','Interpreter','latex')

% proj and noproj
linestyles = {'-', '--'}; 
% linestyles = {'-', '--', ':', '-.', '.'}; 
plot(tt,E1(1,:),'LineStyle', linestyles{1}, 'LineWidth', 3)
hold on
plot(tt,E2(1,:),'LineStyle', linestyles{2},'LineWidth', 3)
hold on
xlabel('Time $t$','FontSize',20,'Interpreter','latex');
ylabel('Energy','FontSize',20);
set(gca, 'FontSize', 15);  
legend('GS projection','GS no projection', 'best','Interpreter','latex')

